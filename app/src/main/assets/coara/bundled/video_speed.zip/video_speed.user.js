// ==UserScript==
// @name         再生速度
// @namespace    coara
// @version      1.0.0
// @description  ページ内のvideo/audioの再生速度をメニューから変更します
// @author       Coara
// @match        http://*/*
// @match        https://*/*
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_notification
// @grant        GM_registerMenuCommand
// @noframes
// ==/UserScript==
(function () {
    var SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 2, 3];
    var current = GM_getValue('speed', 1);

    function apply() {
        var media = document.querySelectorAll('video, audio');
        for (var i = 0; i < media.length; i++) {
            media[i].playbackRate = current;
        }
        return media.length;
    }

    function set(speed) {
        current = speed;
        GM_setValue('speed', speed);
        var n = apply();
        GM_notification({ title: '再生速度', text: speed + 'x (' + n + '件)' });
    }

    SPEEDS.forEach(function (s) {
        GM_registerMenuCommand('再生速度 ' + s + 'x', function () { set(s); });
    });

    document.addEventListener('play', function (ev) {
        var t = ev.target;
        if (t && (t.tagName === 'VIDEO' || t.tagName === 'AUDIO') && current !== 1) {
            t.playbackRate = current;
        }
    }, true);
})();
