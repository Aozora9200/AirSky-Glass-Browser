(function () {
    "use strict";

    var TITLE = "DevTools";
    var MAX_LOG = 2000;
    var MAX_NET = 2000;
    var MAX_M3U_PER_PAGE = 300;
    var BODY_LIMIT = 4000;
    var SAVE_DIR = "/sdcard/download/";
    var WIN_KEY = "__dt_win";
    var M3U_KEY = "__dt_m3u";
    var FAB_KEY = "__dt_fab";
    var MIN_W = 260;
    var MIN_H = 140;
    var TOOLBAR_H = 46;
    var FAB_SIZE = 52;
    var FAB_DRAG_THRESHOLD = 6;
    var M3U_SCAN_MS = 4000;
    var M3U_RE = /(^|[^a-z0-9])m3u8?([^a-z0-9]|$)/i;
    var M3U_URL_RE = /https?:\/\/[^\s"'`<>\\{}|]+/gi;
    var M3U_SEL = "video,source,audio,track,iframe,embed,object,a,link,meta,script";
    var M3U_ATTRS = ["src", "href", "data-src", "data-url", "data-video", "data-file", "data-hls", "data-playlist", "data-m3u8", "content"];

    var logs = [];
    var nets = [];
    var netIndex = {};
    var m3uStore = null;
    var m3uSeen = {};
    var m3uScanTimer = 0;
    var m3uObs = null;
    var m3uLoaded = false;
    var m3uSessionKey = null;
    var m3uPageWatchTimer = 0;

    var panelOpen = false;
    var activeTab = "console";
    var panelRoot = null;
    var panelBody = null;
    var toolbarEl = null;
    var fabEl = null;
    var logFilter = "";
    var netFilter = "";
    var m3uFilter = "";
    var netTypeFilter = "all";
    var consoleHooked = false;
    var xhrHooked = false;
    var fetchHooked = false;
    var perfHooked = false;
    var domReady = false;
    var commandsRegistered = false;
    var logPaintRaf = 0;
    var netPaintRaf = 0;
    var m3uPaintRaf = 0;

    var win = { x: 4, y: 0, w: 0, h: 0, maximized: false, minimized: false };
    var winLoaded = false;
    var winApplyRaf = 0;

    var fab = { x: null, y: null };
    var fabLoaded = false;

    function hasCoara() {
        return typeof coara !== "undefined" && coara !== null;
    }

    function now() { return Date.now(); }
    function p2(n) { return (n < 10 ? "0" : "") + n; }
    function p3(n) { return (n < 10 ? "00" : n < 100 ? "0" : "") + n; }
    function tsOf(t) {
        var d = new Date(t);
        return p2(d.getHours()) + ":" + p2(d.getMinutes()) + ":" + p2(d.getSeconds()) + "." + p3(d.getMilliseconds());
    }
    function stamp() {
        var d = new Date();
        return "" + d.getFullYear() + p2(d.getMonth() + 1) + p2(d.getDate()) + "_" + p2(d.getHours()) + p2(d.getMinutes()) + p2(d.getSeconds());
    }
    function esc(s) {
        return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
            return c === "&" ? "&amp;" : c === "<" ? "&lt;" : c === ">" ? "&gt;" : c === "\"" ? "&quot;" : "&#39;";
        });
    }
    function bytes(n) {
        if (!isFinite(n) || n < 0) return "-";
        if (n < 1024) return n + " B";
        if (n < 1048576) return (n / 1024).toFixed(1) + " KB";
        if (n < 1073741824) return (n / 1048576).toFixed(2) + " MB";
        return (n / 1073741824).toFixed(2) + " GB";
    }
    function ms(n) {
        if (!isFinite(n) || n < 0) return "-";
        return n < 1000 ? Math.round(n) + " ms" : (n / 1000).toFixed(2) + " s";
    }
    function str(v) {
        try {
            if (v === undefined) return "undefined";
            if (v === null) return "null";
            if (typeof v === "string") return v;
            if (typeof v === "number" || typeof v === "boolean") return String(v);
            if (v instanceof Error) return (v.name || "Error") + ": " + v.message + (v.stack ? "\n" + v.stack : "");
            if (typeof v === "function") return "ƒ " + (v.name || "anonymous") + "()";
            if (typeof Element !== "undefined" && v instanceof Element) {
                var cn = (typeof v.className === "string" && v.className) ? "." + v.className.trim().split(/\s+/).join(".") : "";
                return "<" + v.tagName.toLowerCase() + (v.id ? "#" + v.id : "") + cn + ">";
            }
            if (typeof Node !== "undefined" && v instanceof Node) return "[Node " + v.nodeName + "]";
            if (Array.isArray(v)) {
                var a = v.slice(0, 40).map(str);
                return "[" + a.join(", ") + (v.length > 40 ? ", …" : "") + "]";
            }
            if (typeof v === "object") {
                var s = JSON.stringify(v);
                if (s && s.length > BODY_LIMIT) s = s.slice(0, BODY_LIMIT) + "…";
                return s;
            }
            return String(v);
        } catch (e) {
            return "[unprintable]";
        }
    }

    function toast(msg) {
        if (hasCoara()) {
            try {
                if (typeof coara.notify === "function") { coara.notify(msg, TITLE); return; }
            } catch (e) {}
        }
        try {
            var t = document.createElement("div");
            t.textContent = msg;
            t.style.cssText = "position:fixed;left:50%;bottom:80px;transform:translateX(-50%);background:rgba(20,20,28,.95);color:#fff;padding:10px 16px;border-radius:20px;font:13px/1.3 sans-serif;z-index:2147483647;pointer-events:none;box-shadow:0 6px 22px rgba(0,0,0,.5);max-width:86vw;text-align:center;";
            (document.body || document.documentElement).appendChild(t);
            setTimeout(function () { try { t.parentNode.removeChild(t); } catch (e) {} }, 2200);
        } catch (e) {}
    }

    function copyText(text) {
        if (hasCoara()) {
            try {
                if (typeof coara.copy === "function") { coara.copy(text); return true; }
            } catch (e) {}
        }
        var ok = false;
        try {
            var ta = document.createElement("textarea");
            ta.value = text;
            ta.setAttribute("readonly", "");
            ta.style.cssText = "position:fixed;top:0;left:0;width:1px;height:1px;opacity:0;padding:0;border:0;";
            (document.body || document.documentElement).appendChild(ta);
            ta.focus();
            ta.select();
            try { ta.setSelectionRange(0, ta.value.length); } catch (e) {}
            ok = document.execCommand("copy");
            try { ta.parentNode.removeChild(ta); } catch (e) {}
        } catch (e) { ok = false; }
        if (!ok && navigator.clipboard && navigator.clipboard.writeText) {
            try { navigator.clipboard.writeText(text); ok = true; } catch (e) {}
        }
        return ok;
    }

    function blobDownload(name, text) {
        try {
            var blob = new Blob([text], { type: "text/plain;charset=utf-8" });
            var url = URL.createObjectURL(blob);
            var a = document.createElement("a");
            a.href = url;
            a.download = name;
            a.rel = "noopener";
            a.style.cssText = "position:fixed;left:-9999px;top:-9999px;width:1px;height:1px;opacity:0;pointer-events:none;";
            a.addEventListener("click", function (ev) { ev.stopPropagation(); }, true);
            (document.body || document.documentElement).appendChild(a);
            var evt = null;
            try {
                evt = document.createEvent("MouseEvents");
                evt.initEvent("click", true, true);
            } catch (e) {}
            if (evt) a.dispatchEvent(evt);
            else if (typeof a.click === "function") a.click();
            setTimeout(function () {
                try { if (a.parentNode) a.parentNode.removeChild(a); } catch (e) {}
                try { URL.revokeObjectURL(url); } catch (e) {}
            }, 4000);
            return true;
        } catch (e) {}
        return false;
    }

    function download(name, text) {
        if (hasCoara()) {
            try {
                if (typeof coara.writeFile === "function") {
                    if (coara.writeFile(SAVE_DIR + name, text) === true) return true;
                }
            } catch (e) {}
            try {
                if (typeof coara.saveFile === "function") {
                    if (coara.saveFile(SAVE_DIR + name, text) === true) return true;
                }
            } catch (e) {}
            try {
                if (coara.file && typeof coara.file.write === "function") {
                    if (coara.file.write(SAVE_DIR + name, text) === true) return true;
                }
            } catch (e) {}
        }
        return blobDownload(name, text);
    }

    function el(tag, cls, html) {
        var e = document.createElement(tag);
        if (cls) e.className = cls;
        if (html != null) e.innerHTML = html;
        return e;
    }

    /* ===== M3U Module ===== */

    function m3uPageKey() {
        try { return String(location.href).split("#")[0]; } catch (e) { return "unknown"; }
    }
    function m3uPageTitle() {
        var t = "";
        try { t = document.title || ""; } catch (e) { t = ""; }
        t = String(t).replace(/\s+/g, " ").trim();
        if (!t) { try { t = location.hostname || ""; } catch (e) { t = ""; } }
        return t;
    }
    function m3uCanonical(u) {
        try {
            var x = new URL(u);
            x.hash = "";
            var proto = x.protocol.toLowerCase();
            var host = x.hostname.toLowerCase();
            var port = x.port;
            if ((proto === "http:" && port === "80") || (proto === "https:" && port === "443")) port = "";
            var path = x.pathname || "/";
            if (path.length > 1 && path.charAt(path.length - 1) === "/") path = path.slice(0, -1);
            var q = x.search || "";
            return proto + "//" + host + (port ? ":" + port : "") + path + q;
        } catch (e) { return u; }
    }
    function m3uNormalize(raw) {
        if (!raw || typeof raw !== "string") return null;
        var s = raw.trim();
        if (!s) return null;
        s = s.replace(/[.,;:!?)\]}'"]+$/, "");
        if (/^(blob|data|filesystem|about|javascript):/i.test(s)) return null;
        var abs;
        try { abs = new URL(s, location.href).href; } catch (e) { return null; }
        if (!/^https?:/i.test(abs)) return null;
        if (!M3U_RE.test(abs)) return null;
        return m3uCanonical(abs);
    }
    function m3uLoadStore() {
        var raw = null;
        try {
            if (hasCoara() && coara.storage && typeof coara.storage.get === "function") {
                raw = coara.storage.get(M3U_KEY);
            }
        } catch (e) {}
        if (!raw) { try { raw = localStorage.getItem(M3U_KEY); } catch (e) {} }
        var st = null;
        if (raw) {
            try { st = JSON.parse(raw); } catch (e) { st = null; }
        }
        if (!st || typeof st !== "object" || typeof st.id !== "string" || !st.pages || typeof st.pages !== "object") {
            st = { id: stamp(), pages: {} };
        }
        for (var k in st.pages) {
            if (!Object.prototype.hasOwnProperty.call(st.pages, k)) continue;
            var v = st.pages[k];
            if (Array.isArray(v)) st.pages[k] = { title: "", urls: v };
            else if (!v || typeof v !== "object" || !Array.isArray(v.urls)) st.pages[k] = { title: "", urls: [] };
            if (typeof st.pages[k].title !== "string") st.pages[k].title = "";
            var uniq = [];
            for (var i = 0; i < st.pages[k].urls.length; i++) {
                if (uniq.indexOf(st.pages[k].urls[i]) < 0) uniq.push(st.pages[k].urls[i]);
            }
            st.pages[k].urls = uniq;
        }
        return st;
    }
    function m3uSaveStore() {
        if (!m3uStore) return false;
        var text = JSON.stringify(m3uStore);
        var ok = false;
        try {
            if (hasCoara() && coara.storage && typeof coara.storage.set === "function") {
                ok = coara.storage.set(M3U_KEY, text) === true;
            }
        } catch (e) { ok = false; }
        if (!ok) { try { localStorage.setItem(M3U_KEY, text); ok = true; } catch (e) { ok = false; } }
        return ok;
    }
    function m3uResetStore(reason) {
        m3uStore = { id: stamp(), pages: {} };
        m3uSeen = {};
        m3uSessionKey = m3uPageKey();
        m3uSaveStore();
        if (panelOpen && activeTab === "m3u") scheduleM3UPaint();
        if (reason === "navigate") toast("ページ遷移: m3u 検出をリセット");
    }
    function m3uCheckPage() {
        var cur = m3uPageKey();
        if (m3uSessionKey !== cur) {
            m3uResetStore("navigate");
            return true;
        }
        return false;
    }
    function m3uAdd(raw, from) {
        if (m3uSessionKey !== m3uPageKey()) m3uResetStore("navigate");
        var url = m3uNormalize(raw);
        if (!url) return false;
        var key = m3uPageKey();
        var sk = key + "\u0000" + url;
        if (m3uSeen[sk]) return false;
        m3uSeen[sk] = 1;
        if (!m3uStore) m3uStore = m3uLoadStore();
        var title = m3uPageTitle();
        var changed = false;
        if (!m3uStore.pages[key]) { m3uStore.pages[key] = { title: title, urls: [] }; changed = true; }
        else {
            if (title && m3uStore.pages[key].title !== title) { m3uStore.pages[key].title = title; changed = true; }
            if (!m3uStore.pages[key].urls) m3uStore.pages[key].urls = [];
        }
        if (m3uStore.pages[key].urls.indexOf(url) < 0) {
            if (m3uStore.pages[key].urls.length < MAX_M3U_PER_PAGE) {
                m3uStore.pages[key].urls.push(url);
                changed = true;
            }
        }
        if (!changed) return false;
        m3uSaveStore();
        if (panelOpen && activeTab === "m3u") scheduleM3UPaint();
        return true;
    }
    function m3uScanText(text) {
        if (!text || typeof text !== "string" || text.length > 2000000) return;
        M3U_URL_RE.lastIndex = 0;
        var m;
        var n = 0;
        while ((m = M3U_URL_RE.exec(text)) !== null) {
            if (++n > 300) break;
            m3uAdd(m[0], "text");
        }
        M3U_URL_RE.lastIndex = 0;
    }
    function m3uScanNode(elem) {
        if (!elem || elem.nodeType !== 1) return;
        for (var i = 0; i < M3U_ATTRS.length; i++) {
            var v = null;
            try { v = elem.getAttribute(M3U_ATTRS[i]); } catch (e) { v = null; }
            if (v) m3uAdd(v, "dom");
        }
        var tag = elem.tagName;
        if (tag === "VIDEO" || tag === "AUDIO") {
            try { if (elem.currentSrc) m3uAdd(elem.currentSrc, "media"); } catch (e) {}
            try { if (elem.src) m3uAdd(elem.src, "media"); } catch (e) {}
        } else if (tag === "SCRIPT") {
            if (!elem.__m3uScanned) {
                elem.__m3uScanned = true;
                m3uScanText(elem.textContent || "");
            }
        }
    }
    function m3uScanTree(root) {
        if (!root) root = document;
        if (root.nodeType === 1) m3uScanNode(root);
        var list = null;
        try {
            var base = (root.nodeType === 1 || root.nodeType === 9) ? root : document;
            list = base.querySelectorAll ? base.querySelectorAll(M3U_SEL) : null;
        } catch (e) { list = null; }
        if (!list) return;
        for (var i = 0; i < list.length; i++) m3uScanNode(list[i]);
    }
    function m3uQuickScan() {
        if (m3uCheckPage()) return;
        var list = null;
        try { list = document.querySelectorAll("video,audio,source,iframe,embed,object"); } catch (e) { return; }
        for (var i = 0; i < list.length; i++) m3uScanNode(list[i]);
    }
    function m3uHookXHR() {
        try {
            if (!window.XMLHttpRequest || XMLHttpRequest.prototype.__m3uHooked) return;
            var open = XMLHttpRequest.prototype.open;
            XMLHttpRequest.prototype.open = function (method, url) {
                try { m3uAdd(url, "xhr"); } catch (e) {}
                return open.apply(this, arguments);
            };
            XMLHttpRequest.prototype.__m3uHooked = true;
        } catch (e) {}
    }
    function m3uHookFetch() {
        try {
            if (!window.fetch || window.fetch.__m3uHooked) return;
            var orig = window.fetch;
            var wrapped = function (input, init) {
                try {
                    var u = "";
                    if (typeof input === "string") u = input;
                    else if (input && typeof input.url === "string") u = input.url;
                    if (u) m3uAdd(u, "fetch");
                } catch (e) {}
                return orig.apply(this, arguments);
            };
            wrapped.__m3uHooked = true;
            window.fetch = wrapped;
        } catch (e) {}
    }
    function m3uHookMediaSrc() {
        try {
            if (!window.HTMLMediaElement || HTMLMediaElement.prototype.__m3uSrcHooked) return;
            var desc = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, "src");
            if (!desc || !desc.set || !desc.get) return;
            Object.defineProperty(HTMLMediaElement.prototype, "src", {
                configurable: true,
                enumerable: desc.enumerable,
                get: function () { return desc.get.call(this); },
                set: function (v) {
                    try { if (v) m3uAdd(v, "media-set"); } catch (e) {}
                    return desc.set.call(this, v);
                }
            });
            HTMLMediaElement.prototype.__m3uSrcHooked = true;
        } catch (e) {}
    }
    function m3uHookMediaEvents() {
        try {
            document.addEventListener("loadedmetadata", function (ev) {
                try {
                    var t = ev.target;
                    if (t && (t.tagName === "VIDEO" || t.tagName === "AUDIO")) {
                        if (t.currentSrc) m3uAdd(t.currentSrc, "media");
                        if (t.src) m3uAdd(t.src, "media");
                    }
                } catch (e) {}
            }, true);
            document.addEventListener("loadstart", function (ev) {
                try {
                    var t = ev.target;
                    if (t && (t.tagName === "VIDEO" || t.tagName === "AUDIO")) {
                        if (t.currentSrc) m3uAdd(t.currentSrc, "media");
                        if (t.src) m3uAdd(t.src, "media");
                    }
                } catch (e) {}
            }, true);
        } catch (e) {}
    }
    function m3uScanPerf() {
        if (!window.performance || typeof performance.getEntriesByType !== "function") return;
        var list = null;
        try { list = performance.getEntriesByType("resource"); } catch (e) { return; }
        if (!list) return;
        for (var i = 0; i < list.length; i++) m3uAdd(list[i].name, "perf");
    }
    function m3uObservePerf() {
        if (!window.PerformanceObserver || window.PerformanceObserver.__m3uHooked) return;
        var cb = function (l) {
            var es = l.getEntries();
            for (var i = 0; i < es.length; i++) m3uAdd(es[i].name, "perf");
        };
        try {
            var po = new PerformanceObserver(cb);
            po.observe({ type: "resource", buffered: true });
            window.PerformanceObserver.__m3uHooked = true;
        } catch (e) {
            try {
                var po2 = new PerformanceObserver(cb);
                po2.observe({ entryTypes: ["resource"] });
                window.PerformanceObserver.__m3uHooked = true;
            } catch (e2) {}
        }
    }
    function m3uObserveDom() {
        if (m3uObs || !window.MutationObserver) return;
        try {
            m3uObs = new MutationObserver(function (muts) {
                for (var i = 0; i < muts.length; i++) {
                    var mu = muts[i];
                    if (mu.type === "attributes") {
                        var v = null;
                        try { v = mu.target.getAttribute(mu.attributeName); } catch (e) { v = null; }
                        if (v) m3uAdd(v, "attr");
                    } else if (mu.type === "childList") {
                        for (var j = 0; j < mu.addedNodes.length; j++) {
                            var n = mu.addedNodes[j];
                            if (n.nodeType === 1) m3uScanTree(n);
                            else if (n.nodeType === 3) m3uScanText(n.nodeValue || "");
                        }
                    }
                }
            });
            m3uObs.observe(document.documentElement || document, {
                childList: true, subtree: true, attributes: true,
                attributeFilter: M3U_ATTRS
            });
        } catch (e) { m3uObs = null; }
    }
    function m3uHookHistory() {
        try {
            if (window.__m3uHistoryHooked) return;
            window.__m3uHistoryHooked = true;
            window.addEventListener("popstate", function () { m3uCheckPage(); });
            window.addEventListener("hashchange", function () { m3uCheckPage(); });
            if (window.history) {
                ["pushState", "replaceState"].forEach(function (name) {
                    var orig = history[name];
                    if (typeof orig !== "function") return;
                    history[name] = function () {
                        var r = orig.apply(this, arguments);
                        try { m3uCheckPage(); } catch (e) {}
                        return r;
                    };
                });
            }
        } catch (e) {}
    }
    function m3uBuildText() {
        var st = m3uStore || m3uLoadStore();
        var d = new Date();
        var lines = [];
        var keys = [];
        for (var k in st.pages) if (Object.prototype.hasOwnProperty.call(st.pages, k)) keys.push(k);
        keys.sort();
        var total = 0;
        for (var i = 0; i < keys.length; i++) {
            var u = st.pages[keys[i]].urls || [];
            total += u.length;
        }
        lines.push("# M3U URL リスト");
        lines.push("# 保存日時: " + d.getFullYear() + "-" + p2(d.getMonth() + 1) + "-" + p2(d.getDate()) + " " + p2(d.getHours()) + ":" + p2(d.getMinutes()) + ":" + p2(d.getSeconds()));
        lines.push("# 合計: " + total + " 件 / " + keys.length + " ページ");
        lines.push("");
        var n = 0;
        for (var j = 0; j < keys.length; j++) {
            var key = keys[j];
            var page = st.pages[key];
            var arr = page.urls || [];
            if (!arr.length) continue;
            n++;
            lines.push("============================================================");
            lines.push("[" + n + "] " + (page.title || "(タイトルなし)"));
            lines.push("    " + key);
            lines.push("------------------------------------------------------------");
            for (var m = 0; m < arr.length; m++) lines.push("    " + (m + 1) + ". " + arr[m]);
            lines.push("");
        }
        if (!total) { lines.push("(m3u URL はまだ検出されていません)"); lines.push(""); }
        return lines.join("\n");
    }
    function m3uFlush() {
        if (!m3uStore) m3uStore = m3uLoadStore();
        m3uSaveStore();
        var text = m3uBuildText();
        var name = m3uStore.id + "m3u-url.txt";
        return download(name, text);
    }
    function m3uStart() {
        m3uHookXHR();
        m3uHookFetch();
        m3uHookMediaSrc();
        m3uHookMediaEvents();
        m3uHookHistory();
        m3uObservePerf();
        m3uObserveDom();
        m3uScanPerf();
        m3uScanTree(document);
        if (!m3uScanTimer) {
            m3uScanTimer = setInterval(function () { m3uQuickScan(); }, M3U_SCAN_MS);
        }
        if (!m3uPageWatchTimer) {
            m3uPageWatchTimer = setInterval(function () { m3uCheckPage(); }, 1000);
        }
    }
    function m3uInit() {
        if (m3uLoaded) return;
        m3uLoaded = true;
        m3uStore = { id: stamp(), pages: {} };
        m3uSeen = {};
        m3uSessionKey = m3uPageKey();
        m3uSaveStore();
        m3uHookXHR();
        m3uHookFetch();
        m3uHookMediaSrc();
        m3uHookMediaEvents();
        m3uHookHistory();
        m3uObservePerf();
        m3uStart();
    }
    function m3uCount() {
        if (!m3uStore) m3uStore = m3uLoadStore();
        var total = 0;
        for (var k in m3uStore.pages) if (Object.prototype.hasOwnProperty.call(m3uStore.pages, k)) total += (m3uStore.pages[k].urls || []).length;
        return total;
    }
    function m3uReset() {
        m3uStore = { id: stamp(), pages: {} };
        m3uSeen = {};
        m3uSessionKey = m3uPageKey();
        m3uSaveStore();
    }

    /* ===== Console ===== */

    function pushLog(level, args) {
        var parts = [];
        for (var i = 0; i < args.length; i++) parts.push(str(args[i]));
        logs.push({ t: now(), level: level, text: parts.join(" ") });
        if (logs.length > MAX_LOG) logs.splice(0, logs.length - MAX_LOG);
        if (panelOpen && activeTab === "console") scheduleLogPaint();
    }
    function scheduleLogPaint() {
        if (logPaintRaf) return;
        logPaintRaf = requestAnimationFrame(function () { logPaintRaf = 0; paintConsole(); });
    }
    function scheduleNetPaint() {
        if (netPaintRaf) return;
        netPaintRaf = requestAnimationFrame(function () { netPaintRaf = 0; paintNetwork(); });
    }
    function scheduleM3UPaint() {
        if (m3uPaintRaf) return;
        m3uPaintRaf = requestAnimationFrame(function () { m3uPaintRaf = 0; paintM3U(); });
    }
    function hookConsole() {
        if (consoleHooked) return;
        consoleHooked = true;
        ["log", "info", "warn", "error", "debug"].forEach(function (lv) {
            var orig = console[lv];
            if (typeof orig !== "function") return;
            console[lv] = function () {
                try { pushLog(lv, arguments); } catch (e) {}
                try { return orig.apply(console, arguments); } catch (e) {}
            };
        });
        window.addEventListener("error", function (ev) {
            try { pushLog("error", [(ev.message || "error") + " @ " + (ev.filename || "?") + ":" + (ev.lineno || 0)]); } catch (e) {}
        });
        window.addEventListener("unhandledrejection", function (ev) {
            try { pushLog("error", ["Unhandled rejection: " + str(ev.reason)]); } catch (e) {}
        });
    }

    /* ===== Network ===== */

    function inferType(url, init) {
        var u = String(url || "").toLowerCase();
        if (init === "xmlhttprequest") return "xhr";
        if (init === "fetch") return "fetch";
        if (init === "script") return "script";
        if (init === "css" || init === "link") return "css";
        if (init === "img") return "img";
        if (init === "iframe") return "iframe";
        if (init === "navigation") return "doc";
        if (/\.m3u8?(\?|#|$)/.test(u)) return "m3u";
        if (/\.js(\?|#|$)/.test(u)) return "script";
        if (/\.css(\?|#|$)/.test(u)) return "css";
        if (/\.(png|jpe?g|gif|webp|svg|ico|bmp|avif)(\?|#|$)/.test(u)) return "img";
        if (/\.(mp4|webm|mov|mkv|mp3|m4a|ogg|wav|aac|flac|m3u8?)(\?|#|$)/.test(u)) return "media";
        if (/\.(woff2?|ttf|otf|eot)(\?|#|$)/.test(u)) return "font";
        if (/\.(json|xml)(\?|#|$)/.test(u)) return "data";
        if (/\.(html?|php|asp|aspx|jsp)(\?|#|$)/.test(u)) return "doc";
        return init || "other";
    }
    function findNetByUrl(url) {
        for (var i = nets.length - 1; i >= 0; i--) if (nets[i].url === url) return nets[i];
        return null;
    }
    function pushNet(entry) {
        var key = (entry.method || "GET") + " " + entry.url;
        var exist = netIndex[key];
        if (exist) {
            for (var k in entry) if (Object.prototype.hasOwnProperty.call(entry, k)) exist[k] = entry[k];
            if (panelOpen && activeTab === "network") scheduleNetPaint();
            return exist;
        }
        entry.id = key;
        nets.push(entry);
        netIndex[key] = entry;
        if (nets.length > MAX_NET) {
            var r = nets.shift();
            delete netIndex[r.id];
        }
        if (panelOpen && activeTab === "network") scheduleNetPaint();
        return entry;
    }
    function hookXHR() {
        if (xhrHooked || !window.XMLHttpRequest) return;
        xhrHooked = true;
        var oOpen = XMLHttpRequest.prototype.open;
        var oSend = XMLHttpRequest.prototype.send;
        XMLHttpRequest.prototype.open = function (method, url) {
            try {
                this.__dt_method = (method || "GET").toUpperCase();
                this.__dt_url = String(url);
            } catch (e) {}
            return oOpen.apply(this, arguments);
        };
        XMLHttpRequest.prototype.send = function () {
            var self = this;
            var start = now();
            var method = self.__dt_method || "GET";
            var url = self.__dt_url || "";
            try { url = new URL(url, location.href).href; } catch (e) {}
            var entry = pushNet({
                method: method, url: url, type: "xhr",
                status: 0, statusText: "", size: 0, duration: 0,
                start: start, end: 0, initiator: "xmlhttprequest"
            });
            var done = function () {
                var end = now();
                entry.duration = end - start;
                entry.end = end;
                try { entry.status = self.status; entry.statusText = self.statusText; } catch (e) {}
                try {
                    var len = self.getResponseHeader("content-length");
                    if (len) entry.size = parseInt(len, 10) || 0;
                    else if (self.responseType === "" || self.responseType === "text") entry.size = (self.responseText || "").length;
                } catch (e) {}
                pushNet(entry);
            };
            try { self.addEventListener("loadend", done); } catch (e) {}
            return oSend.apply(this, arguments);
        };
    }
    function hookFetch() {
        if (fetchHooked || !window.fetch) return;
        fetchHooked = true;
        var orig = window.fetch;
        window.fetch = function (input, init) {
            var start = now();
            var method = "GET", url = "";
            try {
                if (typeof input === "string") url = new URL(input, location.href).href;
                else if (input && input.url) url = new URL(input.url, location.href).href;
                if (init && init.method) method = String(init.method).toUpperCase();
                else if (input && input.method) method = String(input.method).toUpperCase();
            } catch (e) {}
            var entry = pushNet({
                method: method, url: url, type: "fetch",
                status: 0, statusText: "", size: 0, duration: 0,
                start: start, end: 0, initiator: "fetch"
            });
            return orig.apply(this, arguments).then(function (res) {
                var end = now();
                entry.duration = end - start;
                entry.end = end;
                try { entry.status = res.status; entry.statusText = res.statusText; } catch (e) {}
                try {
                    var len = res.headers && res.headers.get ? res.headers.get("content-length") : null;
                    if (len) entry.size = parseInt(len, 10) || 0;
                } catch (e) {}
                pushNet(entry);
                return res;
            }, function (err) {
                entry.duration = now() - start;
                entry.status = 0;
                entry.statusText = "Failed";
                pushNet(entry);
                throw err;
            });
        };
    }
    function hookPerf() {
        if (perfHooked) return;
        perfHooked = true;
        try {
            if (performance.getEntriesByType) {
                performance.getEntriesByType("resource").forEach(addPerf);
                performance.getEntriesByType("navigation").forEach(addNavPerf);
            }
        } catch (e) {}
        if (!window.PerformanceObserver) return;
        try {
            var po = new PerformanceObserver(function (list) {
                list.getEntries().forEach(function (e) {
                    if (e.entryType === "navigation") addNavPerf(e); else addPerf(e);
                });
            });
            po.observe({ type: "resource", buffered: true });
        } catch (e) {
            try {
                var po2 = new PerformanceObserver(function (list) {
                    list.getEntries().forEach(addPerf);
                });
                po2.observe({ entryTypes: ["resource"] });
            } catch (e2) {}
        }
    }
    function addNavPerf(e) {
        if (!e) return;
        var url = e.name || location.href;
        var key = "GET " + url;
        if (netIndex[key]) return;
        pushNet({
            method: "GET", url: url, type: "doc",
            status: 200, statusText: "", size: e.transferSize || 0,
            duration: e.duration || 0, start: e.startTime || 0,
            end: e.responseEnd || 0, initiator: "navigation"
        });
    }
    function addPerf(e) {
        if (!e || !e.name) return;
        var url = e.name;
        if (!/^https?:/i.test(url)) return;
        var m = findNetByUrl(url);
        var size = e.transferSize || e.encodedBodySize || 0;
        var dur = e.duration || 0;
        if (m) {
            if (!m.size) m.size = size;
            if (!m.duration) m.duration = dur;
            if (!m.end) m.end = e.responseEnd;
            if (!m.start) m.start = e.startTime;
            pushNet(m);
            return;
        }
        pushNet({
            method: "GET", url: url, type: inferType(url, e.initiatorType || "resource"),
            status: 200, statusText: "", size: size, duration: dur,
            start: e.startTime || 0, end: e.responseEnd || 0,
            initiator: e.initiatorType || "resource"
        });
    }

    /* ===== CSS ===== */

    var CSS = [
        ".__dt_fab{position:fixed;left:0;top:0;width:52px;height:52px;border-radius:50%;background:linear-gradient(135deg,#2979ff,#5c6bc0);color:#fff;font-size:22px;border:0;z-index:2147483646;cursor:pointer;display:flex;align-items:center;justify-content:center;box-shadow:0 6px 22px rgba(41,121,255,.55);user-select:none;-webkit-user-select:none;-webkit-tap-highlight-color:transparent;touch-action:none;padding:0;line-height:1;font-family:sans-serif;will-change:left,top;transition:box-shadow .15s}",
        ".__dt_fab:active{background:linear-gradient(135deg,#1565ff,#3f51b5)}",
        ".__dt_fab.__dt_fab_dragging{box-shadow:0 10px 32px rgba(41,121,255,.8);opacity:.9;transition:none}",
        ".__dt_root{position:fixed;z-index:2147483647;background:#0d0d12;color:#e8e8ec;font:13px/1.45 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;display:flex;flex-direction:column;box-sizing:border-box;overflow:hidden;border-radius:12px;box-shadow:0 12px 48px rgba(0,0,0,.6),0 0 0 1px rgba(255,255,255,.08);min-width:260px;min-height:140px}",
        ".__dt_root.__dt_maximized{border-radius:0}",
        ".__dt_root *{box-sizing:border-box;-webkit-tap-highlight-color:transparent}",
        ".__dt_toolbar{display:flex;gap:2px;padding:4px 4px;background:#14141c;border-bottom:1px solid #23232f;align-items:center;flex-shrink:0;cursor:move;touch-action:none;border-top-left-radius:12px;border-top-right-radius:12px;user-select:none;-webkit-user-select:none;min-height:46px;position:relative}",
        ".__dt_root.__dt_maximized .__dt_toolbar{border-top-left-radius:0;border-top-right-radius:0}",
        ".__dt_grip{color:#5a6070;font-size:13px;padding:0 6px;flex-shrink:0;letter-spacing:-1px;line-height:1}",
        ".__dt_title{flex:1;min-width:0;font-size:12px;color:#9aa;padding:0 6px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;pointer-events:none}",
        ".__dt_winbtn{width:38px;height:38px;display:flex;align-items:center;justify-content:center;border-radius:8px;color:#cfd6e0;font-size:16px;cursor:pointer;flex-shrink:0;line-height:1;font-family:sans-serif;user-select:none;padding:0}",
        ".__dt_winbtn:active{background:rgba(255,255,255,.12)}",
        ".__dt_winbtn_close:active{background:rgba(220,40,40,.6)}",
        ".__dt_bar{display:flex;gap:2px;padding:6px 8px;background:#14141c;border-bottom:1px solid #23232f;overflow-x:auto;flex-shrink:0;-webkit-overflow-scrolling:touch}",
        ".__dt_bar::-webkit-scrollbar{height:3px}",
        ".__dt_bar::-webkit-scrollbar-thumb{background:#333;border-radius:2px}",
        ".__dt_tab{padding:7px 12px;border-radius:6px;cursor:pointer;white-space:nowrap;font-size:12px;color:#9aa;user-select:none;border:1px solid transparent;flex-shrink:0}",
        ".__dt_tab.on{background:#2979ff;color:#fff;border-color:#2979ff}",
        ".__dt_body{flex:1;overflow-y:auto;overflow-x:hidden;padding:8px 10px 12px;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:12px;-webkit-overflow-scrolling:touch;min-height:0;overscroll-behavior:contain}",
        ".__dt_body::-webkit-scrollbar{width:6px;height:6px}",
        ".__dt_body::-webkit-scrollbar-thumb{background:#333;border-radius:3px}",
        ".__dt_foot{display:flex;gap:6px;padding:8px;border-top:1px solid #23232f;background:#14141c;flex-shrink:0;flex-wrap:wrap;padding-bottom:calc(8px + env(safe-area-inset-bottom,0px))}",
        ".__dt_root.__dt_minimized .__dt_bar,.__dt_root.__dt_minimized .__dt_body,.__dt_root.__dt_minimized .__dt_foot,.__dt_root.__dt_minimized .__dt_resize{display:none}",
        ".__dt_btn{padding:7px 11px;border-radius:6px;background:#22222e;border:1px solid #2e2e3c;color:#e8e8ec;font-size:12px;cursor:pointer;user-select:none;white-space:nowrap;font-family:inherit}",
        ".__dt_btn:active{background:#2e2e3c}",
        ".__dt_btn.pri{background:#2979ff;border-color:#2979ff;color:#fff}",
        ".__dt_btn.dan{background:#c62828;border-color:#c62828;color:#fff}",
        ".__dt_input{flex:1;min-width:100px;padding:7px 10px;border-radius:6px;background:#050508;border:1px solid #2e2e3c;color:#e8e8ec;font:12px/1.2 ui-monospace,Menlo,monospace;outline:none;-webkit-appearance:none}",
        ".__dt_input:focus{border-color:#2979ff}",
        ".__dt_row{display:flex;gap:8px;padding:5px 6px;border-bottom:1px solid #1c1c26;align-items:flex-start;word-break:break-all}",
        ".__dt_time{color:#7a8090;flex-shrink:0;font-size:11px}",
        ".__dt_lv{flex-shrink:0;font-weight:600;font-size:11px;min-width:44px}",
        ".__dt_lv.log{color:#b8c0d0}",
        ".__dt_lv.info{color:#4fc3f7}",
        ".__dt_lv.warn{color:#ffb74d}",
        ".__dt_lv.error{color:#ff5252}",
        ".__dt_lv.debug{color:#9e9e9e}",
        ".__dt_msg{flex:1;white-space:pre-wrap;word-break:break-all;color:#e0e0e8;min-width:0}",
        ".__dt_msg.error{color:#ff8a80}",
        ".__dt_msg.warn{color:#ffd54f}",
        ".__dt_net{padding:7px 8px;border-bottom:1px solid #1c1c26;cursor:pointer}",
        ".__dt_net.sel{background:rgba(41,121,255,.15);border-left:3px solid #2979ff;padding-left:5px}",
        ".__dt_net_row{display:flex;gap:6px;align-items:center;font-size:12px;flex-wrap:nowrap}",
        ".__dt_net_m{font-weight:600;font-size:11px;color:#9aa;flex-shrink:0;min-width:42px}",
        ".__dt_net_u{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#cfd6e0;min-width:0}",
        ".__dt_net_s{font-weight:600;flex-shrink:0;min-width:36px;text-align:right;font-size:11px}",
        ".__dt_net_z{color:#7a8090;flex-shrink:0;font-size:10px}",
        ".__dt_st2{color:#4caf50}",
        ".__dt_st3{color:#ffb74d}",
        ".__dt_st4{color:#ff9800}",
        ".__dt_st5{color:#f44336}",
        ".__dt_st0{color:#9e9e9e}",
        ".__dt_type{font-size:9px;padding:1px 5px;border-radius:3px;background:#2a2a3a;color:#b0b8c8;flex-shrink:0;text-transform:uppercase;letter-spacing:.4px}",
        ".__dt_details{margin:6px 0 6px 6px;padding:8px 10px;background:#050508;border-radius:6px;border-left:3px solid #2979ff;font-size:11px}",
        ".__dt_kv{display:flex;gap:8px;padding:2px 0;align-items:flex-start}",
        ".__dt_k{color:#7a8090;min-width:80px;flex-shrink:0}",
        ".__dt_v{color:#e0e0e8;word-break:break-all;flex:1;min-width:0}",
        ".__dt_v a{color:#64b5f6;text-decoration:none;word-break:break-all}",
        ".__dt_section{margin:8px 0 14px}",
        ".__dt_sec_title{font-weight:600;color:#9ab;margin:0 0 8px;font-size:12px;padding-bottom:4px;border-bottom:1px solid #23232f;text-transform:uppercase;letter-spacing:.5px}",
        ".__dt_tree{font-family:ui-monospace,Menlo,monospace;font-size:11px;line-height:1.6}",
        ".__dt_tree_node{padding-left:12px}",
        ".__dt_tag{color:#f06292}",
        ".__dt_attr{color:#ffb74d}",
        ".__dt_attrval{color:#aed581}",
        ".__dt_text{color:#cfd6e0}",
        ".__dt_bar_chart{height:6px;background:#22222e;border-radius:3px;overflow:hidden;margin-top:4px}",
        ".__dt_bar_chart>div{height:100%;background:#2979ff;border-radius:3px}",
        ".__dt_empty{color:#6a7080;padding:20px;text-align:center;font-style:italic}",
        ".__dt_flex{display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin-bottom:8px}",
        ".__dt_metrics{display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:6px;margin:6px 0}",
        ".__dt_metric{background:#14141c;border:1px solid #23232f;border-radius:6px;padding:8px 10px}",
        ".__dt_metric_k{font-size:10px;color:#7a8090;text-transform:uppercase;letter-spacing:.4px;margin-bottom:3px}",
        ".__dt_metric_v{font-size:14px;color:#e8e8ec;font-weight:600;word-break:break-all}",
        ".__dt_metric_v.good{color:#4caf50}",
        ".__dt_metric_v.warn{color:#ffb74d}",
        ".__dt_metric_v.bad{color:#f44336}",
        ".__dt_code{background:#050508;border:1px solid #23232f;border-radius:6px;padding:8px 10px;font:11px/1.5 ui-monospace,Menlo,monospace;color:#cfd6e0;white-space:pre-wrap;word-break:break-all;max-height:300px;overflow:auto}",
        ".__dt_list{list-style:none;padding:0;margin:0}",
        ".__dt_list li{padding:6px 8px;border-bottom:1px solid #1c1c26;font-size:11px;display:flex;gap:6px;align-items:center;flex-wrap:wrap;word-break:break-all}",
        ".__dt_dim{color:#7a8090;font-size:11px}",
        ".__dt_hl{color:#64b5f6;word-break:break-all}",
        ".__dt_m3u_page{margin:10px 0 14px;border:1px solid #23232f;border-radius:8px;overflow:hidden}",
        ".__dt_m3u_head{padding:8px 10px;background:#14141c;border-bottom:1px solid #23232f}",
        ".__dt_m3u_title{font-weight:600;color:#e8e8ec;font-size:12px;margin-bottom:2px}",
        ".__dt_m3u_pageurl{font-size:11px;color:#7a8090;word-break:break-all}",
        ".__dt_m3u_item{padding:6px 10px;border-bottom:1px solid #1c1c26;display:flex;gap:6px;align-items:flex-start;flex-wrap:wrap}",
        ".__dt_m3u_item:last-child{border-bottom:0}",
        ".__dt_m3u_idx{color:#7a8090;font-size:11px;flex-shrink:0;min-width:22px}",
        ".__dt_m3u_url{color:#aed581;word-break:break-all;flex:1;font-size:11px;min-width:0}",
        ".__dt_m3u_btns{display:flex;gap:4px;flex-shrink:0}",
        ".__dt_mini_btn{padding:3px 8px;border-radius:5px;background:#22222e;border:1px solid #2e2e3c;color:#cfd6e0;font-size:10px;cursor:pointer;user-select:none;white-space:nowrap}",
        ".__dt_mini_btn:active{background:#2e2e3c}",
        ".__dt_resize{position:absolute;right:0;bottom:0;width:32px;height:32px;cursor:nwse-resize;z-index:5;touch-action:none;background:linear-gradient(135deg,transparent 48%,rgba(255,255,255,.14) 48%,rgba(255,255,255,.14) 56%,transparent 56%,transparent 64%,rgba(255,255,255,.14) 64%,rgba(255,255,255,.14) 72%,transparent 72%);border-bottom-right-radius:12px}",
        ".__dt_root.__dt_maximized .__dt_resize{display:none}"
    ].join("");

    function injectCSS() {
        if (document.getElementById("__dt_style")) return;
        var s = document.createElement("style");
        s.id = "__dt_style";
        s.textContent = CSS;
        (document.head || document.documentElement).appendChild(s);
    }

    function clearBody() { if (panelBody) panelBody.innerHTML = ""; }

    function renderConsole() {
        clearBody();
        var bar = el("div", "__dt_flex");
        var inp = el("input", "__dt_input");
        inp.type = "text";
        inp.placeholder = "フィルタ (テキスト / 正規表現)";
        inp.value = logFilter;
        inp.addEventListener("input", function () { logFilter = inp.value; scheduleLogPaint(); });
        bar.appendChild(inp);
        bar.appendChild(el("span", "__dt_dim", logs.length + " / " + MAX_LOG));
        panelBody.appendChild(bar);
        var list = el("div");
        list.id = "__dt_logs";
        panelBody.appendChild(list);
        paintConsole();
    }
    function paintConsole() {
        var list = document.getElementById("__dt_logs");
        if (!list) return;
        list.innerHTML = "";
        var q = logFilter.trim();
        var re = null;
        if (q) { try { re = new RegExp(q, "i"); } catch (e) { re = null; } }
        var shown = 0;
        for (var i = logs.length - 1; i >= 0; i--) {
            var lg = logs[i];
            if (q) {
                var ok = re ? (re.test(lg.text) || re.test(lg.level)) : (lg.text.toLowerCase().indexOf(q.toLowerCase()) >= 0 || lg.level.indexOf(q.toLowerCase()) >= 0);
                if (!ok) continue;
            }
            var row = el("div", "__dt_row");
            row.appendChild(el("span", "__dt_time", esc(tsOf(lg.t))));
            row.appendChild(el("span", "__dt_lv " + lg.level, lg.level.toUpperCase()));
            row.appendChild(el("span", "__dt_msg " + lg.level, esc(lg.text)));
            list.appendChild(row);
            shown++;
            if (shown >= 1500) break;
        }
        if (!shown) list.appendChild(el("div", "__dt_empty", logs.length ? "一致するログがありません" : "ログはまだありません"));
    }

    function renderNetwork() {
        clearBody();
        var bar = el("div", "__dt_flex");
        var inp = el("input", "__dt_input");
        inp.placeholder = "URL フィルタ";
        inp.value = netFilter;
        inp.addEventListener("input", function () { netFilter = inp.value; scheduleNetPaint(); });
        bar.appendChild(inp);
        panelBody.appendChild(bar);
        var tbar = el("div", "__dt_flex");
        ["all", "xhr", "fetch", "doc", "script", "css", "img", "media", "m3u", "font", "data", "other"].forEach(function (t) {
            var b = el("span", "__dt_btn" + (netTypeFilter === t ? " pri" : ""), t === "all" ? "すべて" : t);
            b.addEventListener("click", function () { netTypeFilter = t; renderNetwork(); });
            tbar.appendChild(b);
        });
        var clr = el("span", "__dt_btn dan", "クリア");
        clr.addEventListener("click", function () { nets.length = 0; netIndex = {}; paintNetwork(); });
        tbar.appendChild(clr);
        panelBody.appendChild(tbar);
        var sum = el("div", "__dt_dim");
        sum.id = "__dt_net_sum";
        sum.style.margin = "6px 0";
        panelBody.appendChild(sum);
        var list = el("div");
        list.id = "__dt_nets";
        panelBody.appendChild(list);
        paintNetwork();
    }
    function paintNetwork() {
        var list = document.getElementById("__dt_nets");
        var sum = document.getElementById("__dt_net_sum");
        if (!list) return;
        list.innerHTML = "";
        var totalSize = 0, totalTime = 0, shown = 0;
        var q = netFilter.toLowerCase();
        for (var i = nets.length - 1; i >= 0; i--) {
            var n = nets[i];
            if (netTypeFilter !== "all" && n.type !== netTypeFilter) continue;
            if (q && n.url.toLowerCase().indexOf(q) < 0 && (n.method || "").toLowerCase().indexOf(q) < 0) continue;
            shown++;
            totalSize += n.size || 0;
            totalTime += n.duration || 0;
            if (shown > 1500) continue;
            var row = el("div", "__dt_net" + (n._x ? " sel" : ""));
            var r1 = el("div", "__dt_net_row");
            r1.appendChild(el("span", "__dt_type", esc(n.type)));
            r1.appendChild(el("span", "__dt_net_m", esc(n.method || "GET")));
            var st = n.status || 0;
            var stCls = st >= 500 ? "__dt_st5" : st >= 400 ? "__dt_st4" : st >= 300 ? "__dt_st3" : st >= 200 ? "__dt_st2" : "__dt_st0";
            r1.appendChild(el("span", "__dt_net_s " + stCls, st ? String(st) : "-"));
            r1.appendChild(el("span", "__dt_net_u", esc(n.url)));
            r1.appendChild(el("span", "__dt_net_z", bytes(n.size)));
            row.appendChild(r1);
            var meta = el("div", "__dt_dim");
            meta.style.marginTop = "2px";
            meta.textContent = ms(n.duration) + " · " + (n.initiator || "-");
            row.appendChild(meta);
            (function (entry) {
                row.addEventListener("click", function () { entry._x = !entry._x; scheduleNetPaint(); });
            })(n);
            if (n._x) {
                var d = el("div", "__dt_details");
                d.appendChild(kv("URL", "<a href=\"" + esc(n.url) + "\" target=\"_blank\" rel=\"noopener\">" + esc(n.url) + "</a>"));
                d.appendChild(kv("Method", esc(n.method || "GET")));
                d.appendChild(kv("Status", st ? (st + " " + esc(n.statusText || "")) : "(pending/failed)"));
                d.appendChild(kv("Type", esc(n.type)));
                d.appendChild(kv("Initiator", esc(n.initiator || "-")));
                d.appendChild(kv("Size", bytes(n.size)));
                d.appendChild(kv("Duration", ms(n.duration)));
                var btns = el("div", "__dt_flex");
                btns.style.marginTop = "6px";
                var b1 = el("span", "__dt_btn", "URL コピー");
                b1.addEventListener("click", function (ev) { ev.stopPropagation(); toast(copyText(n.url) ? "コピーしました" : "失敗"); });
                var b2 = el("span", "__dt_btn", "全体コピー");
                b2.addEventListener("click", function (ev) {
                    ev.stopPropagation();
                    var t = "URL: " + n.url + "\nMethod: " + (n.method || "GET") + "\nType: " + n.type + "\nStatus: " + (n.status || 0) + "\nSize: " + bytes(n.size) + "\nDuration: " + ms(n.duration);
                    toast(copyText(t) ? "コピーしました" : "失敗");
                });
                var b3 = el("span", "__dt_btn", "開く");
                b3.addEventListener("click", function (ev) { ev.stopPropagation(); try { window.open(n.url, "_blank", "noopener"); } catch (e) {} });
                btns.appendChild(b1); btns.appendChild(b2); btns.appendChild(b3);
                d.appendChild(btns);
                row.appendChild(d);
            }
            list.appendChild(row);
        }
        if (sum) sum.textContent = shown + " 件 / " + bytes(totalSize) + " / " + ms(totalTime);
        if (!shown) list.appendChild(el("div", "__dt_empty", "通信はまだ記録されていません"));
    }

    function kv(k, v) {
        var r = el("div", "__dt_kv");
        r.appendChild(el("span", "__dt_k", esc(k)));
        r.appendChild(el("span", "__dt_v", v));
        return r;
    }

    function renderM3U() {
        clearBody();
        if (!m3uStore) m3uStore = m3uLoadStore();
        var bar = el("div", "__dt_flex");
        var inp = el("input", "__dt_input");
        inp.placeholder = "m3u URL フィルタ";
        inp.value = m3uFilter;
        inp.addEventListener("input", function () { m3uFilter = inp.value; scheduleM3UPaint(); });
        bar.appendChild(inp);
        panelBody.appendChild(bar);
        var btnBar = el("div", "__dt_flex");
        var bSave = el("span", "__dt_btn pri", "💾 全部保存");
        bSave.addEventListener("click", function () {
            var ok = m3uFlush();
            toast(ok ? ("保存: " + m3uStore.id + "m3u-url.txt") : "保存に失敗");
        });
        btnBar.appendChild(bSave);
        var bCopy = el("span", "__dt_btn", "📋 全部コピー");
        bCopy.addEventListener("click", function () {
            var text = m3uBuildText();
            toast(copyText(text) ? "コピーしました" : "失敗");
        });
        btnBar.appendChild(bCopy);
        var bClr = el("span", "__dt_btn dan", "🗑 リセット");
        bClr.addEventListener("click", function () {
            m3uReset();
            renderM3U();
            toast("m3u 記録をリセット");
        });
        btnBar.appendChild(bClr);
        panelBody.appendChild(btnBar);
        var stat = el("div", "__dt_dim");
        stat.style.margin = "6px 0";
        var total = m3uCount();
        var pageCount = 0;
        for (var k in m3uStore.pages) if (Object.prototype.hasOwnProperty.call(m3uStore.pages, k)) pageCount++;
        stat.textContent = "合計 " + total + " 件 / " + pageCount + " ページ (" + m3uStore.id + ")";
        panelBody.appendChild(stat);
        var list = el("div");
        list.id = "__dt_m3u_list";
        panelBody.appendChild(list);
        paintM3U();
    }
    function paintM3U() {
        var list = document.getElementById("__dt_m3u_list");
        if (!list) return;
        list.innerHTML = "";
        if (!m3uStore) m3uStore = m3uLoadStore();
        var q = m3uFilter.toLowerCase();
        var keys = [];
        for (var k in m3uStore.pages) if (Object.prototype.hasOwnProperty.call(m3uStore.pages, k)) keys.push(k);
        keys.sort();
        var shown = 0;
        for (var i = 0; i < keys.length; i++) {
            var key = keys[i];
            var page = m3uStore.pages[key];
            var arr = page.urls || [];
            if (!arr.length) continue;
            var filtered = [];
            for (var m = 0; m < arr.length; m++) {
                if (!q || arr[m].toLowerCase().indexOf(q) >= 0) filtered.push(arr[m]);
            }
            if (q && filtered.length === 0) continue;
            shown++;
            var wrap = el("div", "__dt_m3u_page");
            var head = el("div", "__dt_m3u_head");
            var titleEl = el("div", "__dt_m3u_title", esc(page.title || "(タイトルなし)"));
            head.appendChild(titleEl);
            head.appendChild(el("div", "__dt_m3u_pageurl", esc(key)));
            wrap.appendChild(head);
            var items = q ? filtered : arr;
            for (var j = 0; j < items.length; j++) {
                (function (url, idx) {
                    var item = el("div", "__dt_m3u_item");
                    item.appendChild(el("span", "__dt_m3u_idx", String(idx + 1) + "."));
                    var u = el("span", "__dt_m3u_url");
                    var a = document.createElement("a");
                    a.href = url;
                    a.target = "_blank";
                    a.rel = "noopener";
                    a.textContent = url;
                    a.style.color = "#aed581";
                    a.style.textDecoration = "none";
                    a.style.wordBreak = "break-all";
                    u.appendChild(a);
                    item.appendChild(u);
                    var bts = el("div", "__dt_m3u_btns");
                    var cp = el("span", "__dt_mini_btn", "コピー");
                    cp.addEventListener("click", function (ev) {
                        ev.stopPropagation();
                        ev.preventDefault();
                        toast(copyText(url) ? "コピーしました" : "失敗");
                    });
                    bts.appendChild(cp);
                    var op = el("span", "__dt_mini_btn", "開く");
                    op.addEventListener("click", function (ev) {
                        ev.stopPropagation();
                        try { window.open(url, "_blank", "noopener"); } catch (e) {}
                    });
                    bts.appendChild(op);
                    var dl = el("span", "__dt_mini_btn", "保存");
                    dl.addEventListener("click", function (ev) {
                        ev.stopPropagation();
                        var name = "m3u_" + stamp() + ".txt";
                        var ok = download(name, url + "\n");
                        toast(ok ? ("保存: " + name) : "失敗");
                    });
                    bts.appendChild(dl);
                    item.appendChild(bts);
                    wrap.appendChild(item);
                })(items[j], j);
            }
            list.appendChild(wrap);
        }
        if (!shown) list.appendChild(el("div", "__dt_empty", m3uFilter ? "一致する m3u がありません" : "m3u はまだ検出されていません"));
    }

    function renderElements() {
        clearBody();
        var head = el("div", "__dt_flex");
        head.appendChild(el("span", "__dt_dim", "総要素: " + document.getElementsByTagName("*").length));
        var cp = el("span", "__dt_btn", "HTML コピー");
        cp.addEventListener("click", function () { toast(copyText(document.documentElement.outerHTML) ? "コピーしました" : "失敗"); });
        head.appendChild(cp);
        panelBody.appendChild(head);
        var sec = el("div", "__dt_section");
        sec.appendChild(el("h3", "__dt_sec_title", "DOM ツリー"));
        var tree = el("div", "__dt_tree");
        try { tree.appendChild(buildTree(document.documentElement, 0, 6)); } catch (e) {}
        sec.appendChild(tree);
        panelBody.appendChild(sec);
    }
    function buildTree(node, depth, maxDepth) {
        var wrap = el("div", "__dt_tree_node");
        if (!node) return wrap;
        if (depth >= maxDepth) { wrap.appendChild(el("span", "__dt_dim", "…")); return wrap; }
        if (node.nodeType === 1) {
            var line = "<span class='__dt_tag'>&lt;" + esc(node.tagName.toLowerCase()) + "</span>";
            var attrs = node.attributes;
            if (attrs) {
                var lim = Math.min(attrs.length, 6);
                for (var i = 0; i < lim; i++) {
                    var a = attrs[i];
                    var val = String(a.value || "");
                    if (val.length > 60) val = val.slice(0, 60) + "…";
                    line += " <span class='__dt_attr'>" + esc(a.name) + "</span>=<span class='__dt_attrval'>\"" + esc(val) + "\"</span>";
                }
                if (attrs.length > lim) line += " <span class='__dt_dim'>+" + (attrs.length - lim) + "</span>";
            }
            line += "<span class='__dt_tag'>&gt;</span>";
            wrap.appendChild(el("div", null, line));
            var kids = node.childNodes;
            var shown = 0;
            for (var j = 0; j < kids.length; j++) {
                var k = kids[j];
                if (k.nodeType === 1) { wrap.appendChild(buildTree(k, depth + 1, maxDepth)); shown++; }
                else if (k.nodeType === 3) {
                    var t = (k.nodeValue || "").replace(/\s+/g, " ").trim();
                    if (t) {
                        var txt = el("div", "__dt_tree_node");
                        txt.appendChild(el("span", "__dt_text", esc(t.slice(0, 120) + (t.length > 120 ? "…" : ""))));
                        wrap.appendChild(txt);
                        shown++;
                    }
                }
                if (shown > 30 && depth > 2) {
                    var more = el("div", "__dt_tree_node");
                    more.appendChild(el("span", "__dt_dim", "… 他 " + (kids.length - j - 1)));
                    wrap.appendChild(more);
                    break;
                }
            }
        }
        return wrap;
    }

    function renderSources() {
        clearBody();
        var scripts = document.getElementsByTagName("script");
        var s1 = el("div", "__dt_section");
        s1.appendChild(el("h3", "__dt_sec_title", "スクリプト (" + scripts.length + ")"));
        var ul = el("ul", "__dt_list");
        for (var i = 0; i < scripts.length; i++) {
            (function (s) {
                var li = el("li");
                var src = s.src || "";
                li.appendChild(el("span", "__dt_type", src ? "src" : "inline"));
                li.appendChild(el("span", "__dt_hl", esc(src || ("(inline " + (s.textContent || "").length + " 文字)"))));
                if (src) {
                    var b1 = el("span", "__dt_btn", "コピー");
                    b1.addEventListener("click", function () { toast(copyText(src) ? "コピーしました" : "失敗"); });
                    li.appendChild(b1);
                    var b2 = el("span", "__dt_btn", "開く");
                    b2.addEventListener("click", function () { try { window.open(src, "_blank", "noopener"); } catch (e) {} });
                    li.appendChild(b2);
                } else {
                    var b3 = el("span", "__dt_btn", "内容コピー");
                    b3.addEventListener("click", function () { toast(copyText(s.textContent || "") ? "コピーしました" : "失敗"); });
                    li.appendChild(b3);
                }
                ul.appendChild(li);
            })(scripts[i]);
        }
        s1.appendChild(ul);
        panelBody.appendChild(s1);
        var sheets = document.styleSheets;
        var s2 = el("div", "__dt_section");
        s2.appendChild(el("h3", "__dt_sec_title", "スタイルシート (" + sheets.length + ")"));
        var ul2 = el("ul", "__dt_list");
        for (var k = 0; k < sheets.length; k++) {
            (function (sh) {
                var li = el("li");
                var href = sh.href || "(inline)";
                li.appendChild(el("span", "__dt_type", sh.href ? "link" : "style"));
                li.appendChild(el("span", "__dt_hl", esc(href)));
                var c = 0;
                try { c = sh.cssRules ? sh.cssRules.length : 0; } catch (e) { c = -1; }
                li.appendChild(el("span", "__dt_dim", c >= 0 ? (c + " ルール") : "(クロス)"));
                if (sh.href) {
                    var b1 = el("span", "__dt_btn", "コピー");
                    b1.addEventListener("click", function () { toast(copyText(sh.href) ? "コピーしました" : "失敗"); });
                    li.appendChild(b1);
                }
                ul2.appendChild(li);
            })(sheets[k]);
        }
        s2.appendChild(ul2);
        panelBody.appendChild(s2);
    }

    function safeStorage(getter) {
        var out = [];
        try {
            var s = getter();
            if (!s) return out;
            for (var i = 0; i < s.length; i++) {
                var k = s.key(i);
                out.push([k, s.getItem(k)]);
            }
        } catch (e) {}
        return out;
    }
    function storageSection(name, pairs) {
        var sec = el("div", "__dt_section");
        sec.appendChild(el("h3", "__dt_sec_title", name + " (" + pairs.length + ")"));
        if (!pairs.length) { sec.appendChild(el("div", "__dt_empty", "空です")); return sec; }
        var ul = el("ul", "__dt_list");
        pairs.forEach(function (p) {
            var li = el("li");
            li.appendChild(el("span", "__dt_hl", esc(p[0])));
            var v = String(p[1] == null ? "" : p[1]);
            li.appendChild(el("span", "__dt_dim", esc(v.length > 120 ? v.slice(0, 120) + "…" : v)));
            var cp = el("span", "__dt_btn", "コピー");
            cp.addEventListener("click", function () { toast(copyText(p[0] + "=" + p[1]) ? "コピーしました" : "失敗"); });
            li.appendChild(cp);
            ul.appendChild(li);
        });
        sec.appendChild(ul);
        return sec;
    }
    function cookieSection() {
        var sec = el("div", "__dt_section");
        var raw = "";
        try { raw = document.cookie || ""; } catch (e) { raw = ""; }
        var items = raw ? raw.split(/;\s*/) : [];
        sec.appendChild(el("h3", "__dt_sec_title", "Cookies (" + items.length + ")"));
        if (!items.length) { sec.appendChild(el("div", "__dt_empty", "Cookie はありません")); return sec; }
        var ul = el("ul", "__dt_list");
        items.forEach(function (c) {
            var li = el("li");
            li.appendChild(el("span", "__dt_hl", esc(c)));
            var cp = el("span", "__dt_btn", "コピー");
            cp.addEventListener("click", function () { toast(copyText(c) ? "コピーしました" : "失敗"); });
            li.appendChild(cp);
            ul.appendChild(li);
        });
        sec.appendChild(ul);
        return sec;
    }
    function simpleLI(k, v) {
        var li = el("li");
        li.appendChild(el("span", "__dt_hl", esc(k)));
        li.appendChild(el("span", null, esc(v)));
        return li;
    }
    function renderApplication() {
        clearBody();
        panelBody.appendChild(storageSection("Local Storage", safeStorage(function () { return window.localStorage; })));
        panelBody.appendChild(storageSection("Session Storage", safeStorage(function () { return window.sessionStorage; })));
        panelBody.appendChild(cookieSection());
        var sec = el("div", "__dt_section");
        sec.appendChild(el("h3", "__dt_sec_title", "情報"));
        var ul = el("ul", "__dt_list");
        ul.appendChild(simpleLI("cookieEnabled", String(navigator.cookieEnabled)));
        ul.appendChild(simpleLI("onLine", String(navigator.onLine)));
        ul.appendChild(simpleLI("language", String(navigator.language || "-")));
        ul.appendChild(simpleLI("platform", String(navigator.platform || "-")));
        sec.appendChild(ul);
        panelBody.appendChild(sec);
    }

    function metric(k, v, cls) {
        var d = el("div", "__dt_metric");
        d.appendChild(el("div", "__dt_metric_k", esc(k)));
        d.appendChild(el("div", "__dt_metric_v " + (cls || ""), esc(v)));
        return d;
    }
    function renderPerformance() {
        clearBody();
        var nav = null;
        try { nav = performance.getEntriesByType("navigation")[0]; } catch (e) {}
        var paint = [];
        try { paint = performance.getEntriesByType("paint"); } catch (e) {}
        var res = [];
        try { res = performance.getEntriesByType("resource"); } catch (e) {}
        var m = el("div", "__dt_metrics");
        if (nav) {
            var ttfb = nav.responseStart - nav.requestStart;
            m.appendChild(metric("TTFB", ms(ttfb), ttfb < 200 ? "good" : ttfb < 600 ? "warn" : "bad"));
            m.appendChild(metric("DCL", ms(nav.domContentLoadedEventEnd - nav.startTime)));
            m.appendChild(metric("Load", ms(nav.loadEventEnd - nav.startTime)));
            m.appendChild(metric("Transfer", bytes(nav.transferSize)));
        }
        paint.forEach(function (p) {
            var cls = p.startTime < 1800 ? "good" : p.startTime < 3000 ? "warn" : "bad";
            m.appendChild(metric(p.name.replace(/^first-/, "First "), ms(p.startTime), cls));
        });
        panelBody.appendChild(m);
        var s1 = el("div", "__dt_section");
        s1.appendChild(el("h3", "__dt_sec_title", "ナビゲーション"));
        if (nav) {
            var box = el("div", "__dt_code");
            box.textContent = [
                "startTime: " + ms(nav.startTime),
                "responseStart: " + ms(nav.responseStart),
                "responseEnd: " + ms(nav.responseEnd),
                "domInteractive: " + ms(nav.domInteractive),
                "domContentLoaded: " + ms(nav.domContentLoadedEventEnd),
                "loadEventEnd: " + ms(nav.loadEventEnd)
            ].join("\n");
            s1.appendChild(box);
        } else s1.appendChild(el("div", "__dt_empty", "情報なし"));
        panelBody.appendChild(s1);
        var s2 = el("div", "__dt_section");
        s2.appendChild(el("h3", "__dt_sec_title", "リソース (" + res.length + ")"));
        var byType = {};
        var total = 0;
        res.forEach(function (r) {
            var t = r.initiatorType || "other";
            if (!byType[t]) byType[t] = { n: 0, s: 0 };
            byType[t].n++;
            byType[t].s += r.transferSize || 0;
            total += r.transferSize || 0;
        });
        var arr = Object.keys(byType).map(function (k) { return [k, byType[k]]; });
        arr.sort(function (a, b) { return b[1].s - a[1].s; });
        if (!arr.length) s2.appendChild(el("div", "__dt_empty", "リソースなし"));
        arr.forEach(function (pair) {
            var r = el("div");
            r.style.margin = "6px 0";
            r.appendChild(el("div", "__dt_dim", pair[0] + " · " + pair[1].n + " 件 · " + bytes(pair[1].s)));
            var chart = el("div", "__dt_bar_chart");
            var fill = el("div");
            fill.style.width = total ? Math.max(2, (pair[1].s / total) * 100) + "%" : "0%";
            chart.appendChild(fill);
            r.appendChild(chart);
            s2.appendChild(r);
        });
        panelBody.appendChild(s2);
    }

    function policyRow(label, ok) {
        var li = el("li");
        var s = el("span", null, (ok ? "✓ " : "✗ ") + label);
        s.style.color = ok ? "#4caf50" : "#f44336";
        s.style.fontWeight = "600";
        li.appendChild(s);
        return li;
    }
    function renderSecurity() {
        clearBody();
        var secure = window.isSecureContext;
        var m = el("div", "__dt_metrics");
        m.appendChild(metric("Secure Context", secure ? "はい" : "いいえ", secure ? "good" : "bad"));
        m.appendChild(metric("Protocol", location.protocol, location.protocol === "https:" ? "good" : "warn"));
        m.appendChild(metric("Host", location.hostname));
        m.appendChild(metric("Origin", location.origin));
        panelBody.appendChild(m);
        var sec = el("div", "__dt_section");
        sec.appendChild(el("h3", "__dt_sec_title", "セキュリティ"));
        var ul = el("ul", "__dt_list");
        ul.appendChild(policyRow("HTTPS", location.protocol === "https:"));
        ul.appendChild(policyRow("Secure Context", !!secure));
        ul.appendChild(policyRow("CSP (meta)", !!document.querySelector("meta[http-equiv='Content-Security-Policy']")));
        ul.appendChild(policyRow("Service Worker", !!navigator.serviceWorker));
        ul.appendChild(policyRow("SubtleCrypto", !!(window.crypto && window.crypto.subtle)));
        ul.appendChild(policyRow("Permissions API", !!navigator.permissions));
        ul.appendChild(policyRow("WebAuthn", !!(window.PublicKeyCredential)));
        ul.appendChild(policyRow("WebGL", !!(window.WebGLRenderingContext)));
        sec.appendChild(ul);
        panelBody.appendChild(sec);
    }

    function renderMemory() {
        clearBody();
        var m = el("div", "__dt_metrics");
        var mem = performance.memory;
        if (mem) {
            var used = mem.usedJSHeapSize, tot = mem.totalJSHeapSize;
            var ratio = tot ? used / tot : 0;
            m.appendChild(metric("JS Heap 使用", bytes(used), ratio > 0.9 ? "bad" : ratio > 0.7 ? "warn" : "good"));
            m.appendChild(metric("JS Heap 総量", bytes(tot)));
            m.appendChild(metric("上限", bytes(mem.jsHeapSizeLimit)));
            m.appendChild(metric("使用率", (ratio * 100).toFixed(1) + "%"));
        } else m.appendChild(metric("JS Heap", "取得不可"));
        panelBody.appendChild(m);
        var sec = el("div", "__dt_section");
        sec.appendChild(el("h3", "__dt_sec_title", "カウント"));
        var ul = el("ul", "__dt_list");
        ul.appendChild(simpleLI("DOM 要素", String(document.getElementsByTagName("*").length)));
        ul.appendChild(simpleLI("script", String(document.scripts.length)));
        ul.appendChild(simpleLI("link", String(document.getElementsByTagName("link").length)));
        ul.appendChild(simpleLI("img", String(document.images.length)));
        ul.appendChild(simpleLI("iframe", String(document.getElementsByTagName("iframe").length)));
        ul.appendChild(simpleLI("form", String(document.forms.length)));
        ul.appendChild(simpleLI("a", String(document.getElementsByTagName("a").length)));
        ul.appendChild(simpleLI("ログ件数", String(logs.length)));
        ul.appendChild(simpleLI("通信件数", String(nets.length)));
        ul.appendChild(simpleLI("m3u 件数", String(m3uCount())));
        sec.appendChild(ul);
        panelBody.appendChild(sec);
    }

    function renderInfo() {
        clearBody();
        var s1 = el("div", "__dt_section");
        s1.appendChild(el("h3", "__dt_sec_title", "ページ"));
        var ul = el("ul", "__dt_list");
        ul.appendChild(simpleLI("URL", location.href));
        ul.appendChild(simpleLI("Title", document.title));
        ul.appendChild(simpleLI("Referrer", document.referrer || "(なし)"));
        ul.appendChild(simpleLI("Origin", location.origin));
        ul.appendChild(simpleLI("Host", location.host));
        ul.appendChild(simpleLI("Pathname", location.pathname));
        ul.appendChild(simpleLI("Search", location.search || "(なし)"));
        ul.appendChild(simpleLI("Hash", location.hash || "(なし)"));
        s1.appendChild(ul);
        panelBody.appendChild(s1);
        var s2 = el("div", "__dt_section");
        s2.appendChild(el("h3", "__dt_sec_title", "画面"));
        var ul2 = el("ul", "__dt_list");
        ul2.appendChild(simpleLI("Viewport", window.innerWidth + " × " + window.innerHeight));
        ul2.appendChild(simpleLI("Screen", screen.width + " × " + screen.height));
        ul2.appendChild(simpleLI("DPR", String(window.devicePixelRatio)));
        ul2.appendChild(simpleLI("Orientation", (screen.orientation && screen.orientation.type) || "-"));
        s2.appendChild(ul2);
        panelBody.appendChild(s2);
        var s3 = el("div", "__dt_section");
        s3.appendChild(el("h3", "__dt_sec_title", "環境"));
        var ul3 = el("ul", "__dt_list");
        ul3.appendChild(simpleLI("UA", navigator.userAgent));
        ul3.appendChild(simpleLI("Platform", navigator.platform || "-"));
        ul3.appendChild(simpleLI("Language", navigator.language || "-"));
        ul3.appendChild(simpleLI("Languages", (navigator.languages || []).join(", ")));
        ul3.appendChild(simpleLI("Online", String(navigator.onLine)));
        ul3.appendChild(simpleLI("CPU", String(navigator.hardwareConcurrency || "-")));
        ul3.appendChild(simpleLI("Memory", (navigator.deviceMemory || "-") + " GB"));
        ul3.appendChild(simpleLI("Touch", String(navigator.maxTouchPoints || 0)));
        try { ul3.appendChild(simpleLI("Timezone", Intl.DateTimeFormat().resolvedOptions().timeZone)); } catch (e) {}
        s3.appendChild(ul3);
        panelBody.appendChild(s3);
    }

    var TABS = [
        { id: "console", label: "Console" },
        { id: "network", label: "Network" },
        { id: "m3u", label: "M3U" },
        { id: "elements", label: "Elements" },
        { id: "sources", label: "Sources" },
        { id: "application", label: "Application" },
        { id: "performance", label: "Performance" },
        { id: "security", label: "Security" },
        { id: "memory", label: "Memory" },
        { id: "info", label: "Info" }
    ];

    function renderActive() {
        if (!panelOpen || !panelBody) return;
        if (activeTab === "console") renderConsole();
        else if (activeTab === "network") renderNetwork();
        else if (activeTab === "m3u") renderM3U();
        else if (activeTab === "elements") renderElements();
        else if (activeTab === "sources") renderSources();
        else if (activeTab === "application") renderApplication();
        else if (activeTab === "performance") renderPerformance();
        else if (activeTab === "security") renderSecurity();
        else if (activeTab === "memory") renderMemory();
        else if (activeTab === "info") renderInfo();
    }

    function defaultWin() {
        var vw = window.innerWidth || 360;
        var vh = window.innerHeight || 640;
        var w = Math.min(vw - 8, 560);
        var h = Math.min(Math.round(vh * 0.64), 760);
        if (w < MIN_W) w = MIN_W;
        if (h < MIN_H) h = MIN_H;
        win.x = Math.max(4, Math.round((vw - w) / 2));
        win.y = Math.max(4, vh - h - 4);
        win.w = w;
        win.h = h;
        win.maximized = false;
        win.minimized = false;
    }
    function clampWin() {
        var vw = window.innerWidth || 360;
        var vh = window.innerHeight || 640;
        if (!win.w || win.w < MIN_W) win.w = MIN_W;
        if (!win.h || win.h < MIN_H) win.h = MIN_H;
        if (win.w > vw) win.w = vw;
        if (win.h > vh) win.h = vh;
        if (win.x < 0) win.x = 0;
        if (win.y < 0) win.y = 0;
        if (win.x + win.w > vw) win.x = vw - win.w;
        if (win.y + win.h > vh) win.y = vh - win.h;
        if (win.x < 0) win.x = 0;
        if (win.y < 0) win.y = 0;
    }
    function loadWin() {
        if (winLoaded) return;
        winLoaded = true;
        var raw = null;
        try {
            if (hasCoara() && coara.storage && typeof coara.storage.get === "function") raw = coara.storage.get(WIN_KEY);
        } catch (e) {}
        if (!raw) { try { raw = localStorage.getItem(WIN_KEY); } catch (e) {} }
        if (raw) {
            try {
                var o = JSON.parse(raw);
                if (o && typeof o === "object") {
                    if (typeof o.x === "number") win.x = o.x;
                    if (typeof o.y === "number") win.y = o.y;
                    if (typeof o.w === "number") win.w = o.w;
                    if (typeof o.h === "number") win.h = o.h;
                    win.maximized = !!o.maximized;
                    win.minimized = !!o.minimized;
                }
            } catch (e) {}
        }
        if (!win.w || !win.h) defaultWin();
        clampWin();
    }
    function saveWin() {
        var text = JSON.stringify(win);
        var ok = false;
        try {
            if (hasCoara() && coara.storage && typeof coara.storage.set === "function") {
                ok = coara.storage.set(WIN_KEY, text) === true;
            }
        } catch (e) { ok = false; }
        if (!ok) { try { localStorage.setItem(WIN_KEY, text); } catch (e) {} }
    }
    function applyWin() {
        if (!panelRoot) return;
        var vw = window.innerWidth || 360;
        var vh = window.innerHeight || 640;
        if (win.maximized) {
            panelRoot.classList.add("__dt_maximized");
            panelRoot.style.left = "0px";
            panelRoot.style.top = "0px";
            panelRoot.style.width = vw + "px";
            panelRoot.style.height = vh + "px";
        } else {
            panelRoot.classList.remove("__dt_maximized");
            if (win.x + win.w > vw) win.x = vw - win.w;
            if (win.y + win.h > vh) win.y = vh - win.h;
            if (win.x < 0) win.x = 0;
            if (win.y < 0) win.y = 0;
            panelRoot.style.left = win.x + "px";
            panelRoot.style.top = win.y + "px";
            panelRoot.style.width = win.w + "px";
            panelRoot.style.height = (win.minimized ? TOOLBAR_H : win.h) + "px";
        }
        if (win.minimized) panelRoot.classList.add("__dt_minimized");
        else panelRoot.classList.remove("__dt_minimized");
    }
    function scheduleWinApply() {
        if (winApplyRaf) return;
        winApplyRaf = requestAnimationFrame(function () { winApplyRaf = 0; applyWin(); });
    }

    function defaultFab() {
        var vw = window.innerWidth || 360;
        var vh = window.innerHeight || 640;
        fab.x = vw - FAB_SIZE - 12;
        fab.y = vh - FAB_SIZE - 88;
    }
    function clampFab() {
        var vw = window.innerWidth || 360;
        var vh = window.innerHeight || 640;
        if (fab.x == null) fab.x = vw - FAB_SIZE - 12;
        if (fab.y == null) fab.y = vh - FAB_SIZE - 88;
        if (fab.x < 0) fab.x = 0;
        if (fab.y < 0) fab.y = 0;
        if (fab.x + FAB_SIZE > vw) fab.x = vw - FAB_SIZE;
        if (fab.y + FAB_SIZE > vh) fab.y = vh - FAB_SIZE;
        if (fab.x < 0) fab.x = 0;
        if (fab.y < 0) fab.y = 0;
    }
    function loadFab() {
        if (fabLoaded) return;
        fabLoaded = true;
        var raw = null;
        try {
            if (hasCoara() && coara.storage && typeof coara.storage.get === "function") raw = coara.storage.get(FAB_KEY);
        } catch (e) {}
        if (!raw) { try { raw = localStorage.getItem(FAB_KEY); } catch (e) {} }
        if (raw) {
            try {
                var o = JSON.parse(raw);
                if (o && typeof o === "object") {
                    if (typeof o.x === "number") fab.x = o.x;
                    if (typeof o.y === "number") fab.y = o.y;
                }
            } catch (e) {}
        }
        clampFab();
    }
    function saveFab() {
        var text = JSON.stringify({ x: Math.round(fab.x), y: Math.round(fab.y) });
        var ok = false;
        try {
            if (hasCoara() && coara.storage && typeof coara.storage.set === "function") {
                ok = coara.storage.set(FAB_KEY, text) === true;
            }
        } catch (e) { ok = false; }
        if (!ok) { try { localStorage.setItem(FAB_KEY, text); } catch (e) {} }
    }
    function applyFab() {
        if (!fabEl) return;
        var vw = window.innerWidth || 360;
        var vh = window.innerHeight || 640;
        if (fab.x == null || fab.y == null) defaultFab();
        if (fab.x < 0) fab.x = 0;
        if (fab.y < 0) fab.y = 0;
        if (fab.x + FAB_SIZE > vw) fab.x = vw - FAB_SIZE;
        if (fab.y + FAB_SIZE > vh) fab.y = vh - FAB_SIZE;
        if (fab.x < 0) fab.x = 0;
        if (fab.y < 0) fab.y = 0;
        fabEl.style.left = Math.round(fab.x) + "px";
        fabEl.style.top = Math.round(fab.y) + "px";
    }

    function bindTap(elem, handler) {
        var touched = false;
        elem.addEventListener("touchstart", function (ev) { touched = true; ev.stopPropagation(); }, { passive: true });
        elem.addEventListener("touchend", function (ev) {
            ev.stopPropagation();
            if (ev.cancelable) ev.preventDefault();
            if (touched) handler(ev);
            setTimeout(function () { touched = false; }, 400);
        }, { passive: false });
        elem.addEventListener("click", function (ev) {
            if (touched) return;
            ev.stopPropagation();
            if (ev.cancelable) ev.preventDefault();
            handler(ev);
        });
    }
    function makeDraggable(handle, onStart, onMove, onEnd, noDragSelector) {
        var active = false;
        var sx = 0, sy = 0;
        function isNoDrag(target) {
            if (!noDragSelector || !target || !target.closest) return false;
            try { return !!target.closest(noDragSelector); } catch (e) { return false; }
        }
        function start(ev) {
            if (active) return;
            if (isNoDrag(ev.target)) return;
            var t = ev.touches ? ev.touches[0] : ev;
            if (!t) return;
            active = true;
            sx = t.clientX;
            sy = t.clientY;
            if (onStart) onStart(sx, sy);
            document.addEventListener("touchmove", move, { passive: false });
            document.addEventListener("touchend", end, { passive: false });
            document.addEventListener("touchcancel", end, { passive: false });
            document.addEventListener("mousemove", move);
            document.addEventListener("mouseup", end);
            if (ev.cancelable) ev.preventDefault();
            ev.stopPropagation();
        }
        function move(ev) {
            if (!active) return;
            var t = ev.touches ? ev.touches[0] : ev;
            if (!t) return;
            onMove(t.clientX - sx, t.clientY - sy, t.clientX, t.clientY);
            if (ev.cancelable) ev.preventDefault();
            ev.stopPropagation();
        }
        function end(ev) {
            if (!active) return;
            active = false;
            document.removeEventListener("touchmove", move);
            document.removeEventListener("touchend", end);
            document.removeEventListener("touchcancel", end);
            document.removeEventListener("mousemove", move);
            document.removeEventListener("mouseup", end);
            if (onEnd) onEnd();
            if (ev && ev.cancelable) ev.preventDefault();
            if (ev) ev.stopPropagation();
        }
        handle.addEventListener("touchstart", start, { passive: false });
        handle.addEventListener("mousedown", start);
    }

    function makeFabDraggable(elem) {
        var active = false;
        var dragged = false;
        var sx = 0, sy = 0;
        var startX = 0, startY = 0;

        function start(ev) {
            if (active) return;
            var t = ev.touches ? ev.touches[0] : ev;
            if (!t) return;
            active = true;
            dragged = false;
            sx = t.clientX;
            sy = t.clientY;
            startX = fab.x != null ? fab.x : 0;
            startY = fab.y != null ? fab.y : 0;
            document.addEventListener("touchmove", move, { passive: false });
            document.addEventListener("touchend", end, { passive: false });
            document.addEventListener("touchcancel", end, { passive: false });
            document.addEventListener("mousemove", move);
            document.addEventListener("mouseup", end);
            if (ev.cancelable) ev.preventDefault();
            ev.stopPropagation();
        }
        function move(ev) {
            if (!active) return;
            var t = ev.touches ? ev.touches[0] : ev;
            if (!t) return;
            var dx = t.clientX - sx;
            var dy = t.clientY - sy;
            if (!dragged && Math.abs(dx) + Math.abs(dy) < FAB_DRAG_THRESHOLD) {
                if (ev.cancelable) ev.preventDefault();
                ev.stopPropagation();
                return;
            }
            if (!dragged) {
                dragged = true;
                if (elem) elem.classList.add("__dt_fab_dragging");
            }
            fab.x = startX + dx;
            fab.y = startY + dy;
            clampFab();
            applyFab();
            if (ev.cancelable) ev.preventDefault();
            ev.stopPropagation();
        }
        function end(ev) {
            if (!active) return;
            active = false;
            document.removeEventListener("touchmove", move);
            document.removeEventListener("touchend", end);
            document.removeEventListener("touchcancel", end);
            document.removeEventListener("mousemove", move);
            document.removeEventListener("mouseup", end);
            if (elem) elem.classList.remove("__dt_fab_dragging");
            if (dragged) {
                saveFab();
            } else {
                togglePanel();
            }
            if (ev && ev.cancelable) ev.preventDefault();
            if (ev) ev.stopPropagation();
        }
        elem.addEventListener("touchstart", start, { passive: false });
        elem.addEventListener("mousedown", start);
        elem.addEventListener("click", function (ev) {
            ev.stopPropagation();
            if (ev.cancelable) ev.preventDefault();
        });
    }

    function toggleMin() {
        if (win.maximized) win.maximized = false;
        win.minimized = !win.minimized;
        applyWin();
        saveWin();
    }
    function toggleMax() {
        if (win.minimized) win.minimized = false;
        win.maximized = !win.maximized;
        applyWin();
        saveWin();
    }

    function buildPanel() {
        injectCSS();
        loadWin();
        panelRoot = el("div", "__dt_root");

        toolbarEl = el("div", "__dt_toolbar");
        toolbarEl.appendChild(el("div", "__dt_grip", "⋮⋮"));

        var titleEl = el("div", "__dt_title");
        var tstr = "";
        try {
            tstr = location.hostname || "";
            if (location.pathname && location.pathname !== "/") tstr += location.pathname;
            if (tstr.length > 60) tstr = tstr.slice(0, 60) + "…";
        } catch (e) {}
        if (!tstr) tstr = TITLE;
        titleEl.textContent = tstr;
        toolbarEl.appendChild(titleEl);

        var btnReload = el("div", "__dt_winbtn", "⟳");
        btnReload.setAttribute("aria-label", "再読み込み");
        bindTap(btnReload, function () {
            toast("再読み込み中…");
            setTimeout(function () { try { location.reload(); } catch (e) {} }, 60);
        });
        toolbarEl.appendChild(btnReload);

        var btnMin = el("div", "__dt_winbtn", "🗕");
        btnMin.setAttribute("aria-label", "最小化");
        bindTap(btnMin, function () { toggleMin(); });
        toolbarEl.appendChild(btnMin);

        var btnMax = el("div", "__dt_winbtn", "🗖");
        btnMax.setAttribute("aria-label", "最大化");
        bindTap(btnMax, function () { toggleMax(); });
        toolbarEl.appendChild(btnMax);

        var btnClose = el("div", "__dt_winbtn __dt_winbtn_close", "✕");
        btnClose.setAttribute("aria-label", "閉じる");
        bindTap(btnClose, function () { closePanel(); });
        toolbarEl.appendChild(btnClose);

        var dragStartX = 0, dragStartY = 0;
        makeDraggable(toolbarEl,
            function () { dragStartX = win.x; dragStartY = win.y; },
            function (dx, dy) {
                if (win.maximized) return;
                win.x = dragStartX + dx;
                win.y = dragStartY + dy;
                clampWin();
                scheduleWinApply();
            },
            function () { saveWin(); },
            ".__dt_winbtn"
        );

        panelRoot.appendChild(toolbarEl);

        var tabBar = el("div", "__dt_bar");
        TABS.forEach(function (t) {
            var tab = el("div", "__dt_tab" + (activeTab === t.id ? " on" : ""), esc(t.label));
            bindTap(tab, function () {
                activeTab = t.id;
                var kids = tabBar.querySelectorAll(".__dt_tab");
                for (var i = 0; i < kids.length; i++) kids[i].classList.remove("on");
                tab.classList.add("on");
                renderActive();
            });
            tabBar.appendChild(tab);
        });
        panelRoot.appendChild(tabBar);

        panelBody = el("div", "__dt_body");
        panelRoot.appendChild(panelBody);

        var foot = el("div", "__dt_foot");
        var bSave = el("span", "__dt_btn pri", "💾 保存");
        bindTap(bSave, function () { saveAll(); });
        var bNet = el("span", "__dt_btn", "🌐 通信");
        bindTap(bNet, function () { saveNetwork(); });
        var bM3u = el("span", "__dt_btn", "🎬 m3u 保存");
        bindTap(bM3u, function () {
            var ok = m3uFlush();
            toast(ok ? ("m3u 保存: " + m3uStore.id + "m3u-url.txt") : "m3u 保存に失敗");
        });
        var bCopy = el("span", "__dt_btn", "📋 コピー");
        bindTap(bCopy, function () { copyCurrent(); });
        var bUrl = el("span", "__dt_btn", "🔗 URL");
        bindTap(bUrl, function () { toast(copyText(location.href) ? "URL コピー" : "失敗"); });
        var bClr = el("span", "__dt_btn dan", "🗑 クリア");
        bindTap(bClr, function () {
            if (activeTab === "console") logs.length = 0;
            else if (activeTab === "network") { nets.length = 0; netIndex = {}; }
            else if (activeTab === "m3u") m3uReset();
            renderActive();
            toast("クリアしました");
        });
        var bClose = el("span", "__dt_btn", "閉じる");
        bindTap(bClose, function () { closePanel(); });
        foot.appendChild(bSave);
        foot.appendChild(bNet);
        foot.appendChild(bM3u);
        foot.appendChild(bCopy);
        foot.appendChild(bUrl);
        foot.appendChild(bClr);
        foot.appendChild(bClose);
        panelRoot.appendChild(foot);

        var rz = el("div", "__dt_resize");
        var rzStartW = 0, rzStartH = 0;
        makeDraggable(rz,
            function () { rzStartW = win.w; rzStartH = win.h; },
            function (dx, dy) {
                if (win.maximized || win.minimized) return;
                win.w = Math.max(MIN_W, rzStartW + dx);
                win.h = Math.max(MIN_H, rzStartH + dy);
                clampWin();
                scheduleWinApply();
            },
            function () { saveWin(); }
        );
        panelRoot.appendChild(rz);

        (document.body || document.documentElement).appendChild(panelRoot);
        panelOpen = true;
        applyWin();
        renderActive();
        if (fabEl) fabEl.style.display = "none";
    }

    function openPanel() {
        if (panelOpen) return;
        try { buildPanel(); }
        catch (e) { toast("パネル表示に失敗: " + (e && e.message ? e.message : e)); }
    }
    function closePanel() {
        if (!panelOpen) return;
        try { if (panelRoot && panelRoot.parentNode) panelRoot.parentNode.removeChild(panelRoot); } catch (e) {}
        panelRoot = null;
        panelBody = null;
        toolbarEl = null;
        panelOpen = false;
        if (fabEl) {
            fabEl.style.display = "";
            applyFab();
        }
    }
    function togglePanel() { if (panelOpen) closePanel(); else openPanel(); }

    function saveAll() {
        var lines = [];
        lines.push("=== DevTools Snapshot ===");
        lines.push("Saved: " + new Date().toString());
        lines.push("URL: " + location.href);
        lines.push("Title: " + document.title);
        lines.push("UA: " + navigator.userAgent);
        lines.push("");
        lines.push("=== Console (" + logs.length + ") ===");
        logs.forEach(function (lg) { lines.push("[" + tsOf(lg.t) + "] " + lg.level.toUpperCase() + ": " + lg.text); });
        lines.push("");
        lines.push("=== Network (" + nets.length + ") ===");
        nets.forEach(function (n) {
            lines.push("[" + (n.method || "GET") + " " + (n.status || 0) + "] " + n.url + " | " + n.type + " | " + bytes(n.size) + " | " + ms(n.duration));
        });
        lines.push("");
        lines.push("=== M3U ===");
        lines.push(m3uBuildText());
        var name = "devtools_" + stamp() + ".txt";
        var ok = download(name, lines.join("\n"));
        toast(ok ? ("保存: " + name) : "保存に失敗");
    }
    function saveNetwork() {
        var lines = [];
        lines.push("# Network Log");
        lines.push("# Page: " + location.href);
        lines.push("# Title: " + document.title);
        lines.push("# Saved: " + new Date().toString());
        lines.push("# Count: " + nets.length);
        lines.push("");
        for (var i = 0; i < nets.length; i++) {
            var n = nets[i];
            lines.push("[" + (n.method || "GET") + " " + (n.status || 0) + "] " + n.url);
            lines.push("    type=" + n.type + " initiator=" + (n.initiator || "-") + " size=" + bytes(n.size) + " duration=" + ms(n.duration));
        }
        var name = "network_" + stamp() + ".txt";
        var ok = download(name, lines.join("\n"));
        toast(ok ? ("保存: " + name) : "保存に失敗");
    }
    function copyCurrent() {
        var text = "";
        if (activeTab === "console") text = logs.map(function (lg) { return "[" + tsOf(lg.t) + "] " + lg.level.toUpperCase() + ": " + lg.text; }).join("\n");
        else if (activeTab === "network") text = nets.map(function (n) { return "[" + (n.method || "GET") + " " + (n.status || 0) + "] " + n.url; }).join("\n");
        else if (activeTab === "m3u") text = m3uBuildText();
        else if (activeTab === "elements") text = document.documentElement.outerHTML;
        else if (activeTab === "sources") text = Array.prototype.map.call(document.scripts, function (s) { return s.src || "(inline)"; }).join("\n");
        else if (activeTab === "performance") {
            try { text = performance.getEntriesByType("resource").map(function (r) { return r.name + " | " + bytes(r.transferSize || 0) + " | " + ms(r.duration); }).join("\n"); } catch (e) {}
        } else if (activeTab === "info") text = "URL: " + location.href + "\nTitle: " + document.title + "\nUA: " + navigator.userAgent;
        else text = document.body ? document.body.innerText.slice(0, 5000) : "";
        toast(copyText(text) ? "コピーしました" : "失敗");
    }

    function makeFab() {
        if (fabEl && fabEl.parentNode) return;
        injectCSS();
        loadFab();
        fabEl = document.createElement("button");
        fabEl.className = "__dt_fab";
        fabEl.type = "button";
        fabEl.setAttribute("aria-label", "DevTools (ドラッグで移動)");
        fabEl.innerHTML = "🛠";
        applyFab();
        makeFabDraggable(fabEl);
        var attach = function () {
            var host = document.body || document.documentElement;
            if (host && !fabEl.parentNode) host.appendChild(fabEl);
        };
        attach();
        if (!fabEl.parentNode) setTimeout(attach, 300);
    }

    function registerCommands() {
        if (commandsRegistered) return;
        if (!hasCoara()) return;
        try { if (typeof coara.registerCommand !== "function") return; } catch (e) { return; }
        commandsRegistered = true;
        try { coara.registerCommand("DevTools を開く", function () { openPanel(); }); } catch (e) {}
        try { coara.registerCommand("DevTools を閉じる", function () { closePanel(); }); } catch (e) {}
        try { coara.registerCommand("DevTools 開閉", function () { togglePanel(); }); } catch (e) {}
        try { coara.registerCommand("DevTools ログを保存", function () { saveAll(); }); } catch (e) {}
        try { coara.registerCommand("DevTools 通信を保存", function () { saveNetwork(); }); } catch (e) {}
        try { coara.registerCommand("DevTools m3u を保存", function () { m3uFlush(); }); } catch (e) {}
        try { coara.registerCommand("DevTools m3u をリセット", function () { m3uReset(); }); } catch (e) {}
        try { coara.registerCommand("DevTools クリア", function () {
            logs.length = 0; nets.length = 0; netIndex = {};
            renderActive();
            toast("クリアしました");
        }); } catch (e) {}
        try { coara.registerCommand("DevTools ページを再読み込み", function () { try { location.reload(); } catch (e) {} }); } catch (e) {}
        try { coara.registerCommand("DevTools 最大化", function () { win.maximized = true; win.minimized = false; applyWin(); saveWin(); }); } catch (e) {}
        try { coara.registerCommand("DevTools 最小化", function () { win.minimized = true; applyWin(); saveWin(); }); } catch (e) {}
        try { coara.registerCommand("DevTools 位置リセット", function () { defaultWin(); applyWin(); saveWin(); }); } catch (e) {}
        try {
            coara.registerCommand("DevTools ボタン位置リセット", function () {
                fab.x = null; fab.y = null;
                defaultFab();
                clampFab();
                applyFab();
                saveFab();
                toast("DevTools ボタン位置をリセット");
            });
        } catch (e) {}
    }

    function onWindowResize() {
        clampWin();
        if (panelOpen) scheduleWinApply();
        clampFab();
        applyFab();
    }

    function init() {
        if (domReady) return;
        domReady = true;
        injectCSS();
        hookConsole();
        hookXHR();
        hookFetch();
        hookPerf();
        m3uInit();
        makeFab();
        registerCommands();
        window.addEventListener("resize", onWindowResize, { passive: true });
        window.addEventListener("orientationchange", onWindowResize, { passive: true });
    }

    if (document.readyState === "loading") {
        m3uInit();
        document.addEventListener("DOMContentLoaded", init, { once: true });
        setTimeout(init, 2000);
    } else {
        init();
    }

    window.addEventListener("load", function () {
        setTimeout(makeFab, 200);
        setTimeout(registerCommands, 200);
        setTimeout(function () { m3uQuickScan(); m3uScanPerf(); }, 100);
        setTimeout(function () { m3uQuickScan(); m3uScanPerf(); }, 1500);
        setTimeout(function () { m3uQuickScan(); m3uScanPerf(); }, 4000);
    });

    window.__devtools = {
        open: openPanel,
        close: closePanel,
        toggle: togglePanel,
        save: saveAll,
        saveNetwork: saveNetwork,
        logs: function () { return logs.slice(); },
        nets: function () { return nets.slice(); },
        m3u: function () { if (!m3uStore) m3uStore = m3uLoadStore(); return m3uStore; },
        m3uSave: function () { return m3uFlush(); },
        m3uReset: m3uReset,
        m3uAdd: m3uAdd,
        m3uCheckPage: m3uCheckPage,
        clear: function () { logs.length = 0; nets.length = 0; netIndex = {}; },
        maximize: function () { win.maximized = true; win.minimized = false; applyWin(); saveWin(); },
        minimize: function () { win.minimized = true; applyWin(); saveWin(); },
        reset: function () { defaultWin(); applyWin(); saveWin(); },
        reload: function () { try { location.reload(); } catch (e) {} },
        fab: function () { return { x: fab.x, y: fab.y }; },
        fabReset: function () {
            fab.x = null; fab.y = null;
            defaultFab();
            clampFab();
            applyFab();
            saveFab();
            return { x: fab.x, y: fab.y };
        }
    };
})();