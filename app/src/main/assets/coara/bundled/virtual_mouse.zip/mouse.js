(function () {
    var HOST = location.hostname || "local";
    var SPEEDS = [{ n: "遅い", k: 0.8 }, { n: "標準", k: 1.2 }, { n: "速い", k: 1.8 }, { n: "最速", k: 2.6 }];
    var SIZES = [{ n: "小", s: 18 }, { n: "中", s: 26 }, { n: "大", s: 36 }];
    var COLORS = [
        { n: "白", f: "#ffffff", s: "#000000" },
        { n: "黒", f: "#111111", s: "#ffffff" },
        { n: "赤", f: "#ff3b30", s: "#ffffff" },
        { n: "青", f: "#2979ff", s: "#ffffff" }
    ];
    var LONGS = ["ドラッグ", "文字選択+コピー", "右クリック"];
    var MODES = ["タッチパッド", "追従"];
    var LONG_MS = 550;
    var SLOP = 10;
    var EDGE = 22;
    var FOLLOW_DX = 0;
    var FOLLOW_DY = -46;
    var TITLE = "仮想マウス";

    var KEY = "cfg";
    var cfg = defaults();
    var lastRaw = null;
    var saveFailed = false;

    function defaults() {
        return { on: 1, mode: 0, speed: 2, size: 2, color: 0, lp: 0, block: 0, btn: 1, ex: [] };
    }

    function rng(v, max, def) {
        return typeof v === "number" && v >= 0 && v < max ? v | 0 : def;
    }

    function parseCfg(raw) {
        try {
            var p = JSON.parse(raw);
            if (!p || typeof p !== "object") {
                return null;
            }
            var c = defaults();
            c.on = p.on === 0 ? 0 : 1;
            c.mode = rng(p.mode, MODES.length, 0);
            c.speed = rng(p.speed, SPEEDS.length, 2);
            c.size = rng(p.size, SIZES.length, 2);
            c.color = rng(p.color, COLORS.length, 0);
            c.lp = rng(p.lp, LONGS.length, 0);
            c.block = p.block === 0 ? 0 : 1;
            c.btn = p.btn === 0 ? 0 : 1;
            c.ex = Array.isArray(p.ex) ? p.ex.filter(function (h) { return typeof h === "string"; }).slice(0, 200) : [];
            return c;
        } catch (e) {
            return null;
        }
    }

    function syncCfg() {
        var raw = null;
        try {
            raw = coara.storage.get(KEY);
        } catch (e) {
            raw = null;
        }
        if (raw === null || raw === undefined || raw === lastRaw) {
            return false;
        }
        lastRaw = raw;
        var n = parseCfg(raw);
        if (!n) {
            return false;
        }
        cfg = n;
        return true;
    }

    function writeCfg() {
        var text = JSON.stringify(cfg);
        var ok = false;
        try {
            ok = coara.storage.set(KEY, text) === true;
        } catch (e) {
            ok = false;
        }
        if (ok) {
            lastRaw = text;
            saveFailed = false;
        }
        return ok;
    }

    function persist() {
        if (writeCfg()) {
            return true;
        }
        setTimeout(function () {
            if (writeCfg()) {
                return;
            }
            if (!saveFailed) {
                saveFailed = true;
                coara.warn("設定の保存に失敗しました");
                coara.notify("設定を保存できませんでした(拡張機能が無効化されている可能性)", TITLE);
            }
        }, 700);
        return false;
    }

    function update(fn) {
        syncCfg();
        fn();
        var ok = persist();
        refresh();
        return ok;
    }

    syncCfg();

    var raf = window.requestAnimationFrame ? function (f) { return window.requestAnimationFrame(f); } : function (f) { return setTimeout(f, 16); };
    var caf = window.cancelAnimationFrame ? function (i) { window.cancelAnimationFrame(i); } : function (i) { clearTimeout(i); };

    var _vw = 0;
    var _vh = 0;

    function measure() {
        _vw = window.innerWidth || (document.documentElement && document.documentElement.clientWidth) || 360;
        _vh = window.innerHeight || (document.documentElement && document.documentElement.clientHeight) || 640;
    }

    function vw() {
        return _vw;
    }

    function vh() {
        return _vh;
    }

    function clamp(v, lo, hi) {
        return v < lo ? lo : v > hi ? hi : v;
    }

    measure();

    var cx = Math.round(_vw / 2);
    var cy = Math.round(_vh / 2);
    var layer = null;
    var cur = null;
    var btn = null;
    var rip = null;
    var active = false;
    var bound = false;
    var st = null;
    var sc = null;
    var strip = null;
    var lock = false;
    var drag = null;
    var hov = null;
    var armRight = false;
    var lastClick = { t: 0, x: 0, y: 0, n: 0 };
    var dirty = false;
    var moveHover = false;
    var rafId = 0;
    var lastHover = 0;
    var lastSelectX = -1;
    var lastSelectY = -1;
    var fadeTimer = 0;
    var glideId = 0;
    var btnTimer = 0;
    var btnLong = false;
    var panel = null;
    var panelSync = null;
    var nativeActive = false;
    var nativePress = null;

    function isActive() {
        var root = document.documentElement;
        if (root && root.tagName !== "HTML") {
            return false;
        }
        return !!cfg.on && cfg.ex.indexOf(HOST) < 0;
    }

    function arrowUri(f, s) {
        return "url(\"data:image/svg+xml;utf8," + encodeURIComponent("<svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'><path d='M3 2v17.5l4.6-4.3 3.2 7 2.9-1.3-3.1-6.9H17.5z' fill='" + f + "' stroke='" + s + "' stroke-width='1.5' stroke-linejoin='round'/></svg>") + "\")";
    }

    function styleCursor() {
        if (!cur) {
            return;
        }
        var c = COLORS[cfg.color];
        var sz = SIZES[cfg.size].s;
        cur.style.cssText = "position:fixed;left:0;top:0;width:" + sz + "px;height:" + sz + "px;margin:" + (-sz * 2 / 24) + "px 0 0 " + (-sz * 3 / 24) + "px;background:" + arrowUri(c.f, c.s) + " 0 0/100% 100% no-repeat;pointer-events:none;will-change:transform;transition:opacity .25s;opacity:1;transform:translate3d(" + cx + "px," + cy + "px,0);display:" + (active || nativeActive ? "block" : "none");
    }

    function styleButton() {
        if (!btn) {
            return;
        }
        btn.style.cssText = "position:fixed;left:8px;bottom:104px;width:34px;height:34px;border-radius:50%;background:rgba(20,20,20,.55) " + arrowUri("#ffffff", "#000000") + " center/18px 18px no-repeat;pointer-events:auto;z-index:2147483647;margin:0;padding:0;border:0;opacity:" + (active ? ".6" : ".3") + ";touch-action:none;display:" + (cfg.btn ? "block" : "none");
    }

    function ensureLayer() {
        if (layer && layer.parentNode) {
            return true;
        }
        var root = document.documentElement;
        if (!root) {
            return false;
        }
        layer = document.createElement("div");
        layer.setAttribute("aria-hidden", "true");
        layer.style.cssText = "position:fixed;left:0;top:0;width:0;height:0;overflow:visible;pointer-events:none;z-index:2147483647;margin:0;padding:0;border:0;";
        cur = document.createElement("div");
        btn = document.createElement("div");
        rip = null;
        layer.appendChild(cur);
        layer.appendChild(btn);
        btn.addEventListener("touchstart", function (ev) {
            if (ev.cancelable) {
                ev.preventDefault();
            }
            ev.stopPropagation();
            btnLong = false;
            clearTimeout(btnTimer);
            btnTimer = setTimeout(function () {
                btnLong = true;
                vibrate();
                openPanel();
            }, 500);
        }, { passive: false });
        btn.addEventListener("touchend", function (ev) {
            if (ev.cancelable) {
                ev.preventDefault();
            }
            ev.stopPropagation();
            clearTimeout(btnTimer);
            if (!btnLong) {
                toggleFromButton();
            }
        }, { passive: false });
        btn.addEventListener("touchcancel", function () {
            clearTimeout(btnTimer);
        });
        btn.addEventListener("click", function (ev) {
            ev.stopPropagation();
            ev.preventDefault();
        });
        root.appendChild(layer);
        styleCursor();
        styleButton();
        return true;
    }

    function toggleFromButton() {
        update(function () {
            if (isActive()) {
                cfg.on = 0;
            } else {
                cfg.on = 1;
                var i = cfg.ex.indexOf(HOST);
                if (i >= 0) {
                    cfg.ex.splice(i, 1);
                }
            }
        });
        coara.notify(active ? "マウスON" : "マウスOFF", TITLE);
    }

    function showCursor() {
        if (!cur) {
            return;
        }
        cur.style.opacity = "1";
        clearTimeout(fadeTimer);
        fadeTimer = setTimeout(function () {
            if (cur) {
                cur.style.opacity = ".5";
            }
        }, 2500);
    }

    function schedule() {
        if (!rafId) {
            rafId = raf(frame);
        }
    }

    function frame() {
        rafId = 0;
        if (dirty && cur) {
            dirty = false;
            cur.style.transform = "translate3d(" + cx + "px," + cy + "px,0)";
        }
        if (moveHover) {
            var now = Date.now();
            if (now - lastHover >= (drag ? 16 : 40)) {
                moveHover = false;
                lastHover = now;
                hoverAt();
            }
        }
        if (drag) {
            var m = 40;
            var sp = 0;
            if (cy < m) {
                sp = -(m - cy) / m * 14;
            } else if (cy > _vh - m) {
                sp = (cy - (_vh - m)) / m * 14;
            }
            if (sp) {
                scrollWin(0, sp);
                moveHover = true;
            }
            if (drag.kind === "select") {
                updateSelect(!!sp);
            }
            if (sp || moveHover) {
                schedule();
            }
        } else if (moveHover) {
            schedule();
        }
    }

    function hit(d, x, y) {
        var el = d.elementFromPoint(x, y);
        if (el && btn && el === btn) {
            btn.style.display = "none";
            el = d.elementFromPoint(x, y);
            btn.style.display = "block";
        }
        return el;
    }

    function pick(x, y) {
        var ox = 0;
        var oy = 0;
        var el;
        try {
            el = hit(document, x, y);
        } catch (e) {
            return null;
        }
        if (!el) {
            return null;
        }
        for (var g = 0; g < 8; g++) {
            var nx = null;
            try {
                if (el.shadowRoot && el.shadowRoot.elementFromPoint) {
                    var s1 = el.shadowRoot.elementFromPoint(x - ox, y - oy);
                    if (s1 && s1 !== el) {
                        nx = s1;
                    }
                } else if (el.tagName === "IFRAME" || el.tagName === "FRAME") {
                    var cd = el.contentDocument;
                    if (cd) {
                        var r = el.getBoundingClientRect();
                        var bx = r.left + (el.clientLeft || 0);
                        var by = r.top + (el.clientTop || 0);
                        var s2 = cd.elementFromPoint(x - ox - bx, y - oy - by);
                        if (s2) {
                            ox += bx;
                            oy += by;
                            nx = s2;
                        }
                    }
                }
            } catch (e) {
                nx = null;
            }
            if (!nx) {
                break;
            }
            el = nx;
        }
        return { el: el, ox: ox, oy: oy };
    }

    function fire(tg, type, o) {
        o = o || {};
        var el = tg.el;
        var doc = el.ownerDocument;
        var w = (doc && doc.defaultView) || window;
        var ptr = type.indexOf("pointer") === 0;
        var nb = /enter$|leave$/.test(type);
        var x = cx - tg.ox;
        var y = cy - tg.oy;
        var init = {
            bubbles: !nb,
            cancelable: !nb,
            composed: true,
            view: w,
            clientX: x,
            clientY: y,
            screenX: x,
            screenY: y,
            button: o.button || 0,
            buttons: o.buttons || 0,
            detail: o.detail || 0,
            movementX: o.movementX || 0,
            movementY: o.movementY || 0,
            relatedTarget: o.related || null
        };
        var ev;
        try {
            if (ptr) {
                if (!w.PointerEvent) {
                    return true;
                }
                init.pointerId = 1;
                init.pointerType = "mouse";
                init.isPrimary = true;
                init.width = 1;
                init.height = 1;
                init.pressure = init.buttons ? 0.5 : 0;
                ev = new w.PointerEvent(type, init);
            } else {
                ev = new w.MouseEvent(type, init);
            }
            return el.dispatchEvent(ev);
        } catch (e) {
            return true;
        }
    }

    function parentOrHost(n) {
        var p = n.parentNode;
        if (p && p.nodeType === 11) {
            return p.host || null;
        }
        return p;
    }

    function chain(el) {
        var a = [];
        var n = el;
        while (n && n.nodeType === 1) {
            a.push(n);
            n = parentOrHost(n);
        }
        return a;
    }

    function crossing(oldT, nu) {
        var oc = oldT ? chain(oldT.el) : [];
        var nc = chain(nu.el);
        var i;
        if (oldT) {
            fire(oldT, "pointerout", { related: nu.el });
            fire(oldT, "mouseout", { related: nu.el });
            for (i = 0; i < oc.length; i++) {
                if (nc.indexOf(oc[i]) < 0) {
                    fire({ el: oc[i], ox: oldT.ox, oy: oldT.oy }, "pointerleave", { related: nu.el });
                    fire({ el: oc[i], ox: oldT.ox, oy: oldT.oy }, "mouseleave", { related: nu.el });
                }
            }
        }
        fire(nu, "pointerover", { related: oldT ? oldT.el : null });
        fire(nu, "mouseover", { related: oldT ? oldT.el : null });
        for (i = nc.length - 1; i >= 0; i--) {
            if (oc.indexOf(nc[i]) < 0) {
                fire({ el: nc[i], ox: nu.ox, oy: nu.oy }, "pointerenter", { related: oldT ? oldT.el : null });
                fire({ el: nc[i], ox: nu.ox, oy: nu.oy }, "mouseenter", { related: oldT ? oldT.el : null });
            }
        }
    }

    function syncHover(tg) {
        if (!hov || hov.el !== tg.el) {
            crossing(hov, tg);
            hov = tg;
        }
        return tg;
    }

    var lastHx = -1;
    var lastHy = -1;

    function hoverAt() {
        if (cx === lastHx && cy === lastHy && !drag) {
            return;
        }
        lastHx = cx;
        lastHy = cy;
        var tg = pick(cx, cy);
        if (!tg) {
            return;
        }
        syncHover(tg);
        var b = drag && drag.kind === "drag" ? 1 : 0;
        fire(tg, "pointermove", { buttons: b });
        fire(tg, "mousemove", { buttons: b });
        if (drag && drag.kind === "drag" && drag.tg && drag.tg.el.tagName === "INPUT" && drag.tg.el.type === "range") {
            setRange(drag.tg.el, drag.tg.ox);
        }
    }

    var FOCUSABLE = "input,textarea,select,button,a[href],[tabindex],[contenteditable=''],[contenteditable='true'],summary";

    function nativeTarget() {
        return pick(cx, cy);
    }

    function nativeMove(dx, dy) {
        if (!nativeActive || !isFinite(dx) || !isFinite(dy) || (dx === 0 && dy === 0)) {
            return;
        }
        measure();
        cx = clamp(cx + dx, 0, _vw - 1);
        cy = clamp(cy + dy, 0, _vh - 1);
        dirty = true;
        showCursor();
        var tg = nativeTarget();
        if (!tg) {
            schedule();
            return;
        }
        syncHover(tg);
        fire(tg, "pointermove", { buttons: nativePress ? nativePress.buttons : 0, movementX: dx, movementY: dy });
        fire(tg, "mousemove", { buttons: nativePress ? nativePress.buttons : 0, movementX: dx, movementY: dy });
        schedule();
    }

    function nativeDown(button) {
        if (!nativeActive || (button !== 0 && button !== 2)) {
            return;
        }
        stopGlide();
        showCursor();
        var tg = nativeTarget();
        if (!tg) {
            return;
        }
        syncHover(tg);
        var bit = button === 2 ? 2 : 1;
        if (nativePress && nativePress.button === button) {
            return;
        }
        if (nativePress) {
            nativeUp(nativePress.button);
        }
        nativePress = { button: button, buttons: bit, tg: tg, sx: cx, sy: cy };
        fire(tg, "pointerdown", { button: button, buttons: bit, detail: 1 });
        var md = fire(tg, "mousedown", { button: button, buttons: bit, detail: 1 });
        if (md) {
            focusFor(tg.el);
        }
        schedule();
    }

    function nativeUp(button) {
        var p = nativePress;
        if (!p || p.button !== button) {
            return;
        }
        nativePress = null;
        var tg = nativeTarget() || p.tg;
        fire(tg, "pointerup", { button: button, buttons: 0, detail: 1 });
        fire(tg, "mouseup", { button: button, buttons: 0, detail: 1 });
        if (button === 2) {
            fire(tg, "contextmenu", { button: 2, buttons: 0, detail: 1 });
            fire(tg, "auxclick", { button: 2, buttons: 0, detail: 1 });
        } else if (tg.el === p.tg.el && Math.hypot(cx - p.sx, cy - p.sy) < 8) {
            var ce = fire(tg, "click", { button: 0, buttons: 0, detail: 1 });
            if (ce) {
                afterClick(tg);
            }
        }
        schedule();
    }

    function nativeClick(button) {
        nativeDown(button);
        nativeUp(button);
    }

    function nativeScroll(dx, dy) {
        if (!nativeActive || !isFinite(dx) || !isFinite(dy) || (dx === 0 && dy === 0)) {
            return;
        }
        stopGlide();
        var tg = nativeTarget();
        var g = { tg: tg, list: scrollables(tg) };
        if (!tg) {
            g.tg = { el: document.documentElement, ox: 0, oy: 0 };
        }
        applyScroll(g, dx, dy);
    }

    function nativeStart() {
        if (!ensureLayer()) {
            return;
        }
        nativeActive = true;
        styleCursor();
        showCursor();
    }

    function nativeStop() {
        if (nativePress) {
            nativeUp(nativePress.button);
        }
        nativeActive = false;
        styleCursor();
        if (!active && cur) {
            cur.style.display = "none";
        }
    }

    function focusFor(el) {
        var f = null;
        try {
            f = el.closest(FOCUSABLE);
        } catch (e) {
            f = null;
        }
        if (f && f.disabled) {
            f = null;
        }
        if (f) {
            try {
                f.focus({ preventScroll: true });
            } catch (e) {}
            return;
        }
        var d = el.ownerDocument;
        var a = d && d.activeElement;
        if (a && a !== d.body && typeof a.blur === "function" && (/^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName) || a.isContentEditable)) {
            try {
                a.blur();
            } catch (e) {}
        }
    }

    function openPicker(el) {
        if (typeof el.showPicker === "function") {
            try {
                el.showPicker();
            } catch (e) {}
        }
    }

    function setRange(el, ox) {
        var r = el.getBoundingClientRect();
        if (!r.width) {
            return;
        }
        var min = parseFloat(el.min);
        var max = parseFloat(el.max);
        var step = parseFloat(el.step);
        if (isNaN(min)) {
            min = 0;
        }
        if (isNaN(max)) {
            max = 100;
        }
        if (isNaN(step) || step <= 0) {
            step = 1;
        }
        var ratio = clamp((cx - ox - r.left) / r.width, 0, 1);
        var v = min + ratio * (max - min);
        v = Math.round((v - min) / step) * step + min;
        v = clamp(v, min, max);
        if (String(v) === el.value) {
            return;
        }
        el.value = String(v);
        var w = el.ownerDocument.defaultView || window;
        try {
            el.dispatchEvent(new w.Event("input", { bubbles: true }));
            el.dispatchEvent(new w.Event("change", { bubbles: true }));
        } catch (e) {}
    }

    function caretAt(doc, x, y) {
        if (!doc) {
            return null;
        }
        try {
            if (doc.caretRangeFromPoint) {
                return doc.caretRangeFromPoint(x, y);
            }
            if (doc.caretPositionFromPoint) {
                var c = doc.caretPositionFromPoint(x, y);
                if (c) {
                    var r = doc.createRange();
                    r.setStart(c.offsetNode, c.offset);
                    r.collapse(true);
                    return r;
                }
            }
        } catch (e) {}
        return null;
    }

    function selectionFor(doc) {
        if (!doc) {
            return null;
        }
        try {
            if (typeof doc.getSelection === "function") {
                return doc.getSelection();
            }
            var w = doc.defaultView;
            return w && typeof w.getSelection === "function" ? w.getSelection() : null;
        } catch (e) {
            return null;
        }
    }

    function afterClick(tg) {
        var el = tg.el;
        var tag = el.tagName;
        if (tag === "SELECT") {
            openPicker(el);
        } else if (tag === "INPUT") {
            var ty = (el.type || "").toLowerCase();
            if (ty === "range") {
                setRange(el, tg.ox);
            } else if (/^(date|time|datetime-local|month|week|color)$/.test(ty)) {
                openPicker(el);
            }
        } else if ((tag === "VIDEO" || tag === "AUDIO") && el.controls) {
            try {
                if (el.paused) {
                    var pr = el.play();
                    if (pr && pr.catch) {
                        pr.catch(function () {});
                    }
                } else {
                    el.pause();
                }
            } catch (e) {}
        } else if (el.isContentEditable) {
            var r = caretAt(el.ownerDocument, cx - tg.ox, cy - tg.oy);
            if (r) {
                try {
                    var s = selectionFor(el.ownerDocument);
                    if (s) {
                        s.removeAllRanges();
                        s.addRange(r);
                    }
                } catch (e) {}
            }
        }
    }

    function clearSelection(tg) {
        try {
            var s = (tg.el.ownerDocument.defaultView || window).getSelection();
            if (s && s.type === "Range" && !tg.el.isContentEditable && !/^(INPUT|TEXTAREA)$/.test(tg.el.tagName)) {
                s.removeAllRanges();
            }
        } catch (e) {}
    }

    function ripple(right) {
        if (!layer || typeof Element.prototype.animate !== "function") {
            return;
        }
        if (!rip) {
            rip = document.createElement("div");
            layer.appendChild(rip);
        }
        rip.style.cssText = "position:fixed;left:0;top:0;width:36px;height:36px;margin:-18px 0 0 -18px;border-radius:50%;box-sizing:border-box;border:2px solid " + (right ? "#ff9500" : "#2979ff") + ";pointer-events:none;opacity:0";
        try {
            rip.animate([
                { transform: "translate3d(" + cx + "px," + cy + "px,0) scale(.3)", opacity: 0.9 },
                { transform: "translate3d(" + cx + "px," + cy + "px,0) scale(1.2)", opacity: 0 }
            ], { duration: 320, easing: "ease-out" });
        } catch (e) {}
    }

    function doClick(right) {
        var tg = pick(cx, cy);
        if (!tg) {
            return;
        }
        syncHover(tg);
        fire(tg, "pointermove");
        fire(tg, "mousemove");
        ripple(right);
        if (right) {
            fire(tg, "pointerdown", { button: 2, buttons: 2 });
            var md = fire(tg, "mousedown", { button: 2, buttons: 2 });
            if (md) {
                focusFor(tg.el);
            }
            fire(tg, "contextmenu", { button: 2, buttons: 2 });
            fire(tg, "pointerup", { button: 2, buttons: 0 });
            fire(tg, "mouseup", { button: 2, buttons: 0 });
            fire(tg, "auxclick", { button: 2, buttons: 0 });
            return;
        }
        var now = Date.now();
        var n = now - lastClick.t < 350 && Math.hypot(cx - lastClick.x, cy - lastClick.y) < 24 ? lastClick.n + 1 : 1;
        if (n > 3) {
            n = 1;
        }
        lastClick = { t: now, x: cx, y: cy, n: n };
        fire(tg, "pointerdown", { button: 0, buttons: 1, detail: n });
        var mdn = fire(tg, "mousedown", { button: 0, buttons: 1, detail: n });
        if (mdn) {
            focusFor(tg.el);
        }
        fire(tg, "pointerup", { button: 0, buttons: 0, detail: n });
        fire(tg, "mouseup", { button: 0, buttons: 0, detail: n });
        var ce = fire(tg, "click", { button: 0, buttons: 0, detail: n });
        if (n === 2) {
            fire(tg, "dblclick", { button: 0, buttons: 0, detail: 2 });
        }
        if (ce) {
            afterClick(tg);
        }
        clearSelection(tg);
    }

    function vibrate() {
        try {
            if (navigator.vibrate) {
                navigator.vibrate(12);
            }
        } catch (e) {}
    }

    function beginLong() {
        vibrate();
        showCursor();
        if (cfg.lp === 2) {
            doClick(true);
            return;
        }
        var tg = pick(cx, cy);
        if (!tg) {
            return;
        }
        syncHover(tg);
        ripple(false);
        if (cfg.lp === 0) {
            drag = { kind: "drag", tg: tg, sx: cx, sy: cy };
            fire(tg, "pointerdown", { button: 0, buttons: 1, detail: 1 });
            var md = fire(tg, "mousedown", { button: 0, buttons: 1, detail: 1 });
            if (md) {
                focusFor(tg.el);
            }
        } else {
            var a = caretAt(tg.el.ownerDocument, cx - tg.ox, cy - tg.oy);
            if (!a) {
                return;
            }
            drag = { kind: "select", tg: tg, sx: cx, sy: cy, anchor: a };
            lastSelectX = -1;
            lastSelectY = -1;
            try {
                var sel = selectionFor(tg.el.ownerDocument);
                if (sel) {
                    sel.removeAllRanges();
                }
            } catch (e) {}
        }
        schedule();
    }

    function updateSelect(force) {
        var d = drag;
        if (!d || !d.anchor) {
            return;
        }
        if (!force && cx === lastSelectX && cy === lastSelectY) {
            return;
        }
        var r = caretAt(d.tg.el.ownerDocument, cx - d.tg.ox, cy - d.tg.oy);
        if (!r) {
            return;
        }
        lastSelectX = cx;
        lastSelectY = cy;
        try {
            var sel = selectionFor(d.tg.el.ownerDocument);
            if (sel) {
                sel.setBaseAndExtent(d.anchor.startContainer, d.anchor.startOffset, r.startContainer, r.startOffset);
            }
        } catch (e) {}
    }

    function endDrag(cancel) {
        var d = drag;
        drag = null;
        if (!d) {
            return;
        }
        if (d.kind === "drag") {
            var tg = pick(cx, cy) || d.tg;
            fire(tg, "pointerup", { button: 0, buttons: 0, detail: 1 });
            fire(tg, "mouseup", { button: 0, buttons: 0, detail: 1 });
            if (!cancel && tg.el === d.tg.el && Math.hypot(cx - d.sx, cy - d.sy) < 8) {
                var ce = fire(tg, "click", { button: 0, buttons: 0, detail: 1 });
                if (ce) {
                    afterClick(tg);
                }
            }
        } else if (!cancel) {
            var text = "";
            try {
                var sel = selectionFor(d.tg.el.ownerDocument);
                text = sel ? String(sel) : "";
            } catch (e) {
                text = "";
            }
            if (text) {
                coara.copy(text);
                coara.notify("コピー: " + text.slice(0, 40), TITLE);
            }
        }
    }

    function scrollables(tg) {
        var list = [];
        var n = tg ? tg.el : null;
        while (n && n.nodeType === 1 && n !== document.documentElement && n !== document.body) {
            try {
                var w = n.ownerDocument.defaultView || window;
                var cs = w.getComputedStyle(n);
                var sy = /(auto|scroll)/.test(cs.overflowY) && n.scrollHeight > n.clientHeight + 1;
                var sx = /(auto|scroll)/.test(cs.overflowX) && n.scrollWidth > n.clientWidth + 1;
                if (sx || sy) {
                    list.push(n);
                }
            } catch (e) {}
            n = parentOrHost(n);
        }
        return list;
    }

    function scrollWin(dx, dy) {
        try {
            window.scrollBy({ left: dx, top: dy, behavior: "instant" });
        } catch (e) {
            window.scrollBy(dx, dy);
        }
    }

    function applyScroll(g, dx, dy) {
        var w = (g.tg && g.tg.el.ownerDocument.defaultView) || window;
        try {
            var we = new w.WheelEvent("wheel", { bubbles: true, cancelable: true, composed: true, view: w, clientX: cx - g.tg.ox, clientY: cy - g.tg.oy, deltaX: dx, deltaY: dy, deltaMode: 0 });
            if (g.tg && !g.tg.el.dispatchEvent(we)) {
                return;
            }
        } catch (e) {}
        var rx = dx;
        var ry = dy;
        for (var i = 0; i < g.list.length && (rx || ry); i++) {
            var n = g.list[i];
            if (ry) {
                var maxY = n.scrollHeight - n.clientHeight;
                var py = n.scrollTop;
                var ny = clamp(py + ry, 0, maxY);
                if (ny !== py) {
                    n.scrollTop = ny;
                    ry = 0;
                }
            }
            if (rx) {
                var maxX = n.scrollWidth - n.clientWidth;
                var px = n.scrollLeft;
                var nxx = clamp(px + rx, 0, maxX);
                if (nxx !== px) {
                    n.scrollLeft = nxx;
                    rx = 0;
                }
            }
        }
        if (rx || ry) {
            scrollWin(rx, ry);
        }
    }

    function stopGlide() {
        if (glideId) {
            caf(glideId);
            glideId = 0;
        }
    }

    function glide(g, vx, vy) {
        stopGlide();
        if (Math.abs(vx) < 0.15 && Math.abs(vy) < 0.15) {
            return;
        }
        var last = Date.now();
        var step = function () {
            glideId = raf(function () {
                var n = Date.now();
                var dt = Math.min(32, n - last);
                last = n;
                applyScroll(g, vx * dt, vy * dt);
                var f = Math.pow(0.95, dt / 16);
                vx *= f;
                vy *= f;
                if (Math.abs(vx) < 0.02 && Math.abs(vy) < 0.02) {
                    glideId = 0;
                    return;
                }
                step();
            });
        };
        step();
    }

    function centroid(ts) {
        var x = 0;
        var y = 0;
        for (var i = 0; i < ts.length; i++) {
            x += ts[i].clientX;
            y += ts[i].clientY;
        }
        return { x: x / ts.length, y: y / ts.length };
    }

    function cancelSingle() {
        if (st) {
            clearTimeout(st.timer);
            st = null;
        }
        if (drag) {
            endDrag(true);
        }
        strip = null;
    }

    function startScroll(ts) {
        var c = centroid(ts);
        var tg = pick(c.x, c.y) || pick(cx, cy);
        sc = { x: c.x, y: c.y, t: Date.now(), vx: 0, vy: 0, tg: tg, list: scrollables(tg) };
        if (!sc.tg) {
            sc.tg = { el: document.documentElement, ox: 0, oy: 0 };
        }
    }

    function finishScroll() {
        var g = sc;
        sc = null;
        if (g && Date.now() - g.t < 120) {
            glide(g, g.vx, g.vy);
        }
    }

    function find(list, id) {
        for (var i = 0; i < list.length; i++) {
            if (list[i].identifier === id) {
                return list[i];
            }
        }
        return null;
    }

    function ours(t) {
        return !!layer && !!t && t.nodeType === 1 && t !== layer && layer.contains(t);
    }

    function consume(ev) {
        if (!cfg.block) {
            return;
        }
        if (ev.cancelable) {
            ev.preventDefault();
        }
        ev.stopImmediatePropagation();
    }

    function onStart(ev) {
        if (!active || ours(ev.target)) {
            return;
        }
        consume(ev);
        stopGlide();
        showCursor();
        var ts = ev.touches;
        if (ts.length >= 2) {
            cancelSingle();
            startScroll(ts);
            lock = true;
            return;
        }
        if (lock) {
            return;
        }
        var t = ev.changedTouches[0];
        if (!t) {
            return;
        }
        if (t.clientX >= _vw - EDGE) {
            var pt = pick(cx, cy);
            strip = { id: t.identifier, y: t.clientY, list: scrollables(pt), tg: pt || { el: document.documentElement, ox: 0, oy: 0 } };
            return;
        }
        var now = Date.now();
        st = { id: t.identifier, sx: t.clientX, sy: t.clientY, lx: t.clientX, ly: t.clientY, lt: now, t0: now, moved: false, longDone: false, free: false, timer: 0 };
        if (cfg.mode === 1) {
            cx = clamp(Math.round(t.clientX + FOLLOW_DX), 0, _vw - 1);
            cy = clamp(Math.round(t.clientY + FOLLOW_DY), 0, _vh - 1);
            dirty = true;
            moveHover = true;
            schedule();
        }
        st.timer = setTimeout(onLong, LONG_MS);
    }

    function onLong() {
        if (!st || st.longDone) {
            return;
        }
        if (cfg.mode === 0 && st.moved) {
            return;
        }
        st.longDone = true;
        st.free = true;
        beginLong();
    }

    function onMove(ev) {
        if (!active || (!st && !sc && !strip && !lock)) {
            return;
        }
        consume(ev);
        var now = Date.now();
        if (sc) {
            if (ev.touches.length < 2) {
                return;
            }
            var c = centroid(ev.touches);
            var dt = Math.max(1, now - sc.t);
            var ddx = sc.x - c.x;
            var ddy = sc.y - c.y;
            sc.vx = sc.vx * 0.7 + (ddx / dt) * 0.3;
            sc.vy = sc.vy * 0.7 + (ddy / dt) * 0.3;
            sc.x = c.x;
            sc.y = c.y;
            sc.t = now;
            if (ddx || ddy) {
                applyScroll(sc, ddx, ddy);
            }
            return;
        }
        if (strip) {
            var ts = find(ev.changedTouches, strip.id);
            if (ts) {
                var ratio = Math.max(1, (document.documentElement.scrollHeight || _vh) / _vh);
                var sdy = (ts.clientY - strip.y) * ratio;
                strip.y = ts.clientY;
                if (sdy) {
                    applyScroll(strip, 0, sdy);
                }
            }
            return;
        }
        if (!st) {
            return;
        }
        var t = find(ev.changedTouches, st.id);
        if (!t) {
            return;
        }
        var dx = t.clientX - st.lx;
        var dy = t.clientY - st.ly;
        var dtm = Math.max(1, now - st.lt);
        st.lx = t.clientX;
        st.ly = t.clientY;
        st.lt = now;
        if (cfg.mode === 1) {
            cx = clamp(Math.round(t.clientX + FOLLOW_DX), 0, _vw - 1);
            cy = clamp(Math.round(t.clientY + FOLLOW_DY), 0, _vh - 1);
            if (!st.longDone && (Math.abs(dx) + Math.abs(dy)) >= 2) {
                clearTimeout(st.timer);
                st.timer = setTimeout(onLong, LONG_MS);
            }
            dirty = true;
            moveHover = true;
            schedule();
            return;
        }
        if (!st.moved && !st.free) {
            if (Math.hypot(t.clientX - st.sx, t.clientY - st.sy) <= SLOP) {
                return;
            }
            st.moved = true;
            clearTimeout(st.timer);
            dx = t.clientX - st.sx;
            dy = t.clientY - st.sy;
        }
        var v = Math.hypot(dx, dy) / dtm;
        var g = SPEEDS[cfg.speed].k * (1 + clamp((v - 0.4) / 1.4, 0, 1) * 0.9);
        cx = clamp(Math.round(cx + dx * g), 0, _vw - 1);
        cy = clamp(Math.round(cy + dy * g), 0, _vh - 1);
        dirty = true;
        moveHover = true;
        schedule();
    }

    function finishSingle() {
        var s = st;
        st = null;
        clearTimeout(s.timer);
        showCursor();
        if (drag) {
            endDrag(false);
            return;
        }
        if (s.longDone) {
            return;
        }
        var right = armRight;
        armRight = false;
        if (cfg.mode === 1) {
            doClick(right);
        } else if (!s.moved && Date.now() - s.t0 < LONG_MS) {
            doClick(right);
        }
    }

    function onEnd(ev) {
        if (!active || (!st && !sc && !strip && !lock)) {
            return;
        }
        consume(ev);
        if (sc) {
            if (ev.touches.length < 2) {
                finishScroll();
            }
        } else if (strip) {
            if (find(ev.changedTouches, strip.id)) {
                strip = null;
            }
        } else if (st) {
            if (find(ev.changedTouches, st.id)) {
                finishSingle();
            }
        }
        if (!ev.touches.length) {
            lock = false;
            sc = null;
            strip = null;
        }
    }

    function cancelAll() {
        cancelSingle();
        if (sc) {
            sc = null;
        }
        strip = null;
        lock = false;
        stopGlide();
    }

    function onCancel(ev) {
        if (!active) {
            return;
        }
        if (ev && ev.touches && ev.touches.length) {
            return;
        }
        cancelAll();
    }

    function onResize() {
        measure();
        cx = clamp(cx, 0, _vw - 1);
        cy = clamp(cy, 0, _vh - 1);
        dirty = true;
        schedule();
    }

    var PASSIVE_OPT = { capture: true, passive: true };
    var ACTIVE_OPT = { capture: true, passive: false };
    var RESIZE_OPT = { passive: true };
    var boundOpt = null;

    function bind() {
        var wanted = cfg.block ? ACTIVE_OPT : PASSIVE_OPT;
        if (bound) {
            if (boundOpt === wanted) {
                return;
            }
            unbind();
        }
        bound = true;
        boundOpt = wanted;
        window.addEventListener("touchstart", onStart, wanted);
        window.addEventListener("touchmove", onMove, wanted);
        window.addEventListener("touchend", onEnd, wanted);
        window.addEventListener("touchcancel", onCancel, wanted);
        window.addEventListener("blur", onCancel);
        window.addEventListener("resize", onResize, RESIZE_OPT);
    }

    function unbind() {
        if (!bound) {
            return;
        }
        var opt = boundOpt || PASSIVE_OPT;
        bound = false;
        boundOpt = null;
        window.removeEventListener("touchstart", onStart, opt);
        window.removeEventListener("touchmove", onMove, opt);
        window.removeEventListener("touchend", onEnd, opt);
        window.removeEventListener("touchcancel", onCancel, opt);
        window.removeEventListener("blur", onCancel);
        window.removeEventListener("resize", onResize, RESIZE_OPT);
        cancelAll();
        hov = null;
    }

    function refresh() {
        measure();
        active = isActive();
        if (active) {
            bind();
        } else {
            unbind();
        }
        if (ensureLayer()) {
            styleCursor();
            styleButton();
            if (active) {
                showCursor();
            }
        }
    }

    function init() {
        measure();
        refresh();
    }

    if (document.readyState === "loading") {
        active = isActive();
        if (active) {
            bind();
        }
        document.addEventListener("DOMContentLoaded", init, { once: true });
    } else {
        init();
    }

    function closePanel() {
        if (panel && panel.parentNode) {
            panel.parentNode.removeChild(panel);
        }
        panel = null;
        panelSync = null;
    }

    function chip(text, on) {
        var c = document.createElement("div");
        c.setAttribute("role", "button");
        c.textContent = text;
        c.style.cssText = "display:inline-block;margin:3px 4px 3px 0;padding:7px 11px;border-radius:16px;font:13px/1.2 sans-serif;border:1px solid rgba(255,255,255,.35);color:#fff;cursor:pointer;-webkit-user-select:none;user-select:none;background:" + (on ? "#2979ff" : "transparent");
        return c;
    }

    function panelRows() {
        var names = function (list) {
            return list.map(function (x) { return x.n || x; });
        };
        return [
            { label: "全体", opts: ["OFF", "ON"], get: function () { return cfg.on ? 1 : 0; }, set: function (i) { cfg.on = i; } },
            {
                label: "このサイト",
                opts: ["使わない", "使う"],
                get: function () { return cfg.ex.indexOf(HOST) < 0 ? 1 : 0; },
                set: function (i) {
                    var k = cfg.ex.indexOf(HOST);
                    if (i === 1 && k >= 0) {
                        cfg.ex.splice(k, 1);
                    } else if (i === 0 && k < 0) {
                        cfg.ex.push(HOST);
                    }
                }
            },
            { label: "操作方式", opts: names(MODES), get: function () { return cfg.mode; }, set: function (i) { cfg.mode = i; } },
            { label: "速度", opts: names(SPEEDS), get: function () { return cfg.speed; }, set: function (i) { cfg.speed = i; } },
            { label: "大きさ", opts: names(SIZES), get: function () { return cfg.size; }, set: function (i) { cfg.size = i; } },
            { label: "色", opts: names(COLORS), get: function () { return cfg.color; }, set: function (i) { cfg.color = i; } },
            { label: "長押し", opts: names(LONGS), get: function () { return cfg.lp; }, set: function (i) { cfg.lp = i; } },
            { label: "切替ボタン", opts: ["非表示", "表示"], get: function () { return cfg.btn ? 1 : 0; }, set: function (i) { cfg.btn = i; } },
            { label: "ページへのタッチ", opts: ["通す", "遮断"], get: function () { return cfg.block ? 1 : 0; }, set: function (i) { cfg.block = i; } }
        ];
    }

    function openPanel() {
        if (!ensureLayer()) {
            return;
        }
        measure();
        closePanel();
        syncCfg();
        panel = document.createElement("div");
        panel.style.cssText = "position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);width:min(92vw,360px);max-height:84vh;overflow-y:auto;-webkit-overflow-scrolling:touch;background:rgba(24,24,28,.97);color:#fff;font:14px/1.4 sans-serif;border-radius:14px;padding:12px 14px;box-sizing:border-box;pointer-events:auto;z-index:2147483647;touch-action:pan-y;box-shadow:0 8px 32px rgba(0,0,0,.55);filter:none";
        var head = document.createElement("div");
        head.style.cssText = "font-weight:bold;font-size:15px;margin-bottom:6px";
        head.textContent = TITLE + " 設定";
        panel.appendChild(head);
        var stat = document.createElement("div");
        stat.style.cssText = "font-size:11px;opacity:.7;margin-bottom:6px";
        panel.appendChild(stat);
        var rows = panelRows();
        var holders = [];
        var paint = function () {
            stat.textContent = HOST + (saveFailed ? " / 保存失敗" : " / 設定は自動保存");
            for (var r = 0; r < rows.length; r++) {
                var cont = holders[r];
                while (cont.firstChild) {
                    cont.removeChild(cont.firstChild);
                }
                var cur0 = rows[r].get();
                for (var o = 0; o < rows[r].opts.length; o++) {
                    cont.appendChild(chip(rows[r].opts[o], o === cur0));
                }
            }
        };
        panelSync = paint;
        rows.forEach(function (row, ri) {
            var wrap = document.createElement("div");
            wrap.style.cssText = "margin:6px 0";
            var lab = document.createElement("div");
            lab.style.cssText = "font-size:12px;opacity:.75;margin-bottom:2px";
            lab.textContent = row.label;
            var cont = document.createElement("div");
            cont.addEventListener("click", function (ev) {
                var t = ev.target;
                if (!t || t === cont) {
                    return;
                }
                var idx = Array.prototype.indexOf.call(cont.children, t);
                if (idx < 0) {
                    return;
                }
                update(function () {
                    rows[ri].set(idx);
                });
                paint();
            });
            holders.push(cont);
            wrap.appendChild(lab);
            wrap.appendChild(cont);
            panel.appendChild(wrap);
        });
        var foot = document.createElement("div");
        foot.style.cssText = "margin-top:8px";
        var right = chip("次のタップを右クリック", false);
        right.addEventListener("click", function () {
            armRight = true;
            coara.notify("次のタップは右クリック", TITLE);
            closePanel();
        });
        var center = chip("カーソルを中央へ", false);
        center.addEventListener("click", function () {
            cx = Math.round(_vw / 2);
            cy = Math.round(_vh / 2);
            dirty = true;
            schedule();
            showCursor();
        });
        var close = chip("閉じる", true);
        close.addEventListener("click", closePanel);
        foot.appendChild(right);
        foot.appendChild(center);
        foot.appendChild(close);
        panel.appendChild(foot);
        layer.appendChild(panel);
        paint();
    }

    function resync() {
        if (syncCfg()) {
            refresh();
            if (panelSync) {
                panelSync();
            }
        }
    }

    window.addEventListener("pageshow", resync);
    window.addEventListener("focus", resync);
    document.addEventListener("visibilitychange", function () {
        if (!document.hidden) {
            resync();
        }
    });

    coara.registerCommand("マウス ON/OFF", function () {
        update(function () {
            cfg.on = cfg.on ? 0 : 1;
        });
        coara.notify(active ? "マウスON" : "マウスOFF", TITLE);
    });
    coara.registerCommand("マウス このサイトON/OFF", function () {
        update(function () {
            var i = cfg.ex.indexOf(HOST);
            if (i >= 0) {
                cfg.ex.splice(i, 1);
            } else {
                cfg.ex.push(HOST);
            }
        });
        coara.notify(HOST + ": " + (isActive() ? "マウスを使う" : "マウスを使わない"), TITLE);
    });
    coara.registerCommand("マウス 設定", function () {
        openPanel();
    });

    window.__coaraVirtualMouseNative = {
        start: nativeStart,
        stop: nativeStop,
        move: nativeMove,
        down: nativeDown,
        up: nativeUp,
        click: nativeClick,
        scroll: nativeScroll
    };
})();