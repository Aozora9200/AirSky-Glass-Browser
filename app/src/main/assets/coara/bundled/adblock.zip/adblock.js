(function () {
    "use strict";

    var TITLE = "AdBlock";
    var PREFIX = "coara_ab_";
    var WIN_KEY = PREFIX + "win";
    var FAB_KEY = PREFIX + "fab";
    var CFG_KEY = PREFIX + "cfg";
    var SITE_KEY = PREFIX + "sites";
    var STAT_KEY = PREFIX + "stat";
    var HOST_ID = "__ab_host_v2";
    var HOST_STYLE_ID = "__ab_host_style_v2";
    var MIN_W = 260;
    var MIN_H = 160;
    var TOOLBAR_H = 46;
    var FAB_SIZE = 52;
    var FAB_DRAG_THRESHOLD = 6;
    var MAX_LOG = 200;
    var MAX_SITES = 500;
    var WATCHDOG_MS = 1200;
    var NAV_DEBOUNCE_MS = 350;
    var STAT_SAVE_MS = 600;

    var memStore = {};
    var domReady = false;
    var commandsRegistered = false;

    var ttPolicy = null;
    try {
        if (typeof trustedTypes !== "undefined" && trustedTypes &&
            typeof trustedTypes.createPolicy === "function") {
            ttPolicy = trustedTypes.createPolicy("coara-ab-" + Math.random().toString(36).slice(2), {
                createHTML: function (s) { return s; }
            });
        }
    } catch (e) { ttPolicy = null; }

    function setHTMLSafe(node, html) {
        if (!node) return;
        var s = String(html == null ? "" : html);
        if (ttPolicy) {
            try { node.innerHTML = ttPolicy.createHTML(s); return; } catch (e) {}
        }
        try { node.innerHTML = s; return; } catch (e) {}
        try { node.textContent = s; } catch (e) {}
    }

    function clearChildren(node) {
        if (!node) return;
        while (node.firstChild) {
            try { node.removeChild(node.firstChild); }
            catch (e) { break; }
        }
    }

    function hasCoara() {
        return typeof coara !== "undefined" && coara !== null;
    }

    function sget(key, def) {
        try {
            if (hasCoara() && coara.storage && typeof coara.storage.get === "function") {
                var v = coara.storage.get(key);
                if (v !== null && v !== undefined && v !== "") {
                    try { return JSON.parse(v); } catch (e) { return def; }
                }
                return def;
            }
        } catch (e) {}
        try {
            if (typeof localStorage !== "undefined") {
                var lv = localStorage.getItem(key);
                if (lv !== null && lv !== "") {
                    try { return JSON.parse(lv); } catch (e) {}
                }
            }
        } catch (e) {}
        return Object.prototype.hasOwnProperty.call(memStore, key) ? memStore[key] : def;
    }

    function sset(key, val) {
        memStore[key] = val;
        var json;
        try { json = JSON.stringify(val); } catch (e) { return false; }
        try {
            if (hasCoara() && coara.storage && typeof coara.storage.set === "function") {
                coara.storage.set(key, json);
                return true;
            }
        } catch (e) {}
        try {
            if (typeof localStorage !== "undefined") {
                localStorage.setItem(key, json);
                return true;
            }
        } catch (e) {}
        return false;
    }

    function notify(msg) {
        try {
            if (hasCoara() && typeof coara.notify === "function") {
                coara.notify(String(msg), TITLE);
                return;
            }
        } catch (e) {}
    }

    function copyText(t) {
        try {
            if (hasCoara() && typeof coara.copy === "function") {
                coara.copy(String(t));
                return true;
            }
        } catch (e) {}
        try {
            var ta = document.createElement("textarea");
            ta.value = String(t);
            ta.style.cssText = "position:fixed;left:-9999px;top:0;";
            (document.body || document.documentElement).appendChild(ta);
            ta.select();
            var ok = document.execCommand("copy");
            try { ta.parentNode.removeChild(ta); } catch (e) {}
            return ok;
        } catch (e) { return false; }
    }

    function regCmd(name, fn) {
        try {
            if (hasCoara() && typeof coara.registerCommand === "function") {
                coara.registerCommand(name, fn);
            }
        } catch (e) {}
    }

    function safe(fn) {
        try { return fn(); } catch (e) {
            try { console.error("[AdBlock]", e && e.message ? e.message : e); } catch (_) {}
            return null;
        }
    }

    function p2(n) { return (n < 10 ? "0" : "") + n; }
    function tsOf(t) {
        var d = new Date(t);
        return p2(d.getHours()) + ":" + p2(d.getMinutes()) + ":" + p2(d.getSeconds());
    }
    function esc(s) {
        return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
            return c === "&" ? "&amp;" : c === "<" ? "&lt;" : c === ">" ? "&gt;" :
                   c === '"' ? "&quot;" : "&#39;";
        });
    }
    function el(tag, cls, html) {
        var e = document.createElement(tag);
        if (cls) e.className = cls;
        if (html != null) setHTMLSafe(e, html);
        return e;
    }

    var DEFAULT_CFG = {
        enabled: true, css: true, dom: true, network: true,
        popups: true, cookie: true, cookieAuto: true, overlay: true,
        release: true, antiDetect: true, youtube: true
    };

    var CFG = (function () {
        var stored = sget(CFG_KEY, null);
        var out = {};
        var k;
        for (k in DEFAULT_CFG) {
            if (Object.prototype.hasOwnProperty.call(DEFAULT_CFG, k)) {
                out[k] = (stored && typeof stored === "object" && k in stored)
                    ? !!stored[k] : DEFAULT_CFG[k];
            }
        }
        return out;
    })();

    function saveCfg() { sset(CFG_KEY, CFG); }

    var SITES = sget(SITE_KEY, []);
    if (!Array.isArray(SITES)) SITES = [];

    var STAT = (function () {
        var s = sget(STAT_KEY, null);
        if (s && typeof s === "object") {
            if (!Array.isArray(s.recent)) s.recent = [];
            return s;
        }
        return { total: 0, css: 0, dom: 0, network: 0, popup: 0, cookie: 0, overlay: 0, recent: [] };
    })();
    if (typeof STAT.total !== "number") STAT.total = 0;
    if (typeof STAT.css !== "number") STAT.css = 0;
    if (typeof STAT.dom !== "number") STAT.dom = 0;
    if (typeof STAT.network !== "number") STAT.network = 0;
    if (typeof STAT.popup !== "number") STAT.popup = 0;
    if (typeof STAT.cookie !== "number") STAT.cookie = 0;
    if (typeof STAT.overlay !== "number") STAT.overlay = 0;

    var statSaveT = 0;
    function statSave() {
        if (statSaveT) return;
        statSaveT = setTimeout(function () {
            statSaveT = 0;
            sset(STAT_KEY, STAT);
        }, STAT_SAVE_MS);
    }
    function statSaveNow() {
        if (statSaveT) { try { clearTimeout(statSaveT); } catch (e) {} statSaveT = 0; }
        sset(STAT_KEY, STAT);
    }

    function bump(kind, url) {
        STAT.total = (STAT.total || 0) + 1;
        if (typeof STAT[kind] === "number") STAT[kind]++;
        STAT.recent.unshift({ t: Date.now(), kind: kind, url: String(url || "").slice(0, 300) });
        if (STAT.recent.length > MAX_LOG) STAT.recent.length = MAX_LOG;
        statSave();
        if (uiState.open && (uiState.tab === "status" || uiState.tab === "log")) {
            uiScheduleRender();
        }
    }

    function statReset() {
        STAT = { total: 0, css: 0, dom: 0, network: 0, popup: 0, cookie: 0, overlay: 0, recent: [] };
        statSaveNow();
        if (uiState.open) uiScheduleRender();
    }

    function currentHost() {
        try { return String(location.hostname || "").toLowerCase(); } catch (e) { return ""; }
    }
    function isWhitelisted() {
        var h = currentHost();
        if (!h) return false;
        for (var i = 0; i < SITES.length; i++) if (SITES[i] === h) return true;
        return false;
    }
    function addSite(h) {
        h = String(h || "").toLowerCase();
        if (!h) return false;
        if (SITES.indexOf(h) >= 0) return false;
        if (SITES.length >= MAX_SITES) SITES.shift();
        SITES.push(h);
        sset(SITE_KEY, SITES);
        return true;
    }
    function removeSite(h) {
        h = String(h || "").toLowerCase();
        var i = SITES.indexOf(h);
        if (i < 0) return false;
        SITES.splice(i, 1);
        sset(SITE_KEY, SITES);
        return true;
    }

    var BLOCK_DOMAINS = [
        "doubleclick.net","googlesyndication.com","googleadservices.com",
        "googletagservices.com","googletagmanager.com","google-analytics.com",
        "adservice.google.com","2mdn.net","admob.com","googleadapis.com",
        "pagead2.googlesyndication.com","tpc.googlesyndication.com",
        "securepubads.g.doubleclick.net","adclick.g.doubleclick.net",
        "cm.g.doubleclick.net","stats.g.doubleclick.net","ssl.google-analytics.com",
        "app-measurement.com","amazon-adsystem.com","assoc-amazon.com",
        "assoc-amazon.jp","aax.amazon-adsystem.com","c.amazon-adsystem.com",
        "mads.amazon-adsystem.com","s.amazon-adsystem.com","fls-na.amazon.com",
        "unagi.amazon.com","ads.yahoo.com","ad.yahoo.com","yads.c.yimg.jp",
        "adtech.yahooinc.com","ads.yahoo.co.jp","adserver.yahoo.com",
        "log.fc.yahoo.co.jp","yjtag.yahoo.co.jp","yads.yahoo.co.jp",
        "i-mobile.co.jp","nend.net","adstir.com","fluct.jp","geniee.co.jp",
        "logly.co.jp","microad.jp","microad.net","smartnews-ads.com",
        "ad.about.co.jp","adcolony.com","adingo.jp","adlantis.jp","amoad.com",
        "amoad.net","apester.com","ccc-fc.com","d2c.co.jp","everesttech.net",
        "fancrew.jp","gmossp-sp.jp","i2i.jp","im-apps.net","impact-ad.jp",
        "insnative.com","karte.io","maio.jp","o2on.jp","open8.com","popin.cc",
        "scaleout.co.jp","shinobi.jp","ssp.geniee.co.jp","valuecommerce.com",
        "weave-corp.com","x-locations.com","zucks.net","ad-mobile.jp",
        "taboola.com","taboolanews.com","outbrain.com","criteo.com","criteo.net",
        "pubmatic.com","rubiconproject.com","magnite.com","openx.net",
        "adnxs.com","adnxs-simple.com","adsrvr.org","casalemedia.com",
        "contextweb.com","crwdcntrl.net","demdex.net","exelator.com",
        "lijit.com","mathtag.com","ml314.com","nexac.com","turn.com",
        "360yield.com","bluekai.com","agkn.com","adsafeprotected.com",
        "moatads.com","scorecardresearch.com","quantserve.com",
        "addthis.com","sharethis.com","adform.net","adroll.com","bidswitch.net",
        "brightroll.com","conversantmedia.com","dotomi.com","doubleverify.com",
        "e-planning.net","eyeota.net","ezoic.net","freewheel.tv","gumgum.com",
        "indexexchange.com","inmobi.com","integralads.com","iponweb.net",
        "lotame.com","media.net","mediamath.com","mookie1.com","nativo.com",
        "netmng.com","nrich.ai","omnitagjs.com","onetrust.com","optimizely.com",
        "owneriq.net","pippio.com","pool.admedo.com","rlcdn.com","rtbhouse.com",
        "serving-sys.com","sharethrough.com","simpli.fi","smaato.net",
        "sonobi.com","sovrn.com","spotxchange.com","stackadapt.com",
        "tapad.com","teads.tv","thetradedesk.com","tidaltv.com",
        "tribalfusion.com","triplelift.com","trustedstack.com","tremorhub.com",
        "valueclick.com","vungle.com","yumenetworks.com","zedo.com","zeotap.com",
        "popads.net","popcash.net","propellerads.com","propellerpops.com",
        "adcash.com","popmyads.com","onclickads.net","clickadu.com",
        "hilltopads.net","adsterra.com","exoclick.com","juicyads.com",
        "trafficjunky.net","trafficstars.com","popunder.ru","popunderjs.com",
        "adf.ly","linkbucks.com","sh.st","admy.link","ouo.io","bc.vc","shorte.st",
        "hotjar.com","mouseflow.com","fullstory.com","clarity.ms","newrelic.com",
        "bugsnag.com","sentry.io","mixpanel.com","amplitude.com","segment.io",
        "segment.com","heap.io","kissmetrics.com","matomo.cloud",
        "statcounter.com","umami.is","plausible.io","mc.yandex.ru",
        "metrika.yandex.ru","appmetrica.yandex.net","connect.facebook.net",
        "platform.twitter.com","platform.instagram.com","platform.linkedin.com",
        "onesignal.com","pushengage.com","pushwoosh.com","cleverpush.com",
        "webpushr.com","izooto.com","pushnami.com","sendpulse.com",
        "adnium.com","bidvertiser.com","buysellads.com","chitika.com",
        "clickbank.net","clicksor.com","commission-junction.com",
        "conversant.com","cpalead.com","dapper.net","engagebdr.com",
        "epom.com","infolinks.com","kargo.com","kontera.com","liveintent.com",
        "liverail.com","loopme.me","magnetic.com","mediavoice.com","nexage.com",
        "nuffnang.com","peer39.com","pixalate.com","platform161.com",
        "pulsepoint.com","revcontent.com","rhythmone.com","rocketfuel.com",
        "sekindo.com","smartadserver.com","sociomantic.com","spotx.tv",
        "sprintrade.com","stickyadstv.com","switchconcepts.com","tapjoy.com",
        "teracent.com","tremorvideo.com","undertone.com","vindico.com",
        "visiblemeasures.com","yieldbot.com","yieldmo.com","yieldoptimizer.com",
        "zergnet.com","zemanta.com","ziffdavis.com","adfox.ru","adfox.yandex.ru",
        "an.yandex.ru","awaps.yandex.ru","ads.adfox.ru","banners.adfox.ru",
        "ads.rambler.ru","ad.dumedia.ru","ads.digitalcaramel.com",
        "adv.badbonce.com","ad.mail.ru","r.mail.ru","ads.imgsmail.ru","adx.com.ru"
    ];

    var BLOCK_PATHS = [
        "\\/(ads?|adx|adv|adserv|adserver|adservice|adframe|adtech)(\\/|\\?|\\.|$)",
        "\\/ad[-_]?(banner|slot|unit|frame|serve|serv|img|image|loader|script|js|iframe|box|block|wrap|container)(\\/|\\?|\\.|$)",
        "\\/banners?(\\/|\\?|\\.|$)",
        "\\/popunder(s)?(\\/|\\?|\\.|$)",
        "\\/pop[-_]?up(s)?(\\/|\\?|\\.|$)",
        "\\/interstitial(s)?(\\/|\\?|\\.|$)",
        "\\/track(ing|er)?(\\/|\\?|\\.|$)",
        "\\/analytics?(\\/|\\?|\\.|$)",
        "\\/pixel(s)?(\\/|\\?|\\.|$)",
        "\\/beacon(s)?(\\/|\\?|\\.|$)",
        "\\/telemetry(\\/|\\?|\\.|$)",
        "\\/sponsor(ed|ship)?(\\/|\\?|\\.|$)",
        "\\/campaign(s)?(\\/|\\?|\\.|$)",
        "\\/promo(tion)?s?(\\/|\\?|\\.|$)",
        "\\/pagead(\\/|\\?|\\.|$)",
        "\\/(adsbygoogle|adsense|adview|advert)(\\/|\\?|\\.|$)",
        "\\/gtm(\\.js|\\?|$)",
        "\\/gtag(\\/|\\?|\\.|$)",
        "\\/gtm\\.js",
        "\\/fbevents(\\.js|\\?|$)",
        "\\/fbq(\\.js|\\?|$)",
        "\\/ga\\.js",
        "\\/piwik\\.(js|php)",
        "\\/matomo\\.(js|php)",
        "\\/hotjar-",
        "\\/clarity\\.js",
        "\\/optimizely\\.js",
        "\\/doubleclick",
        "\\/prebid",
        "\\/gpt\\.js",
        "\\/pubads_impl",
        "\\/ima3\\.js",
        "\\/yieldmo",
        "\\/adchoices",
        "\\/adchoices\\.png",
        "\\/pagead\\/js",
        "\\/pagead2\\.googlesyndication",
        "\\/aclk\\?",
        "\\/pagead\\/aclk",
        "\\/gen_204\\?",
        "[?&]utm_(source|medium|campaign|term|content)=",
        "[?&]gclid=",
        "[?&]fbclid=",
        "[?&]yclid=",
        "[?&]msclkid="
    ];

    var AD_SELECTORS = [
        "ins.adsbygoogle",
        '[id^="google_ads_"]','[id^="aswift_"]','[id^="div-gpt-ad"]',
        '[id^="google_ads_iframe"]','[id^="taboola-"]','[id^="outbrain-"]',
        '[id^="criteo-"]','[id^="amzn_assoc_"]','[id*="-ad-"]','[id*="ad-slot"]',
        '[id*="ad_slot"]','[id*="ad-banner"]','[id*="ad_banner"]','[id*="advert"]',
        '[id*="banner-ad"]','[id*="banner_ad"]','[id*="sponsored"]','[id*="criteo"]',
        '[id*="popunder"]','[id*="pop-under"]','[id*="pop_up"]','[id*="interstitial"]',
        '[id*="adunit"]','[id*="ad_unit"]','[id*="adsense"]','[id*="adframe"]',
        '[id*="dfp-"]','[id^="dfp"]','[id*="gpt-passback"]','[id*="adfox"]',
        '[class*="ad-slot"]','[class*="ad_slot"]','[class*="ad-banner"]',
        '[class*="ad_banner"]','[class*="adsbygoogle"]','[class*="advert"]',
        '[class*="adsbox"]','[class*="ad-container"]','[class*="ad_container"]',
        '[class*="ad-wrapper"]','[class*="ad_wrapper"]','[class*="ad-holder"]',
        '[class*="ad_holder"]','[class*="banner-ad"]','[class*="banner_ad"]',
        '[class*="sponsored"]','[class*="sponsor-"]','[class*="sponsor_"]',
        '[class*="taboola"]','[class*="outbrain"]','[class*="criteo"]',
        '[class*="adsense"]','[class*="adunit"]','[class*="ad_unit"]',
        '[class*="popunder"]','[class*="pop-under"]','[class*="pop-up-ad"]',
        '[class*="popup-ad"]','[class*="interstitial"]','[class*="ad-frame"]',
        '[class*="ad_frame"]','[class*="dfp-"]','[class*="gpt-ad"]',
        '[class*="adbox"]','[class*="ad-box"]','[class*="ad_box"]',
        '[class*="adlabel"]','[class*="ad-label"]','[class*="ad_label"]',
        '[class*="adchoices"]','[class*="ad-choice"]','[class*="adChoice"]',
        '[class*="adloading"]','[class*="ad-loading"]','[class*="adLoading"]',
        '[class*="adplaceholder"]','[class*="ad-placeholder"]',
        '[class*="ad-placement"]','[class*="ad_placement"]',
        '[class*="affiliate-ad"]','[class*="affiliate_ad"]',
        '[class*="google-ad"]','[class*="google_ad"]','[class*="googleAd"]',
        '[class*="ads-wrapper"]','[aria-label="advertisement"]',
        '[aria-label="Advertisement"]','[aria-label="広告"]','[aria-label="ad"]',
        '[aria-label="Ad"]','[data-ad]','[data-ad-slot]','[data-ad-client]',
        '[data-google-query-id]','[data-ad-unit]','[data-adunit]',
        '[data-advertisement]',
        'iframe[src*="doubleclick.net"]','iframe[src*="googlesyndication.com"]',
        'iframe[src*="googleadservices.com"]','iframe[src*="amazon-adsystem.com"]',
        'iframe[src*="ad.yahoo"]','iframe[src*="ads.yahoo"]',
        'iframe[src*="taboola"]','iframe[src*="outbrain"]','iframe[src*="criteo"]',
        'iframe[src*="/ad/"]','iframe[src*="/ads/"]','iframe[src*="adframe"]',
        'iframe[src*="adserv"]','iframe[src*="/adv/"]','iframe[src*="prebid"]',
        'iframe[id*="google_ads"]','iframe[id*="aswift"]','iframe[id*="adframe"]',
        'iframe[name*="google_ads"]','iframe[name*="aswift"]',
        'iframe[title*="advert"]','iframe[title*="Advertisement"]',
        'iframe[title*="広告"]','iframe[title*="ad"]',
        'iframe[src*="connect.facebook.net"]','iframe[src*="platform.twitter.com"]',
        'iframe[src*="platform.instagram.com"]','iframe[src*="platform.linkedin.com"]',
        ".video-ads",".ytp-ad-module",".ytp-ad-overlay-container",
        ".ytp-ad-text",".ytp-ad-image-overlay",".ytp-ad-progress",
        "#player-ads","#masthead-ad","ytd-promoted-sparkles-web-renderer",
        "ytd-display-ad-renderer","ytd-promoted-video-renderer",
        "ytd-in-feed-ad-layout-renderer","ytd-ad-slot-renderer",
        "ytd-banner-promo-renderer","ytd-statement-banner-renderer",
        ".ima-ad-container",'[class*="ima-ad"]','[id*="ima-ad"]',
        '[class*="newsletter-popup"]','[class*="subscribe-popup"]',
        '[class*="email-popup"]','[class*="push-notification"]',
        '[class*="push_notification"]','[class*="onesignal"]','[id*="onesignal"]',
        '[id*="pushcrew"]','[class*="pushcrew"]','[id*="cleverpush"]',
        '[class*="cleverpush"]','[id*="pushwoosh"]','[class*="pushwoosh"]',
        '[class*="webpushr"]','[id*="webpushr"]'
    ];

    var COOKIE_SELECTORS = [
        "#onetrust-banner-sdk","#onetrust-consent-sdk",".onetrust-pc-dark-filter",
        "#onetrust-pc-sdk",".optanon-alert-box-wrapper","#optanon",
        ".cookie-banner","#cookie-banner",".cookie-consent","#cookie-consent",
        ".cookie-notice","#cookie-notice",".cookie-bar","#cookie-bar",
        ".cookie-policy","#cookie-policy",".cookie-popup","#cookie-popup",
        ".cookie-message","#cookie-message",".cookie-warning","#cookie-warning",
        ".gdpr-banner","#gdpr-banner",".gdpr-consent","#gdpr-consent",
        ".gdpr-popup","#gdpr-popup",".gdpr-modal","#gdpr-modal",
        '[class*="cookie-consent"]','[class*="cookieConsent"]',
        '[class*="cookie-banner"]','[class*="cookieBanner"]',
        '[id*="cookie-consent"]','[id*="cookieConsent"]',
        '[id*="cookie-banner"]','[id*="cookieBanner"]',
        '[class*="CookieBanner"]','[id*="CookieBanner"]',
        '[class*="CookieConsent"]','[id*="CookieConsent"]',
        '[class*="CookieNotice"]','[id*="CookieNotice"]',
        '[class*="cc-window"]','[id*="cc-window"]','[class*="cc-banner"]',
        '[id*="sp_message"]','[class*="sp_message"]','[id*="sp-consent"]',
        '[id*="cmpbox"]','[class*="cmpbox"]','[id*="qc-cmp"]','[class*="qc-cmp"]',
        '[id*="didomi"]','[class*="didomi"]','[id*="truste"]','[class*="truste"]',
        '[id*="cookiebot"]','[class*="cookiebot"]','[id*="CybotCookiebot"]',
        '[class*="CybotCookiebot"]','[id*="iubenda"]','[class*="iubenda"]',
        '[class*="moove_gdpr"]','[id*="moove_gdpr"]','[class*="borlabs"]',
        '[class*="klaro"]','[id*="klaro"]','[class*="osano"]','[id*="osano"]',
        '[class*="termly"]','[id*="termly"]','[class*="cookieyes"]',
        '[id*="cookieyes"]','[class*="cookiehub"]','[id*="cookiehub"]'
    ];

    var OVERLAY_SELECTORS = [
        '[class*="modal-backdrop"]','[class*="modalBackdrop"]',
        '[class*="overlay-backdrop"]','[class*="popup-overlay"]',
        '[class*="paywall"]','[id*="paywall"]','[class*="subscribe-wall"]',
        '[class*="piano-modal"]','[id*="piano-modal"]','[class*="tp-modal"]',
        '[id*="tp-modal"]','[class*="exit-intent"]','[class*="exitIntent"]',
        '[id*="exit-intent"]'
    ];

    var COOKIE_TEXTS = [
        "同意する","同意","承諾","承認","許可","了解","OK","Ok","ok",
        "Accept","Accept All","Accept all","I Accept","I agree","Agree",
        "Allow All","Allow all","Got it","Got It","Close","Continue",
        "すべて同意","すべて許可","全て同意","全て許可","全て受け入れる",
        "同意して続ける","同意して閉じる","受け入れる"
    ];

    var BLOCK_RES = (function () {
        var out = [];
        var i;
        for (i = 0; i < BLOCK_DOMAINS.length; i++) {
            try {
                var d = BLOCK_DOMAINS[i].replace(/[.+?^${}()|[\]\\]/g, "\\$&");
                out.push(new RegExp("://([^/]*\\.)?" + d + "([:/]|$)", "i"));
            } catch (e) {}
        }
        for (i = 0; i < BLOCK_PATHS.length; i++) {
            try { out.push(new RegExp(BLOCK_PATHS[i], "i")); } catch (e) {}
        }
        return out;
    })();

    function shouldBlock(url) {
        if (!url) return false;
        var s = String(url);
        if (s.length < 5) return false;
        if (s.indexOf("data:") === 0) return false;
        if (s.indexOf("blob:") === 0) return false;
        if (s.indexOf("about:") === 0) return false;
        if (s.indexOf("javascript:") === 0) return false;
        for (var i = 0; i < BLOCK_RES.length; i++) {
            if (BLOCK_RES[i].test(s)) return true;
        }
        return false;
    }

    var abStyleEl = null;
    var SELECTOR_ALL = "";

    function rebuildSelector() {
        var l = AD_SELECTORS.slice();
        if (CFG.cookie) l = l.concat(COOKIE_SELECTORS);
        if (CFG.overlay) l = l.concat(OVERLAY_SELECTORS);
        SELECTOR_ALL = l.join(",");
    }
    rebuildSelector();

    function applyAbCSS() {
        safe(function () {
            if (abStyleEl && abStyleEl.parentNode) {
                try { abStyleEl.parentNode.removeChild(abStyleEl); } catch (e) {}
            }
            abStyleEl = null;
            if (!CFG.enabled || !CFG.css || isWhitelisted()) return;
            var list = AD_SELECTORS.slice();
            if (CFG.cookie) list = list.concat(COOKIE_SELECTORS);
            if (CFG.overlay) list = list.concat(OVERLAY_SELECTORS);
            var css = list.join(",") +
                "{display:none !important;visibility:hidden !important;" +
                "opacity:0 !important;pointer-events:none !important;" +
                "width:0 !important;height:0 !important;" +
                "position:absolute !important;left:-99999px !important;" +
                "max-width:0 !important;max-height:0 !important;" +
                "overflow:hidden !important;clip:rect(0,0,0,0) !important;" +
                "clip-path:inset(50%) !important;}";
            var st = document.createElement("style");
            st.setAttribute("data-coara-ab-css", "1");
            st.textContent = css;
            var target = document.head || document.documentElement;
            if (target) { target.appendChild(st); abStyleEl = st; }
            else {
                var mo = new MutationObserver(function () {
                    var t = document.head || document.documentElement;
                    if (t) { try { mo.disconnect(); } catch (e) {} t.appendChild(st); abStyleEl = st; }
                });
                try { mo.observe(document, { childList: true, subtree: true }); } catch (e) {}
            }
        });
    }

    function nuke(node, kind, src) {
        if (!node || node.nodeType !== 1) return;
        if (node.__coaraAb) return;
        if (node.id === HOST_ID) return;
        node.__coaraAb = true;
        var ok = false;
        try {
            if (node.parentNode) { node.parentNode.removeChild(node); ok = true; }
        } catch (e) {}
        if (!ok) {
            try { node.style.display = "none"; ok = true; } catch (e) {}
        }
        if (ok) bump(kind || "dom", src || (node.tagName ? node.tagName.toLowerCase() : ""));
    }

    function scan(root) {
        if (!CFG.enabled || !CFG.dom) return;
        if (isWhitelisted()) return;
        if (!root || root.nodeType !== 1) {
            root = document.documentElement;
            if (!root) return;
        }
        try {
            if (root.matches && root.matches(SELECTOR_ALL)) nuke(root, "dom");
        } catch (e) {}
        try {
            var list = root.querySelectorAll(SELECTOR_ALL);
            for (var i = 0; i < list.length; i++) nuke(list[i], "dom");
        } catch (e) {}
    }

    var obs = null;
    var pendingRoots = [];
    var flushT = 0;

    function flushObserver() {
        flushT = 0;
        var roots = pendingRoots;
        pendingRoots = [];
        for (var i = 0; i < roots.length; i++) scan(roots[i]);
    }

    function startObserver() {
        if (obs) return;
        if (!document.documentElement) return;
        safe(function () {
            obs = new MutationObserver(function (muts) {
                for (var i = 0; i < muts.length; i++) {
                    var m = muts[i];
                    if (m.type === "childList") {
                        for (var j = 0; j < m.addedNodes.length; j++) {
                            var n = m.addedNodes[j];
                            if (n.nodeType === 1) pendingRoots.push(n);
                        }
                    } else if (m.type === "attributes" && m.target) {
                        pendingRoots.push(m.target);
                    }
                }
                if (pendingRoots.length && !flushT) flushT = setTimeout(flushObserver, 60);
            });
            obs.observe(document.documentElement, {
                childList: true, subtree: true,
                attributes: true,
                attributeFilter: ["src", "href", "style", "class", "id"]
            });
        });
    }

    function autoCookie() {
        if (!CFG.enabled || !CFG.cookie || !CFG.cookieAuto) return;
        if (isWhitelisted()) return;
        var sels = [
            "#onetrust-accept-btn-handler","#onetrust-reject-all-handler",
            ".onetrust-close-btn-handler","#accept-cookie-notification",
            "#cookie-accept","#cookieAccept","#accept-cookies",
            "#cookie-consent-accept","#cookie_consent_accept",
            ".cookie-accept",".cookieAccept",".accept-cookies",
            ".cc-allow",".cc-accept",".cc-btn.cc-allow",".cc-dismiss",
            "#hs-eu-confirmation-button","#hs-eu-decline-button",
            '[data-testid="cookie-policy-manage-dialog-accept-button"]',
            '[data-testid="cookie-policy-dialog-accept-button"]',
            '[data-testid="uc-accept-all-button"]',
            '[data-testid="uc-deny-all-button"]',
            '[aria-label="Accept cookies"]','[aria-label="Accept all cookies"]',
            '[aria-label="Accept All"]','[aria-label="同意する"]',
            '[aria-label="同意"]','[aria-label="同意して閉じる"]',
            "#CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll",
            "#CybotCookiebotDialogBodyButtonAccept",
            "#CybotCookiebotDialogBodyButtonDecline",
            '.qc-cmp2-summary-buttons > button[mode="primary"]',
            '.qc-cmp2-summary-buttons > button[mode="secondary"]',
            ".fc-cta-consent",".fc-button.fc-cta-consent",
            ".iubenda-cs-accept-btn",".iubenda-cs-reject-btn",
            ".cmplz-accept",".cmplz-deny",".cmplz-btn.cmplz-accept",
            "#cmplz-cookiebanner-container .cmplz-accept",
            "#moove_gdpr_cookie_info_bar .moove-gdpr-infobar-allow-all",
            ".cli_action_button.cli_action_accept",
            ".cli_action_button.cli_action_reject",
            "#didomi-notice-agree-button","#didomi-notice-disagree-button",
            ".didomi-continue-without-agreeing",
            "#truste-consent-button","#truste-consent-required",
            ".termly-consent-preferences-accept-all",
            ".cky-btn-accept",".cky-btn-reject",
            ".osano-cm-accept-all",".osano-cm-deny-all",
            ".js-cookie-consent-agree",".js-cookie-consent-decline"
        ];
        var nodes = [];
        var i, k;
        for (i = 0; i < sels.length; i++) {
            try {
                var f = document.querySelectorAll(sels[i]);
                for (k = 0; k < f.length; k++) nodes.push(f[k]);
            } catch (e) {}
        }
        try {
            var btns = document.querySelectorAll('button, a[role="button"], [role="button"]');
            for (var b = 0; b < btns.length; b++) {
                var btn = btns[b];
                var txt = (btn.textContent || "").trim();
                if (!txt || txt.length > 40) continue;
                for (var t = 0; t < COOKIE_TEXTS.length; t++) {
                    if (txt === COOKIE_TEXTS[t]) { nodes.push(btn); break; }
                }
            }
        } catch (e) {}
        for (var n = 0; n < nodes.length; n++) {
            try {
                var elm = nodes[n];
                if (elm && !elm.__coaraCookie) {
                    elm.__coaraCookie = true;
                    elm.click();
                    bump("cookie", "cookie-accept");
                }
            } catch (e) {}
        }
    }

    function removeOverlays() {
        if (!CFG.enabled || !CFG.overlay) return;
        if (isWhitelisted()) return;
        try {
            var locked = document.querySelectorAll(
                '[class*="scroll-lock"],[class*="no-scroll"],[class*="overflow-hidden"]'
            );
            for (var i = 0; i < locked.length; i++) {
                try {
                    locked[i].classList.remove("scroll-lock");
                    locked[i].classList.remove("no-scroll");
                    locked[i].classList.remove("overflow-hidden");
                } catch (e) {}
            }
        } catch (e) {}
        try {
            if (document.body && document.body.style.overflow === "hidden") {
                document.body.style.overflow = "";
            }
            if (document.documentElement && document.documentElement.style.overflow === "hidden") {
                document.documentElement.style.overflow = "";
            }
        } catch (e) {}
    }

    var releaseDone = false;
    function releaseProtect() {
        if (releaseDone) return;
        if (!CFG.enabled || !CFG.release) return;
        releaseDone = true;
        try { document.oncontextmenu = null; } catch (e) {}
        try { document.onselectstart = null; } catch (e) {}
        try { document.ondragstart = null; } catch (e) {}
        try { document.oncopy = null; } catch (e) {}
        try { document.oncut = null; } catch (e) {}
        try { document.onpaste = null; } catch (e) {}
        try { if (document.body) document.body.oncontextmenu = null; } catch (e) {}
        try {
            var st = document.createElement("style");
            st.setAttribute("data-coara-release", "1");
            st.textContent =
                "*{-webkit-touch-callout:default !important;" +
                "-webkit-user-select:text !important;" +
                "user-select:text !important;}";
            var target = document.head || document.documentElement;
            if (target) target.appendChild(st);
        } catch (e) {}
    }

    function buildPageInject() {
        var fn = function (domains, paths, opts) {
            try {
                if (window.__coaraAbNet) return;
                window.__coaraAbNet = true;
                var RES = [];
                var i;
                for (i = 0; i < domains.length; i++) {
                    try {
                        var d = domains[i].replace(/[.+?^${}()|[\]\\]/g, "\\$&");
                        RES.push(new RegExp("://([^/]*\\.)?" + d + "([:/]|$)", "i"));
                    } catch (e) {}
                }
                for (i = 0; i < paths.length; i++) {
                    try { RES.push(new RegExp(paths[i], "i")); } catch (e) {}
                }
                function hit(url) {
                    if (!url) return false;
                    var s = String(url);
                    if (s.length < 5) return false;
                    if (s.indexOf("data:") === 0) return false;
                    if (s.indexOf("blob:") === 0) return false;
                    if (s.indexOf("about:") === 0) return false;
                    if (s.indexOf("javascript:") === 0) return false;
                    for (var k = 0; k < RES.length; k++) {
                        try { if (RES[k].test(s)) return true; } catch (e) {}
                    }
                    return false;
                }
                function report(u) {
                    try {
                        window.dispatchEvent(new CustomEvent("coara-ab-block", { detail: String(u).slice(0, 300) }));
                    } catch (e) {}
                }
                function noop() {}
                try {
                    var _fetch = window.fetch;
                    if (_fetch) {
                        window.fetch = function (input) {
                            try {
                                var url = "";
                                if (typeof input === "string") url = input;
                                else if (input && input.url) url = input.url;
                                if (hit(url)) {
                                    report(url);
                                    return Promise.resolve(new Response("", {
                                        status: 204, statusText: "No Content", headers: new Headers()
                                    }));
                                }
                            } catch (e) {}
                            return _fetch.apply(this, arguments);
                        };
                    }
                } catch (e) {}
                try {
                    var _xo = XMLHttpRequest.prototype.open;
                    var _xs = XMLHttpRequest.prototype.send;
                    XMLHttpRequest.prototype.open = function (m, u) {
                        try { this.__abB = hit(u); if (this.__abB) report(u); }
                        catch (e) { this.__abB = false; }
                        return _xo.apply(this, arguments);
                    };
                    XMLHttpRequest.prototype.send = function () {
                        var x = this;
                        if (x.__abB) {
                            setTimeout(function () {
                                try {
                                    try { Object.defineProperty(x, "readyState", { value: 4, configurable: true }); } catch (e) {}
                                    try { Object.defineProperty(x, "status", { value: 204, configurable: true }); } catch (e) {}
                                    try { Object.defineProperty(x, "statusText", { value: "No Content", configurable: true }); } catch (e) {}
                                    try { Object.defineProperty(x, "responseText", { value: "", configurable: true }); } catch (e) {}
                                    try { Object.defineProperty(x, "response", { value: "", configurable: true }); } catch (e) {}
                                    try { x.dispatchEvent(new Event("readystatechange")); } catch (e) {}
                                    try { x.dispatchEvent(new Event("load")); } catch (e) {}
                                    try { x.dispatchEvent(new Event("loadend")); } catch (e) {}
                                    try { if (typeof x.onreadystatechange === "function") x.onreadystatechange(); } catch (e) {}
                                    try { if (typeof x.onload === "function") x.onload(); } catch (e) {}
                                    try { if (typeof x.onloadend === "function") x.onloadend(); } catch (e) {}
                                } catch (e) {}
                            }, 0);
                            return;
                        }
                        return _xs.apply(this, arguments);
                    };
                } catch (e) {}
                try {
                    if (navigator.sendBeacon) {
                        var _b = navigator.sendBeacon.bind(navigator);
                        navigator.sendBeacon = function (url, data) {
                            try { if (hit(url)) { report(url); return true; } } catch (e) {}
                            return _b(url, data);
                        };
                    }
                } catch (e) {}
                try {
                    var _WS = window.WebSocket;
                    if (_WS) {
                        var WP = function (url, proto) {
                            if (hit(url)) {
                                report(url);
                                return { readyState: 3, url: url, protocol: "", bufferedAmount: 0,
                                         extensions: "", binaryType: "blob",
                                         close: noop, send: noop,
                                         addEventListener: noop, removeEventListener: noop,
                                         dispatchEvent: function () { return false; } };
                            }
                            return proto !== undefined ? new _WS(url, proto) : new _WS(url);
                        };
                        WP.prototype = _WS.prototype;
                        try {
                            WP.CONNECTING = _WS.CONNECTING; WP.OPEN = _WS.OPEN;
                            WP.CLOSING = _WS.CLOSING; WP.CLOSED = _WS.CLOSED;
                        } catch (e) {}
                        window.WebSocket = WP;
                    }
                } catch (e) {}
                try {
                    var _ES = window.EventSource;
                    if (_ES) {
                        window.EventSource = function (url, cfg) {
                            if (hit(url)) {
                                report(url);
                                return { url: url, readyState: 2, withCredentials: false,
                                         close: noop, addEventListener: noop,
                                         removeEventListener: noop,
                                         dispatchEvent: function () { return false; } };
                            }
                            return new _ES(url, cfg);
                        };
                        try { window.EventSource.prototype = _ES.prototype; } catch (e) {}
                    }
                } catch (e) {}
                try {
                    if (opts.popups) {
                        var _wo = window.open;
                        window.open = function (url) {
                            if (hit(url)) { report(url); return null; }
                            if (!url) { report("popup-empty"); return null; }
                            return _wo.apply(this, arguments);
                        };
                    }
                } catch (e) {}
                try {
                    var _sa = Element.prototype.setAttribute;
                    Element.prototype.setAttribute = function (name, value) {
                        try {
                            var tag = this.tagName;
                            var n = String(name).toLowerCase();
                            if ((tag === "SCRIPT" && n === "src") ||
                                (tag === "IFRAME" && n === "src") ||
                                (tag === "IMG" && n === "src") ||
                                (tag === "LINK" && n === "href") ||
                                (tag === "SOURCE" && n === "src") ||
                                (tag === "EMBED" && n === "src") ||
                                (tag === "OBJECT" && n === "data")) {
                                if (hit(value)) {
                                    report(value);
                                    if (tag === "SCRIPT") this.type = "javascript/blocked";
                                    else if (tag === "IFRAME" || tag === "IMG") this.style.display = "none";
                                    this.__abB = true;
                                    return;
                                }
                            }
                        } catch (e) {}
                        return _sa.apply(this, arguments);
                    };
                } catch (e) {}
                function patchSrc(proto, prop) {
                    try {
                        var d = Object.getOwnPropertyDescriptor(proto, prop);
                        if (!d || !d.set) return;
                        Object.defineProperty(proto, prop, {
                            get: d.get,
                            set: function (v) {
                                if (hit(v)) {
                                    report(v);
                                    try { this.__abB = true; } catch (e) {}
                                    return;
                                }
                                return d.set.call(this, v);
                            },
                            configurable: true
                        });
                    } catch (e) {}
                }
                try { if (window.HTMLScriptElement) patchSrc(HTMLScriptElement.prototype, "src"); } catch (e) {}
                try { if (window.HTMLIFrameElement) patchSrc(HTMLIFrameElement.prototype, "src"); } catch (e) {}
                try { if (window.HTMLImageElement) patchSrc(HTMLImageElement.prototype, "src"); } catch (e) {}
                try { if (window.HTMLLinkElement) patchSrc(HTMLLinkElement.prototype, "href"); } catch (e) {}
                try { if (window.HTMLSourceElement) patchSrc(HTMLSourceElement.prototype, "src"); } catch (e) {}
                try { if (window.HTMLVideoElement) patchSrc(HTMLVideoElement.prototype, "src"); } catch (e) {}
                try { if (window.HTMLAudioElement) patchSrc(HTMLAudioElement.prototype, "src"); } catch (e) {}
                try { if (window.HTMLEmbedElement) patchSrc(HTMLEmbedElement.prototype, "src"); } catch (e) {}
                function filt(html) {
                    if (!html) return "";
                    var s = String(html);
                    try {
                        s = s.replace(/<script[^>]+src=["']([^"']+)["'][^>]*>\s*<\/script>/gi,
                            function (m, u) { if (hit(u)) { report(u); return ""; } return m; });
                        s = s.replace(/<iframe[^>]+src=["']([^"']+)["'][^>]*>/gi,
                            function (m, u) { if (hit(u)) { report(u); return ""; } return m; });
                    } catch (e) {}
                    return s;
                }
                try {
                    var _dw = document.write;
                    document.write = function () {
                        try {
                            var args = [].slice.call(arguments);
                            for (var i = 0; i < args.length; i++) args[i] = filt(args[i]);
                            return _dw.apply(document, args);
                        } catch (e) { return _dw.apply(document, arguments); }
                    };
                } catch (e) {}
                try {
                    var _dwl = document.writeln;
                    if (_dwl) {
                        document.writeln = function () {
                            try {
                                var args = [].slice.call(arguments);
                                for (var i = 0; i < args.length; i++) args[i] = filt(args[i]);
                                return _dwl.apply(document, args);
                            } catch (e) { return _dwl.apply(document, arguments); }
                        };
                    }
                } catch (e) {}
                try {
                    if (opts.popups) {
                        var _hp = history.pushState;
                        var _hr = history.replaceState;
                        history.pushState = function (state, title, url) {
                            if (url && hit(url)) return;
                            return _hp.apply(this, arguments);
                        };
                        history.replaceState = function (state, title, url) {
                            if (url && hit(url)) return;
                            return _hr.apply(this, arguments);
                        };
                    }
                } catch (e) {}
                try {
                    Object.defineProperty(window, "onbeforeunload", {
                        get: function () { return null; },
                        set: function () {},
                        configurable: true
                    });
                } catch (e) {}
                try {
                    if (window.Notification && Notification.requestPermission) {
                        Notification.requestPermission = function () {
                            return Promise.resolve("denied");
                        };
                    }
                } catch (e) {}
                try {
                    if (navigator.permissions && navigator.permissions.query) {
                        var _pq = navigator.permissions.query.bind(navigator.permissions);
                        navigator.permissions.query = function (desc) {
                            try {
                                if (desc && (desc.name === "notifications" ||
                                             desc.name === "geolocation")) {
                                    return Promise.resolve({
                                        state: "denied", status: "denied", onchange: null,
                                        addEventListener: noop, removeEventListener: noop
                                    });
                                }
                            } catch (e) {}
                            return _pq(desc);
                        };
                    }
                } catch (e) {}
                try {
                    if (navigator.geolocation) {
                        navigator.geolocation.getCurrentPosition = function (ok, err) {
                            if (err) setTimeout(function () {
                                err({ code: 1, message: "User denied Geolocation" });
                            }, 0);
                        };
                        navigator.geolocation.watchPosition = function () { return 0; };
                        navigator.geolocation.clearWatch = noop;
                    }
                } catch (e) {}
                try {
                    if (window.DOMParser) {
                        var _DP = window.DOMParser;
                        window.DOMParser = function () {
                            var p = new _DP();
                            var orig = p.parseFromString.bind(p);
                            p.parseFromString = function (str, mime) {
                                return orig(filt(str), mime);
                            };
                            return p;
                        };
                        window.DOMParser.prototype = _DP.prototype;
                    }
                } catch (e) {}
                try {
                    var _de = EventTarget.prototype.dispatchEvent;
                    EventTarget.prototype.dispatchEvent = function (ev) {
                        if (ev && ev.type === "beforeunload") return true;
                        return _de.apply(this, arguments);
                    };
                } catch (e) {}
                try {
                    if (document.documentElement) {
                        var mo = new MutationObserver(function (muts) {
                            for (var i = 0; i < muts.length; i++) {
                                var m = muts[i];
                                for (var j = 0; j < m.addedNodes.length; j++) {
                                    var n = m.addedNodes[j];
                                    if (n.nodeType !== 1) continue;
                                    var tag = n.tagName;
                                    if (tag === "IFRAME" || tag === "SCRIPT" ||
                                        tag === "IMG" || tag === "LINK" ||
                                        tag === "EMBED" || tag === "SOURCE") {
                                        var src = n.src || n.href ||
                                            n.getAttribute("src") || n.getAttribute("href");
                                        if (src && hit(src)) {
                                            report(src);
                                            try { n.remove(); } catch (e) {}
                                        }
                                    }
                                }
                            }
                        });
                        mo.observe(document.documentElement, { childList: true, subtree: true });
                    }
                } catch (e) {}
            } catch (e) {}
        };
        var args = [
            JSON.stringify(BLOCK_DOMAINS),
            JSON.stringify(BLOCK_PATHS),
            JSON.stringify({ popups: CFG.popups })
        ].join(",");
        return "(" + fn.toString() + ")(" + args + ");";
    }

    function buildAntiDetect() {
        var fn = function () {
            try {
                if (window.__coaraAbAnti) return;
                window.__coaraAbAnti = true;
                function isAd(el) {
                    try {
                        if (!el || !el.nodeType) return false;
                        var id = el.id || "";
                        var cls = (typeof el.className === "string") ? el.className : "";
                        var s = id + " " + cls;
                        if (!s) return false;
                        if (s.indexOf("adsbygoogle") !== -1) return true;
                        if (s.indexOf("google_ads") !== -1) return true;
                        if (s.indexOf("div-gpt-ad") !== -1) return true;
                        if (/^ad$|^ads$|^adsbox$|^ad-banner$|^adBanner$|^ad-placement$|^ad-placeholder$/i.test(id)) return true;
                        if (/(^|\s)(ad|ads|adsbox|ad-banner|ad-placement|adunit|ad-slot|advert|banner-ad|sponsored)(\s|$)/i.test(cls)) return true;
                        if (/^ad[-_]?(banner|box|slot|unit|frame|wrap|container|placeholder)/i.test(cls)) return true;
                        return false;
                    } catch (e) { return false; }
                }
                try {
                    var _bc = Element.prototype.getBoundingClientRect;
                    Element.prototype.getBoundingClientRect = function () {
                        if (isAd(this)) {
                            return { top: 0, left: 0, width: 300, height: 250,
                                     right: 300, bottom: 250, x: 0, y: 0,
                                     toJSON: function () { return this; } };
                        }
                        return _bc.apply(this, arguments);
                    };
                } catch (e) {}
                try {
                    var hO = Object.getOwnPropertyDescriptor(HTMLElement.prototype, "offsetHeight");
                    var hW = Object.getOwnPropertyDescriptor(HTMLElement.prototype, "offsetWidth");
                    if (hO && hO.get) Object.defineProperty(HTMLElement.prototype, "offsetHeight", {
                        get: function () { return isAd(this) ? 250 : hO.get.call(this); },
                        configurable: true
                    });
                    if (hW && hW.get) Object.defineProperty(HTMLElement.prototype, "offsetWidth", {
                        get: function () { return isAd(this) ? 300 : hW.get.call(this); },
                        configurable: true
                    });
                } catch (e) {}
                try { window.canRunAds = true; } catch (e) {}
                try { window.isAdBlockActive = false; } catch (e) {}
                try { window.adBlockDetected = false; } catch (e) {}
                try {
                    if (!window.adsbygoogle || !window.adsbygoogle.push) {
                        window.adsbygoogle = window.adsbygoogle || {};
                        window.adsbygoogle.loaded = true;
                        window.adsbygoogle.push = function () {};
                    }
                } catch (e) {}
                try {
                    window.googletag = window.googletag || {};
                    if (!window.googletag.cmd) window.googletag.cmd = [];
                    if (!window.googletag.cmd.push) window.googletag.cmd.push = function (f) { try { f(); } catch (e) {} };
                    if (!window.googletag.pubads) window.googletag.pubads = function () {
                        return { enableSingleRequest: function () {}, refresh: function () {},
                                 setTargeting: function () {}, disableInitialLoad: function () {},
                                 addEventListener: function () {}, collapseEmptyDivs: function () {} };
                    };
                    if (!window.googletag.enableServices) window.googletag.enableServices = function () {};
                    if (!window.googletag.defineSlot) window.googletag.defineSlot = function () {
                        return { addService: function () { return this; },
                                 setTargeting: function () { return this; } };
                    };
                    if (!window.googletag.display) window.googletag.display = function () {};
                    if (!window.googletag.destroySlots) window.googletag.destroySlots = function () {};
                } catch (e) {}
                try {
                    var names = ["blockAdBlock","BlockAdBlock","FuckAdBlock","fuckAdBlock",
                                 "SniffAdBlock","sniffAdBlock","DetectAdBlock","detectAdBlock"];
                    for (var ni = 0; ni < names.length; ni++) {
                        (function (n) {
                            try {
                                Object.defineProperty(window, n, {
                                    get: function () {
                                        return function () {
                                            var api = {
                                                onDetected: function () { return api; },
                                                onNotDetected: function (cb) { try { cb && cb(); } catch (e) {} return api; },
                                                setOption: function () { return api; },
                                                check: function () { return api; },
                                                detected: false
                                            };
                                            return api;
                                        };
                                    },
                                    configurable: true
                                });
                            } catch (e) {}
                        })(names[ni]);
                    }
                } catch (e) {}
                try { if (!window.ga) window.ga = function () {}; } catch (e) {}
                try {
                    if (!window.dataLayer) window.dataLayer = [];
                    if (!window.dataLayer.push) window.dataLayer.push = function () {};
                } catch (e) {}
                try { if (!window.gtag) window.gtag = function () {}; } catch (e) {}
                try { if (!window.fbq) window.fbq = function () {}; } catch (e) {}
                try { if (!window._fbq) window._fbq = function () {}; } catch (e) {}
            } catch (e) {}
        };
        return "(" + fn.toString() + ")();";
    }

    function injectInline(code) {
        safe(function () {
            var s = document.createElement("script");
            s.setAttribute("data-coara-ab-inject", "1");
            s.textContent = code;
            var target = document.head || document.documentElement;
            if (target) { target.appendChild(s); try { s.remove(); } catch (e) {} }
            else {
                var mo = new MutationObserver(function () {
                    var t = document.head || document.documentElement;
                    if (t) { try { mo.disconnect(); } catch (e) {} t.appendChild(s); try { s.remove(); } catch (e) {} }
                });
                try { mo.observe(document, { childList: true, subtree: true }); } catch (e) {}
            }
        });
    }

    function injectNetwork() {
        if (!CFG.enabled || !CFG.network) return;
        if (isWhitelisted()) return;
        injectInline(buildPageInject());
    }
    function injectAntiDetect() {
        if (!CFG.enabled || !CFG.antiDetect) return;
        if (isWhitelisted()) return;
        injectInline(buildAntiDetect());
    }

    var ytT = 0;
    function ytLoop() {
        if (!CFG.youtube || !CFG.enabled) return;
        try { if (location.hostname.indexOf("youtube.com") === -1) return; } catch (e) { return; }
        if (ytT) return;
        ytT = setInterval(function () {
            try {
                if (!CFG.youtube || !CFG.enabled) return;
                var sk = document.querySelectorAll(
                    ".ytp-ad-skip-button,.ytp-ad-skip-button-modern," +
                    ".ytp-skip-ad-button,.ytp-skip-ad-button-slot,.ytp-skip-ad button"
                );
                for (var i = 0; i < sk.length; i++) { try { sk[i].click(); bump("dom", "yt-skip"); } catch (e) {} }
                var cl = document.querySelectorAll(".ytp-ad-overlay-close-button,.ytp-ad-overlay-close-container");
                for (var j = 0; j < cl.length; j++) { try { cl[j].click(); } catch (e) {} }
                var playing = document.querySelector(".ad-showing,.ad-interrupting");
                if (playing) {
                    var v = document.querySelector("video");
                    if (v) {
                        try {
                            v.muted = true;
                            v.playbackRate = 16;
                            if (v.duration && isFinite(v.duration)) v.currentTime = v.duration;
                            bump("dom", "yt-ad-skip");
                        } catch (e) {}
                    }
                }
            } catch (e) {}
        }, 500);
    }

    var cleanerT = 0;
    function startCleaner() {
        if (cleanerT) clearInterval(cleanerT);
        cleanerT = setInterval(function () {
            try {
                if (!CFG.enabled) return;
                scan(document.body || document.documentElement);
                autoCookie();
                removeOverlays();
            } catch (e) {}
        }, 2500);
    }

    var lastUrl = "";
    var navT = 0;

    function onNavigate() {
        try {
            if (location.href === lastUrl) return;
            lastUrl = location.href;
        } catch (e) { return; }
        if (navT) { try { clearTimeout(navT); } catch (e) {} }
        navT = setTimeout(function () {
            navT = 0;
            safe(function () { scan(document.body || document.documentElement); });
            autoCookie();
            removeOverlays();
            if (CFG.enabled) {
                injectNetwork();
                injectAntiDetect();
            }
            ensureHost();
            if (uiState.open) {
                if (!panelEl || (shadowRoot && panelEl.getRootNode() !== shadowRoot)) {
                    panelEl = null;
                    panelBody = null;
                    panelTabBar = null;
                    uiState.open = false;
                    safe(buildPanel);
                } else {
                    uiScheduleRender();
                }
            }
        }, NAV_DEBOUNCE_MS);
    }

    function watchUrl() {
        try { lastUrl = location.href; } catch (e) {}
        try {
            var _push = history.pushState;
            var _repl = history.replaceState;
            history.pushState = function () {
                var r = _push.apply(this, arguments);
                try { setTimeout(onNavigate, 0); } catch (e) {}
                return r;
            };
            history.replaceState = function () {
                var r = _repl.apply(this, arguments);
                try { setTimeout(onNavigate, 0); } catch (e) {}
                return r;
            };
        } catch (e) {}
        try { window.addEventListener("popstate", function () { setTimeout(onNavigate, 0); }); } catch (e) {}
        try { window.addEventListener("hashchange", function () { setTimeout(onNavigate, 0); }); } catch (e) {}
        try { window.addEventListener("yt-navigate-finish", function () { setTimeout(onNavigate, 0); }); } catch (e) {}
        try { window.addEventListener("yt-page-data-updated", function () { setTimeout(onNavigate, 0); }); } catch (e) {}
        try { window.addEventListener("spfdone", function () { setTimeout(onNavigate, 0); }); } catch (e) {}
        setInterval(function () {
            try {
                if (location.href !== lastUrl) onNavigate();
            } catch (e) {}
        }, 700);
    }

    try {
        window.addEventListener("coara-ab-block", function (ev) {
            try { bump("network", ev.detail || ""); } catch (e) {}
        });
    } catch (e) {}

    var SHADOW_CSS = [
        ":host{all:initial;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;font-size:13px;line-height:1.45;color:#e8e8ec;-webkit-tap-highlight-color:transparent;}",
        "*,*::before,*::after{box-sizing:border-box;}",
        ".fab{position:fixed;width:52px;height:52px;border-radius:50%;background:linear-gradient(135deg,#e53935,#c62828);color:#fff;font-size:22px;border:0;cursor:pointer;display:flex;align-items:center;justify-content:center;box-shadow:0 6px 22px rgba(229,57,53,.55);user-select:none;-webkit-user-select:none;-webkit-tap-highlight-color:transparent;touch-action:none;padding:0;line-height:1;font-family:inherit;pointer-events:auto;will-change:left,top;transition:box-shadow .15s;}",
        ".fab.off{background:linear-gradient(135deg,#757575,#424242);}",
        ".fab:active{filter:brightness(1.1);}",
        ".fab.dragging{opacity:.9;filter:brightness(1.15);}",
        ".root{position:fixed;background:#0d0d12;color:#e8e8ec;font:13px/1.45 inherit;display:flex;flex-direction:column;overflow:hidden;border-radius:12px;box-shadow:0 12px 48px rgba(0,0,0,.6),0 0 0 1px rgba(255,255,255,.08);pointer-events:auto;min-width:260px;min-height:160px;}",
        ".root.max{border-radius:0;}",
        ".root.min .bar,.root.min .body,.root.min .foot,.root.min .resize{display:none;}",
        ".toolbar{display:flex;gap:2px;padding:4px;background:#1a1216;border-bottom:1px solid #2a1f24;align-items:center;flex-shrink:0;cursor:move;touch-action:none;border-top-left-radius:12px;border-top-right-radius:12px;user-select:none;-webkit-user-select:none;min-height:46px;position:relative;}",
        ".root.max .toolbar{border-top-left-radius:0;border-top-right-radius:0;}",
        ".grip{color:#7a5a5f;font-size:13px;padding:0 6px;flex-shrink:0;letter-spacing:-1px;line-height:1;}",
        ".title{flex:1;min-width:0;font-size:12px;color:#c8a8b0;padding:0 6px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;pointer-events:none;}",
        ".winbtn{width:38px;height:38px;display:flex;align-items:center;justify-content:center;border-radius:8px;color:#cfd6e0;font-size:16px;cursor:pointer;flex-shrink:0;line-height:1;user-select:none;padding:0;}",
        ".winbtn:active{background:rgba(255,255,255,.12);}",
        ".winbtn.close:active{background:rgba(220,40,40,.6);}",
        ".bar{display:flex;gap:2px;padding:6px 8px;background:#1a1216;border-bottom:1px solid #2a1f24;overflow-x:auto;flex-shrink:0;-webkit-overflow-scrolling:touch;}",
        ".bar::-webkit-scrollbar{height:3px;}",
        ".bar::-webkit-scrollbar-thumb{background:#444;border-radius:2px;}",
        ".tab{padding:7px 12px;border-radius:6px;cursor:pointer;white-space:nowrap;font-size:12px;color:#b8a8b0;user-select:none;border:1px solid transparent;flex-shrink:0;}",
        ".tab.on{background:#e53935;color:#fff;border-color:#e53935;}",
        ".body{flex:1;overflow-y:auto;overflow-x:hidden;padding:8px 10px 12px;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12px;-webkit-overflow-scrolling:touch;min-height:0;overscroll-behavior:contain;}",
        ".body::-webkit-scrollbar{width:6px;height:6px;}",
        ".body::-webkit-scrollbar-thumb{background:#444;border-radius:3px;}",
        ".foot{display:flex;gap:6px;padding:8px;border-top:1px solid #2a1f24;background:#1a1216;flex-shrink:0;flex-wrap:wrap;padding-bottom:calc(8px + env(safe-area-inset-bottom,0px));}",
        ".btn{padding:7px 11px;border-radius:6px;background:#22222e;border:1px solid #2e2e3c;color:#e8e8ec;font-size:12px;cursor:pointer;user-select:none;white-space:nowrap;font-family:inherit;}",
        ".btn:active{background:#2e2e3c;}",
        ".btn.pri{background:#e53935;border-color:#e53935;color:#fff;}",
        ".btn.dan{background:#c62828;border-color:#c62828;color:#fff;}",
        ".section{margin:8px 0 14px;}",
        ".sec-title{font-weight:600;color:#c8a8b0;margin:0 0 8px;font-size:12px;padding-bottom:4px;border-bottom:1px solid #2a1f24;text-transform:uppercase;letter-spacing:.5px;}",
        ".row{display:flex;gap:8px;padding:8px 6px;border-bottom:1px solid #1c1c26;align-items:center;justify-content:space-between;}",
        ".row:last-child{border-bottom:0;}",
        ".label{font-size:12px;color:#e0e0e8;flex:1;min-width:0;}",
        ".desc{font-size:10px;color:#7a8090;margin-top:2px;line-height:1.3;}",
        ".sw{position:relative;width:40px;height:22px;background:#444;border-radius:22px;cursor:pointer;flex-shrink:0;user-select:none;transition:background .2s;}",
        ".sw.on{background:#e53935;}",
        ".sw::after{content:'';position:absolute;top:2px;left:2px;width:18px;height:18px;background:#fff;border-radius:50%;transition:left .2s;}",
        ".sw.on::after{left:20px;}",
        ".metrics{display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:6px;margin:6px 0;}",
        ".metric{background:#14141c;border:1px solid #2a1f24;border-radius:8px;padding:10px;}",
        ".metric-k{font-size:10px;color:#7a8090;text-transform:uppercase;letter-spacing:.4px;margin-bottom:4px;}",
        ".metric-v{font-size:18px;color:#e8e8ec;font-weight:700;word-break:break-all;line-height:1;}",
        ".metric-v.good{color:#66bb6a;}",
        ".metric-v.bad{color:#ef5350;}",
        ".list{list-style:none;padding:0;margin:0;}",
        ".list li{padding:7px 8px;border-bottom:1px solid #1c1c26;font-size:11px;display:flex;gap:6px;align-items:center;flex-wrap:wrap;word-break:break-all;}",
        ".list li:last-child{border-bottom:0;}",
        ".item-url{flex:1;min-width:0;color:#aed581;word-break:break-all;font-size:11px;}",
        ".item-kind{font-size:9px;padding:2px 6px;border-radius:4px;background:#2a1f24;color:#e8b8b0;text-transform:uppercase;letter-spacing:.4px;flex-shrink:0;}",
        ".item-kind.css{background:#1e3a5c;color:#90caf9;}",
        ".item-kind.dom{background:#3a2a1e;color:#ffb74d;}",
        ".item-kind.network{background:#3a1e2a;color:#ef9a9a;}",
        ".item-kind.cookie{background:#1e3a2a;color:#a5d6a7;}",
        ".item-kind.overlay{background:#3a3a1e;color:#fff59d;}",
        ".item-t{color:#7a8090;font-size:10px;flex-shrink:0;}",
        ".empty{color:#6a7080;padding:20px;text-align:center;font-style:italic;}",
        ".input{flex:1;min-width:100px;padding:7px 10px;border-radius:6px;background:#050508;border:1px solid #2e2e3c;color:#e8e8ec;font:12px/1.2 inherit;outline:none;-webkit-appearance:none;}",
        ".input:focus{border-color:#e53935;}",
        ".flex{display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin-bottom:8px;}",
        ".resize{position:absolute;right:0;bottom:0;width:32px;height:32px;cursor:nwse-resize;z-index:5;touch-action:none;background:linear-gradient(135deg,transparent 48%,rgba(255,255,255,.14) 48%,rgba(255,255,255,.14) 56%,transparent 56%,transparent 64%,rgba(255,255,255,.14) 64%,rgba(255,255,255,.14) 72%,transparent 72%);border-bottom-right-radius:12px;}",
        ".root.max .resize{display:none;}",
        ".site-tag{display:inline-flex;align-items:center;gap:4px;padding:4px 8px;background:#22222e;border:1px solid #2e2e3c;border-radius:14px;font-size:11px;color:#cfd6e0;margin:3px 4px 3px 0;}",
        ".site-tag b{font-weight:500;color:#e0e0e8;}",
        ".site-tag .x{cursor:pointer;color:#ff8a80;font-weight:700;padding:0 2px;}",
        ".dim{color:#7a8090;font-size:11px;}",
        ".yes{color:#66bb6a;}",
        ".no{color:#ef5350;}"
    ].join("");

    function injectHostStyle() {
        try {
            var existing = document.getElementById(HOST_STYLE_ID);
            if (existing && existing.parentNode) existing.parentNode.removeChild(existing);
            var s = document.createElement("style");
            s.id = HOST_STYLE_ID;
            s.textContent =
                "#" + HOST_ID + "{" +
                "all:initial !important;" +
                "position:fixed !important;" +
                "top:0 !important;" +
                "left:0 !important;" +
                "width:0 !important;" +
                "height:0 !important;" +
                "margin:0 !important;" +
                "padding:0 !important;" +
                "border:0 !important;" +
                "background:transparent !important;" +
                "z-index:2147483647 !important;" +
                "pointer-events:none !important;" +
                "display:block !important;" +
                "visibility:visible !important;" +
                "opacity:1 !important;" +
                "transform:none !important;" +
                "filter:none !important;" +
                "perspective:none !important;" +
                "backdrop-filter:none !important;" +
                "will-change:auto !important;" +
                "contain:none !important;" +
                "clip:auto !important;" +
                "clip-path:none !important;" +
                "overflow:visible !important;" +
                "isolation:auto !important;" +
                "mix-blend-mode:normal !important;" +
                "inset:auto auto auto 0 !important;" +
                "}";
            (document.head || document.documentElement).appendChild(s);
        } catch (e) {}
    }

    function applyHostInlineStyle(host) {
        if (!host) return;
        try {
            host.style.cssText =
                "position:fixed !important;" +
                "top:0 !important;" +
                "left:0 !important;" +
                "width:0 !important;" +
                "height:0 !important;" +
                "margin:0 !important;" +
                "padding:0 !important;" +
                "border:0 !important;" +
                "background:transparent !important;" +
                "z-index:2147483647 !important;" +
                "pointer-events:none !important;" +
                "display:block !important;" +
                "visibility:visible !important;" +
                "opacity:1 !important;" +
                "transform:none !important;" +
                "clip:auto !important;" +
                "clip-path:none !important;" +
                "overflow:visible !important;";
        } catch (e) {}
    }

    function bindTap(elem, handler) {
        var touched = false;
        elem.addEventListener("touchstart", function (ev) { touched = true; ev.stopPropagation(); }, { passive: true });
        elem.addEventListener("touchend", function (ev) {
            ev.stopPropagation();
            if (ev.cancelable) ev.preventDefault();
            if (touched) handler(ev);
            setTimeout(function () { touched = false; }, 400);
        }, { passive: false });
        elem.addEventListener("click", function (ev) {
            if (touched) return;
            ev.stopPropagation();
            if (ev.cancelable) ev.preventDefault();
            handler(ev);
        });
    }

    function makeDraggable(handle, onStart, onMove, onEnd, noDragSelector) {
        var active = false;
        var sx = 0, sy = 0;
        function isNoDrag(target) {
            if (!noDragSelector || !target || !target.closest) return false;
            try { return !!target.closest(noDragSelector); } catch (e) { return false; }
        }
        function start(ev) {
            if (active) return;
            if (isNoDrag(ev.target)) return;
            var t = ev.touches ? ev.touches[0] : ev;
            if (!t) return;
            active = true;
            sx = t.clientX;
            sy = t.clientY;
            if (onStart) onStart(sx, sy);
            document.addEventListener("touchmove", move, { passive: false });
            document.addEventListener("touchend", end, { passive: false });
            document.addEventListener("touchcancel", end, { passive: false });
            document.addEventListener("mousemove", move);
            document.addEventListener("mouseup", end);
            if (ev.cancelable) ev.preventDefault();
            ev.stopPropagation();
        }
        function move(ev) {
            if (!active) return;
            var t = ev.touches ? ev.touches[0] : ev;
            if (!t) return;
            onMove(t.clientX - sx, t.clientY - sy, t.clientX, t.clientY);
            if (ev.cancelable) ev.preventDefault();
            ev.stopPropagation();
        }
        function end(ev) {
            if (!active) return;
            active = false;
            document.removeEventListener("touchmove", move);
            document.removeEventListener("touchend", end);
            document.removeEventListener("touchcancel", end);
            document.removeEventListener("mousemove", move);
            document.removeEventListener("mouseup", end);
            if (onEnd) onEnd();
            if (ev && ev.cancelable) ev.preventDefault();
            if (ev) ev.stopPropagation();
        }
        handle.addEventListener("touchstart", start, { passive: false });
        handle.addEventListener("mousedown", start);
    }

    var win = { x: 4, y: 0, w: 0, h: 0, maximized: false, minimized: false };
    var winLoaded = false;
    var winApplyRaf = 0;

    function defaultWin() {
        var vw = window.innerWidth || 360;
        var vh = window.innerHeight || 640;
        var w = Math.min(vw - 8, 520);
        var h = Math.min(Math.round(vh * 0.62), 720);
        if (w < MIN_W) w = MIN_W;
        if (h < MIN_H) h = MIN_H;
        win.x = Math.max(4, Math.round((vw - w) / 2));
        win.y = Math.max(4, vh - h - 4);
        win.w = w; win.h = h;
        win.maximized = false;
        win.minimized = false;
    }
    function clampWin() {
        var vw = window.innerWidth || 360;
        var vh = window.innerHeight || 640;
        if (!win.w || win.w < MIN_W) win.w = MIN_W;
        if (!win.h || win.h < MIN_H) win.h = MIN_H;
        if (win.w > vw) win.w = vw;
        if (win.h > vh) win.h = vh;
        if (win.x < 0) win.x = 0;
        if (win.y < 0) win.y = 0;
        if (win.x + win.w > vw) win.x = vw - win.w;
        if (win.y + win.h > vh) win.y = vh - win.h;
        if (win.x < 0) win.x = 0;
        if (win.y < 0) win.y = 0;
    }
    function loadWin() {
        if (winLoaded) return;
        winLoaded = true;
        var o = sget(WIN_KEY, null);
        if (o && typeof o === "object") {
            if (typeof o.x === "number") win.x = o.x;
            if (typeof o.y === "number") win.y = o.y;
            if (typeof o.w === "number") win.w = o.w;
            if (typeof o.h === "number") win.h = o.h;
            win.maximized = !!o.maximized;
            win.minimized = !!o.minimized;
        }
        if (!win.w || !win.h) defaultWin();
        clampWin();
    }
    function saveWin() { sset(WIN_KEY, win); }
    function applyWin() {
        if (!panelEl) return;
        var vw = window.innerWidth || 360;
        var vh = window.innerHeight || 640;
        if (win.maximized) {
            panelEl.classList.add("max");
            panelEl.style.left = "0px";
            panelEl.style.top = "0px";
            panelEl.style.width = vw + "px";
            panelEl.style.height = vh + "px";
        } else {
            panelEl.classList.remove("max");
            if (win.x + win.w > vw) win.x = vw - win.w;
            if (win.y + win.h > vh) win.y = vh - win.h;
            if (win.x < 0) win.x = 0;
            if (win.y < 0) win.y = 0;
            panelEl.style.left = win.x + "px";
            panelEl.style.top = win.y + "px";
            panelEl.style.width = win.w + "px";
            panelEl.style.height = (win.minimized ? TOOLBAR_H : win.h) + "px";
        }
        if (win.minimized) panelEl.classList.add("min");
        else panelEl.classList.remove("min");
    }
    function scheduleWinApply() {
        if (winApplyRaf) return;
        winApplyRaf = requestAnimationFrame(function () { winApplyRaf = 0; applyWin(); });
    }

    var fab = { x: null, y: null };
    var fabLoaded = false;
    var fabEl = null;

    function defaultFab() {
        var vw = window.innerWidth || 360;
        var vh = window.innerHeight || 640;
        fab.x = vw - FAB_SIZE - 12;
        fab.y = vh - FAB_SIZE - 88;
    }
    function clampFab() {
        var vw = window.innerWidth || 360;
        var vh = window.innerHeight || 640;
        if (fab.x == null) fab.x = vw - FAB_SIZE - 12;
        if (fab.y == null) fab.y = vh - FAB_SIZE - 88;
        if (fab.x < 0) fab.x = 0;
        if (fab.y < 0) fab.y = 0;
        if (fab.x + FAB_SIZE > vw) fab.x = vw - FAB_SIZE;
        if (fab.y + FAB_SIZE > vh) fab.y = vh - FAB_SIZE;
        if (fab.x < 0) fab.x = 0;
        if (fab.y < 0) fab.y = 0;
    }
    function loadFab() {
        if (fabLoaded) return;
        fabLoaded = true;
        var o = sget(FAB_KEY, null);
        if (o && typeof o === "object") {
            if (typeof o.x === "number") fab.x = o.x;
            if (typeof o.y === "number") fab.y = o.y;
        }
        clampFab();
    }
    function saveFab() { sset(FAB_KEY, { x: Math.round(fab.x), y: Math.round(fab.y) }); }
    function applyFab() {
        if (!fabEl) return;
        var vw = window.innerWidth || 360;
        var vh = window.innerHeight || 640;
        if (fab.x == null || fab.y == null) defaultFab();
        if (fab.x < 0) fab.x = 0;
        if (fab.y < 0) fab.y = 0;
        if (fab.x + FAB_SIZE > vw) fab.x = vw - FAB_SIZE;
        if (fab.y + FAB_SIZE > vh) fab.y = vh - FAB_SIZE;
        if (fab.x < 0) fab.x = 0;
        if (fab.y < 0) fab.y = 0;
        fabEl.style.left = Math.round(fab.x) + "px";
        fabEl.style.top = Math.round(fab.y) + "px";
    }

    function makeFabDraggable(elem) {
        var active = false;
        var dragged = false;
        var sx = 0, sy = 0;
        var startX = 0, startY = 0;
        function start(ev) {
            if (active) return;
            var t = ev.touches ? ev.touches[0] : ev;
            if (!t) return;
            active = true;
            dragged = false;
            sx = t.clientX;
            sy = t.clientY;
            startX = fab.x != null ? fab.x : 0;
            startY = fab.y != null ? fab.y : 0;
            document.addEventListener("touchmove", move, { passive: false });
            document.addEventListener("touchend", end, { passive: false });
            document.addEventListener("touchcancel", end, { passive: false });
            document.addEventListener("mousemove", move);
            document.addEventListener("mouseup", end);
            if (ev.cancelable) ev.preventDefault();
            ev.stopPropagation();
        }
        function move(ev) {
            if (!active) return;
            var t = ev.touches ? ev.touches[0] : ev;
            if (!t) return;
            var dx = t.clientX - sx;
            var dy = t.clientY - sy;
            if (!dragged && Math.abs(dx) + Math.abs(dy) < FAB_DRAG_THRESHOLD) {
                if (ev.cancelable) ev.preventDefault();
                ev.stopPropagation();
                return;
            }
            if (!dragged) {
                dragged = true;
                if (elem) elem.classList.add("dragging");
            }
            fab.x = startX + dx;
            fab.y = startY + dy;
            clampFab();
            applyFab();
            if (ev.cancelable) ev.preventDefault();
            ev.stopPropagation();
        }
        function end(ev) {
            if (!active) return;
            active = false;
            document.removeEventListener("touchmove", move);
            document.removeEventListener("touchend", end);
            document.removeEventListener("touchcancel", end);
            document.removeEventListener("mousemove", move);
            document.removeEventListener("mouseup", end);
            if (elem) elem.classList.remove("dragging");
            if (dragged) saveFab();
            else togglePanel();
            if (ev && ev.cancelable) ev.preventDefault();
            if (ev) ev.stopPropagation();
        }
        elem.addEventListener("touchstart", start, { passive: false });
        elem.addEventListener("mousedown", start);
        elem.addEventListener("click", function (ev) {
            ev.stopPropagation();
            if (ev.cancelable) ev.preventDefault();
        });
    }

    var hostEl = null;
    var shadowRoot = null;
    var panelEl = null;
    var panelBody = null;
    var panelTabBar = null;

    var uiState = { open: false, tab: "status" };
    var uiRaf = 0;

    function createHost() {
        safe(function () {
            var existing = document.getElementById(HOST_ID);
            if (existing && existing !== hostEl) {
                try { if (existing.parentNode) existing.parentNode.removeChild(existing); } catch (e) {}
            }
            injectHostStyle();
            var host = document.createElement("div");
            host.id = HOST_ID;
            applyHostInlineStyle(host);
            try {
                if (typeof host.showPopover === "function") {
                    host.setAttribute("popover", "manual");
                }
            } catch (e) {}
            var target = document.documentElement || document.body;
            if (!target) return;
            target.appendChild(host);
            try {
                if (host.hasAttribute("popover") && typeof host.showPopover === "function") {
                    host.showPopover();
                }
            } catch (e) {}
            var shadow = null;
            try { shadow = host.attachShadow({ mode: "open" }); }
            catch (e) { return; }
            var style = document.createElement("style");
            style.textContent = SHADOW_CSS;
            shadow.appendChild(style);
            hostEl = host;
            shadowRoot = shadow;
        });
    }

    function reattachHost() {
        if (!hostEl) return;
        try { applyHostInlineStyle(hostEl); } catch (e) {}
        var fs = document.fullscreenElement || document.webkitFullscreenElement || document.msFullscreenElement;
        var target = fs || document.documentElement;
        if (!target) return;
        if (hostEl.parentNode !== target) {
            try { target.appendChild(hostEl); } catch (e) {}
        }
        try {
            if (hostEl.hasAttribute("popover") && typeof hostEl.showPopover === "function") {
                try { hostEl.hidePopover(); } catch (e) {}
                try { hostEl.showPopover(); } catch (e) {}
            }
        } catch (e) {}
    }

    function ensureHost() {
        if (!hostEl) {
            createHost();
            if (!fabEl) buildFab();
            return;
        }
        var fs = document.fullscreenElement || document.webkitFullscreenElement || document.msFullscreenElement;
        var target = fs || document.documentElement;
        if (target && hostEl.parentNode !== target) reattachHost();
        try { injectHostStyle(); } catch (e) {}
        if (shadowRoot && fabEl && !fabEl.parentNode) {
            try { shadowRoot.appendChild(fabEl); } catch (e) {}
        }
        if (uiState.open) {
            if (!panelEl || (shadowRoot && panelEl.getRootNode() !== shadowRoot)) {
                panelEl = null;
                panelBody = null;
                panelTabBar = null;
                uiState.open = false;
                safe(buildPanel);
            } else if (shadowRoot && !panelEl.parentNode) {
                try { shadowRoot.appendChild(panelEl); } catch (e) {}
                applyWin();
                renderActive();
            }
        }
    }

    function buildFab() {
        if (!shadowRoot) return;
        if (fabEl && fabEl.parentNode) return;
        loadFab();
        try {
            if (!fabEl) {
                fabEl = document.createElement("button");
                fabEl.className = "fab" + (CFG.enabled ? "" : " off");
                fabEl.type = "button";
                fabEl.setAttribute("aria-label", "AdBlock (ドラッグで移動)");
                fabEl.textContent = "🛡";
                fabEl.style.pointerEvents = "auto";
                makeFabDraggable(fabEl);
            } else {
                fabEl.className = "fab" + (CFG.enabled ? "" : " off");
            }
            shadowRoot.appendChild(fabEl);
            applyFab();
        } catch (e) {
            fabEl = null;
        }
    }

    function TABS() {
        return [
            { id: "status", label: "状態" },
            { id: "settings", label: "設定" },
            { id: "sites", label: "サイト" },
            { id: "log", label: "ログ" }
        ];
    }

    function uiScheduleRender() {
        if (uiRaf) return;
        uiRaf = requestAnimationFrame(function () {
            uiRaf = 0;
            renderActive();
        });
    }

    function makeSwitchRow(key, label, desc) {
        var row = el("div", "row");
        var wrap = document.createElement("div");
        wrap.style.flex = "1";
        wrap.style.minWidth = "0";
        var l = el("div", "label");
        l.textContent = label;
        wrap.appendChild(l);
        if (desc) {
            var d = el("div", "desc");
            d.textContent = desc;
            wrap.appendChild(d);
        }
        row.appendChild(wrap);
        var sw = el("div", "sw" + (CFG[key] ? " on" : ""));
        bindTap(sw, function () {
            CFG[key] = !CFG[key];
            saveCfg();
            if (CFG[key]) sw.classList.add("on");
            else sw.classList.remove("on");
            onCfgChanged(key);
        });
        row.appendChild(sw);
        return row;
    }

    function onCfgChanged(key) {
        if (key === "enabled") {
            if (fabEl) {
                if (CFG.enabled) fabEl.classList.remove("off");
                else fabEl.classList.add("off");
            }
            applyAbCSS();
            if (CFG.enabled) {
                startObserver();
                injectNetwork();
                injectAntiDetect();
                scan(document.body);
                releaseDone = false;
                releaseProtect();
            }
            notify("AdBlock: " + (CFG.enabled ? "ON" : "OFF"));
        } else if (key === "css" || key === "cookie" || key === "overlay") {
            rebuildSelector();
            applyAbCSS();
            scan(document.body);
        } else if (key === "network" || key === "popups" || key === "antiDetect") {
            notify("AdBlock: リロードで完全反映");
        } else if (key === "release") {
            if (CFG.release) { releaseDone = false; releaseProtect(); }
        }
        saveCfg();
        statSaveNow();
        if (uiState.open) uiScheduleRender();
    }

    function renderStatus() {
        if (!panelBody) return;
        clearChildren(panelBody);
        var m = el("div", "metrics");
        function metric(k, v, cls) {
            var d = el("div", "metric");
            var kk = el("div", "metric-k"); kk.textContent = k; d.appendChild(kk);
            var vv = el("div", "metric-v " + (cls || "")); vv.textContent = v; d.appendChild(vv);
            return d;
        }
        m.appendChild(metric("遮断合計", String(STAT.total || 0), STAT.total > 0 ? "good" : ""));
        m.appendChild(metric("CSS", String(STAT.css || 0)));
        m.appendChild(metric("DOM", String(STAT.dom || 0)));
        m.appendChild(metric("通信", String(STAT.network || 0)));
        m.appendChild(metric("Cookie", String(STAT.cookie || 0)));
        m.appendChild(metric("Overlay", String(STAT.overlay || 0)));
        panelBody.appendChild(m);
        var s = el("div", "section");
        var h = el("h3", "sec-title"); h.textContent = "このページ"; s.appendChild(h);
        var ul = el("ul", "list");
        function li(k, v, cls) {
            var r = el("li");
            var a = el("span", "dim"); a.textContent = k; r.appendChild(a);
            var b = el("span", cls || ""); b.textContent = v; r.appendChild(b);
            return r;
        }
        var href = "";
        try { href = location.href; } catch (e) {}
        ul.appendChild(li("ホスト", currentHost() || "(不明)"));
        ul.appendChild(li("URL", href.slice(0, 120)));
        ul.appendChild(li("全体", CFG.enabled ? "ON" : "OFF", CFG.enabled ? "yes" : "no"));
        ul.appendChild(li("ホワイトリスト", isWhitelisted() ? "適用中" : "未登録", isWhitelisted() ? "no" : "yes"));
        s.appendChild(ul);
        panelBody.appendChild(s);
        var q = el("div", "section");
        var h2 = el("h3", "sec-title"); h2.textContent = "クイック操作"; q.appendChild(h2);
        var row = el("div", "flex");
        var b1 = el("span", "btn pri"); b1.textContent = CFG.enabled ? "一時停止" : "有効化";
        bindTap(b1, function () { CFG.enabled = !CFG.enabled; saveCfg(); onCfgChanged("enabled"); });
        row.appendChild(b1);
        var b2 = el("span", "btn"); b2.textContent = "今すぐスキャン";
        bindTap(b2, function () { scan(document.body); autoCookie(); removeOverlays(); notify("スキャン完了"); });
        row.appendChild(b2);
        var b3 = el("span", "btn dan"); b3.textContent = "統計リセット";
        bindTap(b3, function () { statReset(); notify("統計をリセットしました"); });
        row.appendChild(b3);
        q.appendChild(row);
        panelBody.appendChild(q);
    }

    function renderSettings() {
        if (!panelBody) return;
        clearChildren(panelBody);
        var s1 = el("div", "section");
        var h1 = el("h3", "sec-title"); h1.textContent = "全体"; s1.appendChild(h1);
        s1.appendChild(makeSwitchRow("enabled", "AdBlock 有効", "全体のON/OFF"));
        panelBody.appendChild(s1);
        var s2 = el("div", "section");
        var h2 = el("h3", "sec-title"); h2.textContent = "ブロック層"; s2.appendChild(h2);
        s2.appendChild(makeSwitchRow("css", "CSS 非表示", "セレクタ一致で display:none"));
        s2.appendChild(makeSwitchRow("dom", "DOM 監視", "動的挿入要素を削除"));
        s2.appendChild(makeSwitchRow("network", "ネットワーク遮断", "fetch/XHR横取り"));
        s2.appendChild(makeSwitchRow("popups", "ポップアップ遮断", "window.openを無効化"));
        s2.appendChild(makeSwitchRow("antiDetect", "アンチ検知対策", "検知用DOM偽装"));
        panelBody.appendChild(s2);
        var s3 = el("div", "section");
        var h3 = el("h3", "sec-title"); h3.textContent = "付加機能"; s3.appendChild(h3);
        s3.appendChild(makeSwitchRow("cookie", "Cookieバナー除去", "バナー自体を非表示"));
        s3.appendChild(makeSwitchRow("cookieAuto", "Cookie自動同意", "「同意」を自動クリック"));
        s3.appendChild(makeSwitchRow("overlay", "オーバーレイ除去", "ペイウォール/モーダル除去"));
        s3.appendChild(makeSwitchRow("release", "コピー保護解除", "右クリック・選択禁止を解除"));
        s3.appendChild(makeSwitchRow("youtube", "YouTube最適化", "広告スキップ自動化"));
        panelBody.appendChild(s3);
    }

    function renderSites() {
        if (!panelBody) return;
        clearChildren(panelBody);
        var info = el("div", "section");
        var h = el("h3", "sec-title");
        h.textContent = "ホワイトリスト (" + SITES.length + "/" + MAX_SITES + ")";
        info.appendChild(h);
        var row = el("div", "flex");
        var inp = el("input", "input");
        inp.type = "text";
        inp.placeholder = "example.com";
        inp.value = currentHost();
        row.appendChild(inp);
        var addBtn = el("span", "btn pri"); addBtn.textContent = "追加";
        bindTap(addBtn, function () {
            var v = String(inp.value || "").trim().toLowerCase();
            v = v.replace(/^https?:\/\//, "").split("/")[0];
            if (!v) { notify("ホスト名を入力"); return; }
            if (addSite(v)) { notify("追加: " + v); renderSites(); }
            else notify("既に登録済み");
        });
        row.appendChild(addBtn);
        info.appendChild(row);
        var row2 = el("div", "flex");
        var curBtn = el("span", "btn"); curBtn.textContent = "このサイトを追加";
        bindTap(curBtn, function () {
            var hh = currentHost();
            if (!hh) return;
            if (addSite(hh)) { notify("追加: " + hh); renderSites(); }
            else notify("既に登録済み");
        });
        row2.appendChild(curBtn);
        var rmBtn = el("span", "btn dan"); rmBtn.textContent = "このサイトを解除";
        bindTap(rmBtn, function () {
            var hh = currentHost();
            if (!hh) return;
            if (removeSite(hh)) { notify("解除: " + hh); renderSites(); }
            else notify("未登録");
        });
        row2.appendChild(rmBtn);
        info.appendChild(row2);
        panelBody.appendChild(info);
        var sec = el("div", "section");
        var h2 = el("h3", "sec-title"); h2.textContent = "登録済み"; sec.appendChild(h2);
        if (!SITES.length) {
            var em = el("div", "empty"); em.textContent = "ホワイトリストは空です";
            sec.appendChild(em);
        } else {
            var wrap = document.createElement("div");
            for (var i = 0; i < SITES.length; i++) {
                (function (host) {
                    var tag = el("span", "site-tag");
                    var b = document.createElement("b");
                    b.textContent = host;
                    tag.appendChild(b);
                    var x = el("span", "x"); x.textContent = "×";
                    bindTap(x, function () { removeSite(host); renderSites(); });
                    tag.appendChild(x);
                    wrap.appendChild(tag);
                })(SITES[i]);
            }
            sec.appendChild(wrap);
        }
        panelBody.appendChild(sec);
        var act = el("div", "flex");
        var clr = el("span", "btn dan"); clr.textContent = "全解除";
        bindTap(clr, function () {
            SITES.length = 0;
            sset(SITE_KEY, SITES);
            renderSites();
            notify("ホワイトリストをクリア");
        });
        act.appendChild(clr);
        panelBody.appendChild(act);
    }

    function renderLog() {
        if (!panelBody) return;
        clearChildren(panelBody);
        var sec = el("div", "section");
        var h = el("h3", "sec-title");
        h.textContent = "最近の遮断 (" + STAT.recent.length + "/" + MAX_LOG + ")";
        sec.appendChild(h);
        var row = el("div", "flex");
        var cp = el("span", "btn"); cp.textContent = "全コピー";
        bindTap(cp, function () {
            var lines = [];
            for (var i = 0; i < STAT.recent.length; i++) {
                var e = STAT.recent[i];
                lines.push("[" + tsOf(e.t) + "] [" + e.kind + "] " + e.url);
            }
            if (copyText(lines.join("\n"))) notify("コピーしました");
            else notify("コピー失敗");
        });
        row.appendChild(cp);
        var clr = el("span", "btn dan"); clr.textContent = "クリア";
        bindTap(clr, function () {
            STAT.recent.length = 0;
            statSaveNow();
            renderLog();
        });
        row.appendChild(clr);
        sec.appendChild(row);
        if (!STAT.recent.length) {
            var em = el("div", "empty"); em.textContent = "まだ遮断していません";
            sec.appendChild(em);
        } else {
            var ul = el("ul", "list");
            for (var i = 0; i < Math.min(STAT.recent.length, 100); i++) {
                var e = STAT.recent[i];
                var li = el("li");
                var kk = el("span", "item-kind " + e.kind);
                kk.textContent = e.kind;
                li.appendChild(kk);
                var tt = el("span", "item-t");
                tt.textContent = tsOf(e.t);
                li.appendChild(tt);
                var uu = el("span", "item-url");
                uu.textContent = e.url;
                li.appendChild(uu);
                ul.appendChild(li);
            }
            sec.appendChild(ul);
        }
        panelBody.appendChild(sec);
    }

    function renderActive() {
        if (!uiState.open || !panelBody) return;
        if (panelEl && shadowRoot && panelEl.getRootNode() !== shadowRoot) {
            panelEl = null;
            panelBody = null;
            panelTabBar = null;
            uiState.open = false;
            safe(buildPanel);
            return;
        }
        if (!panelBody.isConnected) {
            if (panelEl && shadowRoot && !panelEl.parentNode) {
                try { shadowRoot.appendChild(panelEl); } catch (e) {}
            }
        }
        try {
            if (uiState.tab === "status") renderStatus();
            else if (uiState.tab === "settings") renderSettings();
            else if (uiState.tab === "sites") renderSites();
            else if (uiState.tab === "log") renderLog();
            else renderStatus();
        } catch (e) {
            try { console.error("[AdBlock] render error", e); } catch (_) {}
            try { clearChildren(panelBody); } catch (_) {}
            try {
                var err = el("div", "empty");
                err.textContent = "描画エラー: " + (e && e.message ? e.message : e);
                panelBody.appendChild(err);
            } catch (_) {}
        }
        if (panelBody && panelBody.childNodes.length === 0) {
            uiState.tab = "status";
            try { renderStatus(); } catch (e) {}
        }
    }

    function toggleMin() {
        if (win.maximized) win.maximized = false;
        win.minimized = !win.minimized;
        applyWin();
        saveWin();
    }
    function toggleMax() {
        if (win.minimized) win.minimized = false;
        win.maximized = !win.maximized;
        applyWin();
        saveWin();
    }

    function buildPanel() {
        if (!shadowRoot) return;
        if (panelEl && panelEl.parentNode) return;
        loadWin();
        panelEl = el("div", "root");
        panelEl.style.pointerEvents = "auto";
        var toolbar = el("div", "toolbar");
        var grip = el("div", "grip"); grip.textContent = "⋮⋮";
        toolbar.appendChild(grip);
        var titleEl = el("div", "title");
        var tstr = "";
        try {
            tstr = currentHost() || "";
            if (location.pathname && location.pathname !== "/") tstr += location.pathname;
            if (tstr.length > 60) tstr = tstr.slice(0, 60) + "…";
        } catch (e) {}
        if (!tstr) tstr = TITLE;
        titleEl.textContent = tstr;
        toolbar.appendChild(titleEl);
        var btnReload = el("div", "winbtn"); btnReload.textContent = "⟳";
        bindTap(btnReload, function () {
            statSaveNow();
            notify("再読み込み中…");
            setTimeout(function () { try { location.reload(); } catch (e) {} }, 60);
        });
        toolbar.appendChild(btnReload);
        var btnMin = el("div", "winbtn"); btnMin.textContent = "🗕";
        bindTap(btnMin, function () { toggleMin(); });
        toolbar.appendChild(btnMin);
        var btnMax = el("div", "winbtn"); btnMax.textContent = "🗖";
        bindTap(btnMax, function () { toggleMax(); });
        toolbar.appendChild(btnMax);
        var btnClose = el("div", "winbtn close"); btnClose.textContent = "✕";
        bindTap(btnClose, function () { closePanel(); });
        toolbar.appendChild(btnClose);
        var dragX = 0, dragY = 0;
        makeDraggable(toolbar,
            function () { dragX = win.x; dragY = win.y; },
            function (dx, dy) {
                if (win.maximized) return;
                win.x = dragX + dx;
                win.y = dragY + dy;
                clampWin();
                scheduleWinApply();
            },
            function () { saveWin(); },
            ".winbtn"
        );
        panelEl.appendChild(toolbar);
        panelTabBar = el("div", "bar");
        var tabs = TABS();
        for (var i = 0; i < tabs.length; i++) {
            (function (t) {
                var tab = el("div", "tab" + (uiState.tab === t.id ? " on" : ""));
                tab.textContent = t.label;
                bindTap(tab, function () {
                    uiState.tab = t.id;
                    var kids = panelTabBar.querySelectorAll(".tab");
                    for (var k = 0; k < kids.length; k++) kids[k].classList.remove("on");
                    tab.classList.add("on");
                    renderActive();
                });
                panelTabBar.appendChild(tab);
            })(tabs[i]);
        }
        panelEl.appendChild(panelTabBar);
        panelBody = el("div", "body");
        panelEl.appendChild(panelBody);
        var foot = el("div", "foot");
        var bScan = el("span", "btn pri"); bScan.textContent = "🔍 スキャン";
        bindTap(bScan, function () {
            scan(document.body); autoCookie(); removeOverlays(); notify("スキャン完了");
        });
        var bToggle = el("span", "btn"); bToggle.textContent = CFG.enabled ? "⏸ 停止" : "▶ 有効化";
        bindTap(bToggle, function () {
            CFG.enabled = !CFG.enabled;
            saveCfg();
            onCfgChanged("enabled");
            bToggle.textContent = CFG.enabled ? "⏸ 停止" : "▶ 有効化";
        });
        var bCopy = el("span", "btn"); bCopy.textContent = "📋 コピー";
        bindTap(bCopy, function () {
            var href = "";
            try { href = location.href; } catch (e) {}
            var t = "=== AdBlock ===\n" +
                "URL: " + href + "\n" +
                "Total: " + STAT.total + "\n" +
                "CSS: " + STAT.css + " DOM: " + STAT.dom + " Net: " + STAT.network + "\n" +
                "Recent:\n";
            var lines = [];
            for (var i = 0; i < Math.min(STAT.recent.length, 50); i++) {
                var e = STAT.recent[i];
                lines.push("[" + tsOf(e.t) + "] [" + e.kind + "] " + e.url);
            }
            t += lines.join("\n");
            if (copyText(t)) notify("コピーしました");
            else notify("コピー失敗");
        });
        var bCls = el("span", "btn"); bCls.textContent = "閉じる";
        bindTap(bCls, function () { closePanel(); });
        foot.appendChild(bScan);
        foot.appendChild(bToggle);
        foot.appendChild(bCopy);
        foot.appendChild(bCls);
        panelEl.appendChild(foot);
        var rz = el("div", "resize");
        var rzW = 0, rzH = 0;
        makeDraggable(rz,
            function () { rzW = win.w; rzH = win.h; },
            function (dx, dy) {
                if (win.maximized || win.minimized) return;
                win.w = Math.max(MIN_W, rzW + dx);
                win.h = Math.max(MIN_H, rzH + dy);
                clampWin();
                scheduleWinApply();
            },
            function () { saveWin(); }
        );
        panelEl.appendChild(rz);
        shadowRoot.appendChild(panelEl);
        uiState.open = true;
        applyWin();
        renderActive();
        if (fabEl) fabEl.style.display = "none";
    }

    function openPanel() {
        if (hostEl && panelEl && shadowRoot && panelEl.getRootNode() !== shadowRoot) {
            panelEl = null;
            panelBody = null;
            panelTabBar = null;
            uiState.open = false;
        }
        if (uiState.open && panelEl) {
            if (!panelEl.parentNode && shadowRoot) {
                try { shadowRoot.appendChild(panelEl); } catch (e) {}
                applyWin();
                renderActive();
            }
            if (fabEl) fabEl.style.display = "none";
            return;
        }
        ensureHost();
        safe(buildPanel);
    }
    function closePanel() {
        if (!uiState.open && !panelEl) return;
        try {
            if (panelEl && panelEl.parentNode) panelEl.parentNode.removeChild(panelEl);
        } catch (e) {}
        panelEl = null;
        panelBody = null;
        panelTabBar = null;
        uiState.open = false;
        if (fabEl) {
            if (shadowRoot && !fabEl.parentNode) {
                try { shadowRoot.appendChild(fabEl); } catch (e) {}
            }
            fabEl.style.display = "";
            applyFab();
        }
    }
    function togglePanel() {
        if (uiState.open) closePanel();
        else openPanel();
    }

    function onResize() {
        clampWin();
        if (uiState.open) scheduleWinApply();
        clampFab();
        applyFab();
    }

    function handleFullscreen() {
        safe(function () {
            var fs = document.fullscreenElement ||
                     document.webkitFullscreenElement ||
                     document.msFullscreenElement;
            if (!hostEl) return;
            var target = fs || document.documentElement;
            if (!target) return;
            if (hostEl.parentNode !== target) {
                try { target.appendChild(hostEl); } catch (e) {}
            }
            try {
                if (hostEl.hasAttribute("popover") && typeof hostEl.showPopover === "function") {
                    try { hostEl.hidePopover(); } catch (e) {}
                    try { hostEl.showPopover(); } catch (e) {}
                }
            } catch (e) {}
        });
    }

    var watchdogT = 0;
    function startWatchdog() {
        if (watchdogT) clearInterval(watchdogT);
        watchdogT = setInterval(function () {
            safe(function () {
                if (!hostEl) { createHost(); if (!fabEl) buildFab(); return; }
                if (!hostEl.isConnected) reattachHost();
                try { injectHostStyle(); } catch (e) {}
                if (!fabEl) buildFab();
                else if (!fabEl.parentNode && shadowRoot) {
                    try { shadowRoot.appendChild(fabEl); } catch (e) {}
                }
                if (uiState.open) {
                    if (!panelEl || (shadowRoot && panelEl.getRootNode() !== shadowRoot)) {
                        panelEl = null;
                        panelBody = null;
                        panelTabBar = null;
                        uiState.open = false;
                        safe(buildPanel);
                    } else if (!panelEl.parentNode && shadowRoot) {
                        try { shadowRoot.appendChild(panelEl); } catch (e) {}
                        applyWin();
                        renderActive();
                    } else if (panelBody && panelBody.childNodes.length === 0) {
                        uiScheduleRender();
                    }
                }
            });
        }, WATCHDOG_MS);
    }

    function registerCommands() {
        if (commandsRegistered) return;
        commandsRegistered = true;
        regCmd("AdBlock メニューを開く", function () { openPanel(); });
        regCmd("AdBlock メニューを閉じる", function () { closePanel(); });
        regCmd("AdBlock メニュー開閉", function () { togglePanel(); });
        regCmd("AdBlock 全体 ON/OFF", function () {
            CFG.enabled = !CFG.enabled; saveCfg(); onCfgChanged("enabled");
        });
        regCmd("AdBlock CSS ON/OFF", function () {
            CFG.css = !CFG.css; saveCfg();
            rebuildSelector(); applyAbCSS(); scan(document.body);
            notify("CSS: " + (CFG.css ? "ON" : "OFF"));
        });
        regCmd("AdBlock DOM監視 ON/OFF", function () {
            CFG.dom = !CFG.dom; saveCfg();
            notify("DOM: " + (CFG.dom ? "ON" : "OFF"));
        });
        regCmd("AdBlock ネットワーク遮断 ON/OFF", function () {
            CFG.network = !CFG.network; saveCfg();
            notify("Network: " + (CFG.network ? "ON" : "OFF") + " (リロード推奨)");
        });
        regCmd("AdBlock ポップアップ遮断 ON/OFF", function () {
            CFG.popups = !CFG.popups; saveCfg();
            notify("Popups: " + (CFG.popups ? "ON" : "OFF") + " (リロード推奨)");
        });
        regCmd("AdBlock Cookieバナー除去 ON/OFF", function () {
            CFG.cookie = !CFG.cookie; saveCfg();
            rebuildSelector(); applyAbCSS(); scan(document.body);
            notify("Cookie: " + (CFG.cookie ? "ON" : "OFF"));
        });
        regCmd("AdBlock Cookie自動同意 ON/OFF", function () {
            CFG.cookieAuto = !CFG.cookieAuto; saveCfg();
            notify("CookieAuto: " + (CFG.cookieAuto ? "ON" : "OFF"));
        });
        regCmd("AdBlock オーバーレイ除去 ON/OFF", function () {
            CFG.overlay = !CFG.overlay; saveCfg();
            rebuildSelector(); applyAbCSS(); scan(document.body);
            notify("Overlay: " + (CFG.overlay ? "ON" : "OFF"));
        });
        regCmd("AdBlock コピー保護解除 ON/OFF", function () {
            CFG.release = !CFG.release; saveCfg();
            if (CFG.release) { releaseDone = false; releaseProtect(); }
            notify("Release: " + (CFG.release ? "ON" : "OFF"));
        });
        regCmd("AdBlock アンチ検知対策 ON/OFF", function () {
            CFG.antiDetect = !CFG.antiDetect; saveCfg();
            notify("AntiDetect: " + (CFG.antiDetect ? "ON" : "OFF") + " (リロード推奨)");
        });
        regCmd("AdBlock YouTube最適化 ON/OFF", function () {
            CFG.youtube = !CFG.youtube; saveCfg();
            notify("YouTube: " + (CFG.youtube ? "ON" : "OFF"));
        });
        regCmd("AdBlock 今すぐスキャン", function () {
            scan(document.body); autoCookie(); removeOverlays();
            notify("スキャン完了");
        });
        regCmd("AdBlock 統計リセット", function () {
            statReset();
            notify("統計をリセット");
        });
        regCmd("AdBlock このサイトをホワイトリストに追加", function () {
            var h = currentHost();
            if (!h) { notify("ホスト不明"); return; }
            if (addSite(h)) notify("追加: " + h);
            else notify("既に登録済み");
        });
        regCmd("AdBlock このサイトをホワイトリストから解除", function () {
            var h = currentHost();
            if (!h) { notify("ホスト不明"); return; }
            if (removeSite(h)) notify("解除: " + h);
            else notify("未登録");
        });
        regCmd("AdBlock FAB位置リセット", function () {
            fab.x = null; fab.y = null;
            defaultFab();
            clampFab();
            applyFab();
            saveFab();
            notify("FAB位置リセット");
        });
        regCmd("AdBlock ウィンドウ位置リセット", function () {
            defaultWin();
            if (uiState.open) applyWin();
            saveWin();
            notify("ウィンドウ位置リセット");
        });
        regCmd("AdBlock 再アタッチ", function () {
            reattachHost();
            notify("再アタッチしました");
        });
    }

    function onYouTubeReady() {
        try {
            if (location.hostname.indexOf("youtube.com") === -1) return;
        } catch (e) { return; }
        safe(function () {
            var tries = 0;
            var iv = setInterval(function () {
                tries++;
                var app = document.querySelector("ytd-app");
                if (app || tries > 60) {
                    clearInterval(iv);
                    ensureHost();
                    buildFab();
                    if (uiState.open) uiScheduleRender();
                }
            }, 250);
        });
    }

    function flushAll() {
        try { statSaveNow(); } catch (e) {}
        try { saveWin(); } catch (e) {}
        try { saveFab(); } catch (e) {}
        try { saveCfg(); } catch (e) {}
    }

    function initLifecycle() {
        try { window.addEventListener("pagehide", flushAll, true); } catch (e) {}
        try { window.addEventListener("beforeunload", flushAll, true); } catch (e) {}
        try { window.addEventListener("unload", flushAll, true); } catch (e) {}
        try {
            document.addEventListener("visibilitychange", function () {
                if (document.visibilityState === "hidden") flushAll();
                else {
                    ensureHost();
                    if (uiState.open) uiScheduleRender();
                }
            }, true);
        } catch (e) {}
        try {
            window.addEventListener("pageshow", function () {
                ensureHost();
                if (uiState.open) uiScheduleRender();
            });
        } catch (e) {}
    }

    function init() {
        if (domReady) return;
        domReady = true;
        injectHostStyle();
        createHost();
        if (!fabEl) buildFab();
        applyAbCSS();
        injectAntiDetect();
        injectNetwork();
        startObserver();
        scan(document.documentElement);
        registerCommands();
        startWatchdog();
        initLifecycle();
        try {
            document.addEventListener("fullscreenchange", handleFullscreen, true);
            document.addEventListener("webkitfullscreenchange", handleFullscreen, true);
            document.addEventListener("MSFullscreenChange", handleFullscreen, true);
            window.addEventListener("resize", onResize, { passive: true });
            window.addEventListener("orientationchange", onResize, { passive: true });
        } catch (e) {}
        safe(function () { scan(document.body); });
        autoCookie();
        removeOverlays();
        releaseProtect();
        startCleaner();
        watchUrl();
        ytLoop();
        onYouTubeReady();
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init, { once: true });
        setTimeout(init, 2000);
    } else {
        init();
    }

    window.addEventListener("load", function () {
        setTimeout(function () {
            safe(function () {
                ensureHost();
                buildFab();
                registerCommands();
                if (uiState.open) uiScheduleRender();
            });
        }, 200);
        setTimeout(function () { safe(function () { scan(document.body); ensureHost(); }); }, 500);
        setTimeout(function () { safe(function () { scan(document.body); autoCookie(); ensureHost(); }); }, 1500);
        setTimeout(function () { safe(function () { scan(document.body); ensureHost(); }); }, 3500);
        setTimeout(function () { safe(function () { scan(document.body); autoCookie(); ensureHost(); }); }, 7000);
        setTimeout(function () { safe(function () { scan(document.body); ensureHost(); }); }, 12000);
    });

    window.__adblock = {
        open: openPanel,
        close: closePanel,
        toggle: togglePanel,
        cfg: function () { return CFG; },
        setCfg: function (k, v) { CFG[k] = !!v; saveCfg(); onCfgChanged(k); },
        stats: function () { return STAT; },
        resetStats: statReset,
        flush: flushAll,
        sites: function () { return SITES.slice(); },
        addSite: addSite,
        removeSite: removeSite,
        scan: function () { scan(document.body); autoCookie(); removeOverlays(); },
        fab: function () { return { x: fab.x, y: fab.y }; },
        fabReset: function () {
            fab.x = null; fab.y = null;
            defaultFab(); clampFab(); applyFab(); saveFab();
            return { x: fab.x, y: fab.y };
        },
        reattach: reattachHost,
        host: function () { return hostEl; },
        shadow: function () { return shadowRoot; }
    };
})();