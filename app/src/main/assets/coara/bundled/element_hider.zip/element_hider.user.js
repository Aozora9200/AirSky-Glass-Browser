// ==UserScript==
// @name         要素非表示
// @namespace    coara
// @version      1.0.0
// @description  広告ブロックテスト
// @author       Coara
// @match        *://*/*
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_addStyle
// @grant        GM_notification
// @grant        GM_registerMenuCommand
// @run-at       document-start
// @noframes
// ==/UserScript==
(function () {
    var SELECTORS = [
        'ins.adsbygoogle',
        '[id^="google_ads_"]',
        '[id^="div-gpt-ad"]',
        '[class*="ad-slot"]',
        '[class*="ad-banner"]',
        '[class*="sponsored"]',
        '[aria-label="advertisement"]',
        '[aria-label="広告"]',
        'iframe[src*="doubleclick.net"]',
        'iframe[src*="googlesyndication.com"]',
        'iframe[src*="ad.yahoo"]',
        '.cookie-banner',
        '#cookie-banner',
        '.cookie-consent',
        '#onetrust-banner-sdk'
    ];
    var handle = null;
    var enabled = GM_getValue('enabled', true);

    function apply() {
        if (handle) {
            handle.remove();
            handle = null;
        }
        if (enabled) {
            handle = GM_addStyle(SELECTORS.join(',\n') + ' { display: none !important; }');
        }
    }

    apply();
    GM_registerMenuCommand('要素非表示 ON/OFF', function () {
        enabled = !enabled;
        GM_setValue('enabled', enabled);
        apply();
        GM_notification({ title: '要素非表示', text: enabled ? 'ONにしました' : 'OFFにしました' });
    });
})();
