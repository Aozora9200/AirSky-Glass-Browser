(function () {
    var TYPES = ["ripple", "spark", "heart", "star", "twinkle", "off"];
    var TYPE_NAMES = { ripple: "波紋", spark: "火花", heart: "ハート", star: "星", twinkle: "きらめき", off: "OFF" };
    var PALETTES = [
        { name: "虹色", colors: null },
        { name: "水色", colors: ["#4fc3f7", "#29b6f6", "#81d4fa", "#80deea"] },
        { name: "ピンク", colors: ["#f48fb1", "#f06292", "#ff80ab", "#ffb6d5"] },
        { name: "金色", colors: ["#ffd54f", "#ffca28", "#ffe082", "#fff176"] },
        { name: "白", colors: ["#ffffff", "#f5f5f5", "#e0f7fa"] }
    ];
    var SIZES = [{ name: "小", k: 0.7 }, { name: "中", k: 1 }, { name: "大", k: 1.5 }];
    var POOL_MAX = 32;
    var IDLE_MS = 3000;
    var TRAIL_GAP = 45;

    var MASK_HEART = "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'><path d='M12 21s-8-5.6-8-11.2C4 6.6 6.4 4.5 9 4.5c1.4 0 2.6.7 3 1.8.4-1.1 1.6-1.8 3-1.8 2.6 0 5 2.1 5 5.3C20 15.4 12 21 12 21z'/></svg>\")";
    var MASK_STAR = "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'><path d='M12 1.5l3 7 7.5.6-5.7 4.9 1.8 7.3L12 17.3 5.4 21.3l1.8-7.3L1.5 9.1 9 8.5z'/></svg>\")";
    var MASK_TWINKLE = "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'><path d='M12 0c.8 6.4 3.4 9.2 12 12-8.6 2.8-11.2 5.6-12 12-.8-6.4-3.4-9.2-12-12 8.6-2.8 11.2-5.6 12-12z'/></svg>\")";

    var type = coara.storage.get("type") || "ripple";
    if (type === "trail") {
        type = "twinkle";
    }
    if (TYPES.indexOf(type) < 0) {
        type = "ripple";
    }
    var palette = parseInt(coara.storage.get("palette") || "0", 10);
    if (!(palette >= 0 && palette < PALETTES.length)) {
        palette = 0;
    }
    var size = parseInt(coara.storage.get("size") || "1", 10);
    if (!(size >= 0 && size < SIZES.length)) {
        size = 1;
    }

    var layer = null;
    var free = [];
    var total = 0;
    var running = [];
    var idleTimer = 0;
    var hue = Math.floor(Math.random() * 360);
    var lastMove = 0;
    var canAnimate = typeof Element !== "undefined" && typeof Element.prototype.animate === "function";
    var bound = false;
    var boundMove = false;

    function persist() {
        coara.storage.set("type", type);
        coara.storage.set("palette", String(palette));
        coara.storage.set("size", String(size));
    }

    function pick() {
        var p = PALETTES[palette];
        if (!p.colors) {
            hue = (hue + 47) % 360;
            return "hsl(" + hue + ",95%,65%)";
        }
        return p.colors[Math.floor(Math.random() * p.colors.length)];
    }

    function ensureLayer() {
        if (layer && layer.parentNode) {
            return true;
        }
        var root = document.documentElement;
        if (!root) {
            return false;
        }
        layer = document.createElement("div");
        layer.setAttribute("aria-hidden", "true");
        layer.style.cssText = "position:fixed;left:0;top:0;width:0;height:0;overflow:visible;pointer-events:none;z-index:2147483647;margin:0;padding:0;border:0;contain:layout style;";
        root.appendChild(layer);
        free = [];
        total = 0;
        return true;
    }

    function destroyLayer() {
        clearTimeout(idleTimer);
        for (var i = 0; i < running.length; i++) {
            try {
                running[i].cancel();
            } catch (e) {}
        }
        running = [];
        if (layer && layer.parentNode) {
            layer.parentNode.removeChild(layer);
        }
        layer = null;
        free = [];
        total = 0;
    }

    function armIdle() {
        clearTimeout(idleTimer);
        idleTimer = setTimeout(function () {
            if (!running.length) {
                destroyLayer();
            }
        }, IDLE_MS);
    }

    function take() {
        var el = free.pop();
        if (el) {
            return el;
        }
        if (total >= POOL_MAX || !layer) {
            return null;
        }
        el = document.createElement("div");
        total++;
        layer.appendChild(el);
        return el;
    }

    function fly(el, css, frames, duration, easing) {
        el.style.cssText = "position:fixed;left:0;top:0;margin:0;padding:0;border:0;pointer-events:none;backface-visibility:hidden;" + css;
        var anim;
        try {
            anim = el.animate(frames, { duration: duration, easing: easing || "ease-out", fill: "forwards" });
        } catch (e) {
            el.style.display = "none";
            free.push(el);
            return;
        }
        running.push(anim);
        var done = function () {
            var i = running.indexOf(anim);
            if (i >= 0) {
                running.splice(i, 1);
            }
            if (layer && el.parentNode === layer) {
                el.style.cssText = "display:none";
                free.push(el);
            }
            if (!running.length) {
                armIdle();
            }
        };
        anim.onfinish = done;
        anim.oncancel = done;
    }

    function tr(x, y, s, r) {
        return "translate3d(" + x.toFixed(1) + "px," + y.toFixed(1) + "px,0) translate(-50%,-50%) scale(" + s + ")" + (r ? " rotate(" + r + "deg)" : "");
    }

    function shape(mask, d, c) {
        return "width:" + d + "px;height:" + d + "px;background:" + c + ";-webkit-mask:" + mask + " center/contain no-repeat;mask:" + mask + " center/contain no-repeat;";
    }

    function ripple(x, y, k) {
        var c = pick();
        var d = 64 * k;
        var ring = take();
        if (ring) {
            fly(ring, "width:" + d + "px;height:" + d + "px;border-radius:50%;box-sizing:border-box;border:" + (2.5 * k) + "px solid " + c + ";", [
                { transform: tr(x, y, 0.15), opacity: 0.95 },
                { transform: tr(x, y, 1.25), opacity: 0 }
            ], 560, "cubic-bezier(.15,.7,.3,1)");
        }
        var glow = take();
        if (glow) {
            fly(glow, "width:" + d + "px;height:" + d + "px;border-radius:50%;background:radial-gradient(circle," + c + " 0%,transparent 68%);", [
                { transform: tr(x, y, 0.3), opacity: 0.65 },
                { transform: tr(x, y, 1), opacity: 0 }
            ], 420, "ease-out");
        }
        var ring2 = take();
        if (ring2) {
            fly(ring2, "width:" + d * 0.7 + "px;height:" + d * 0.7 + "px;border-radius:50%;box-sizing:border-box;border:" + (1.5 * k) + "px solid " + c + ";", [
                { transform: tr(x, y, 0.1), opacity: 0 },
                { transform: tr(x, y, 0.5), opacity: 0.7, offset: 0.25 },
                { transform: tr(x, y, 1.1), opacity: 0 }
            ], 640, "cubic-bezier(.2,.6,.3,1)");
        }
    }

    function spark(x, y, k) {
        var n = 10;
        var base = Math.random() * 6.283;
        for (var i = 0; i < n; i++) {
            var el = take();
            if (!el) {
                return;
            }
            var a = base + (i / n) * 6.283 + (Math.random() - 0.5) * 0.35;
            var dist = (26 + Math.random() * 38) * k;
            var d = (4 + Math.random() * 3) * k;
            var c = pick();
            fly(el, "width:" + d + "px;height:" + d + "px;border-radius:50%;background:" + c + ";box-shadow:0 0 " + (d * 1.2) + "px " + c + ";", [
                { transform: tr(x, y, 1), opacity: 1 },
                { transform: tr(x + Math.cos(a) * dist, y + Math.sin(a) * dist + 6 * k, 0.1), opacity: 0 }
            ], 520 + Math.random() * 200, "cubic-bezier(.1,.75,.3,1)");
        }
    }

    function heart(x, y, k) {
        for (var i = 0; i < 4; i++) {
            var el = take();
            if (!el) {
                return;
            }
            var d = (14 + Math.random() * 10) * k;
            var dx = (Math.random() - 0.5) * 46 * k;
            var rise = (50 + Math.random() * 40) * k;
            var r = (Math.random() - 0.5) * 40;
            fly(el, shape(MASK_HEART, d, pick()), [
                { transform: tr(x + (Math.random() - 0.5) * 12 * k, y, 0.3, 0), opacity: 0 },
                { transform: tr(x + dx * 0.4, y - rise * 0.3, 1.05, r * 0.5), opacity: 1, offset: 0.2 },
                { transform: tr(x + dx, y - rise, 0.8, r), opacity: 0 }
            ], 780 + Math.random() * 260, "ease-out");
        }
    }

    function star(x, y, k) {
        var n = 6;
        var base = Math.random() * 6.283;
        for (var i = 0; i < n; i++) {
            var el = take();
            if (!el) {
                return;
            }
            var a = base + (i / n) * 6.283 + (Math.random() - 0.5) * 0.4;
            var dist = (30 + Math.random() * 34) * k;
            var d = (10 + Math.random() * 8) * k;
            var r = (Math.random() - 0.5) * 240;
            fly(el, shape(MASK_STAR, d, pick()), [
                { transform: tr(x, y, 0.4, 0), opacity: 1 },
                { transform: tr(x + Math.cos(a) * dist, y + Math.sin(a) * dist, 1, r), opacity: 0.9, offset: 0.55 },
                { transform: tr(x + Math.cos(a) * dist * 1.15, y + Math.sin(a) * dist * 1.15 + 8 * k, 0.2, r * 1.3), opacity: 0 }
            ], 640 + Math.random() * 200, "cubic-bezier(.15,.7,.3,1)");
        }
    }

    function twinkle(x, y, k, count) {
        for (var i = 0; i < count; i++) {
            var el = take();
            if (!el) {
                return;
            }
            var ox = count > 1 ? (Math.random() - 0.5) * 56 * k : (Math.random() - 0.5) * 14 * k;
            var oy = count > 1 ? (Math.random() - 0.5) * 56 * k : (Math.random() - 0.5) * 14 * k;
            var d = (12 + Math.random() * 14) * k;
            fly(el, shape(MASK_TWINKLE, d, pick()), [
                { transform: tr(x + ox, y + oy, 0, 0), opacity: 0 },
                { transform: tr(x + ox, y + oy, 1, 45), opacity: 1, offset: 0.35 },
                { transform: tr(x + ox, y + oy + 10 * k, 0, 120), opacity: 0 }
            ], 480 + Math.random() * 240, "ease-in-out");
        }
    }

    function emit(x, y, moving) {
        if (type === "off" || !canAnimate) {
            return;
        }
        if (moving) {
            if (type !== "twinkle") {
                return;
            }
            var now = Date.now();
            if (now - lastMove < TRAIL_GAP) {
                return;
            }
            lastMove = now;
        }
        if (!ensureLayer()) {
            return;
        }
        clearTimeout(idleTimer);
        var k = SIZES[size].k;
        if (type === "ripple") {
            ripple(x, y, k);
        } else if (type === "spark") {
            spark(x, y, k);
        } else if (type === "heart") {
            heart(x, y, k);
        } else if (type === "star") {
            star(x, y, k);
        } else {
            twinkle(x, y, k, moving ? 1 : 5);
        }
        if (!running.length) {
            armIdle();
        }
    }

    var hasTouch = "ontouchstart" in window || (navigator.maxTouchPoints || 0) > 0;
    var opts = { capture: true, passive: true };

    function onTouchStart(ev) {
        var t = ev.changedTouches;
        for (var i = 0; i < t.length && i < 3; i++) {
            emit(t[i].clientX, t[i].clientY, false);
        }
    }

    function onTouchMove(ev) {
        if (type !== "twinkle") {
            return;
        }
        var t = ev.changedTouches;
        if (t.length) {
            emit(t[0].clientX, t[0].clientY, true);
        }
    }

    var mouseDown = false;
    function onMouseDown(ev) {
        mouseDown = true;
        emit(ev.clientX, ev.clientY, false);
    }

    function onMouseMove(ev) {
        if (mouseDown) {
            emit(ev.clientX, ev.clientY, true);
        }
    }

    function onMouseUp() {
        mouseDown = false;
    }

    function bindEvents() {
        if (bound || type === "off" || !canAnimate) {
            return;
        }
        bound = true;
        if (hasTouch) {
            window.addEventListener("touchstart", onTouchStart, opts);
            if (type === "twinkle") {
                window.addEventListener("touchmove", onTouchMove, opts);
                boundMove = true;
            }
        } else {
            window.addEventListener("mousedown", onMouseDown, opts);
            if (type === "twinkle") {
                window.addEventListener("mousemove", onMouseMove, opts);
                boundMove = true;
            }
            window.addEventListener("mouseup", onMouseUp, opts);
        }
    }

    function unbindEvents() {
        if (!bound) {
            return;
        }
        bound = false;
        if (hasTouch) {
            window.removeEventListener("touchstart", onTouchStart, opts);
            if (boundMove) {
                window.removeEventListener("touchmove", onTouchMove, opts);
            }
        } else {
            window.removeEventListener("mousedown", onMouseDown, opts);
            if (boundMove) {
                window.removeEventListener("mousemove", onMouseMove, opts);
            }
            window.removeEventListener("mouseup", onMouseUp, opts);
        }
        boundMove = false;
        mouseDown = false;
    }

    function syncEvents() {
        if (type === "off" || !canAnimate) {
            unbindEvents();
            return;
        }
        if (!bound) {
            bindEvents();
            return;
        }
        var wantMove = type === "twinkle";
        if (wantMove === boundMove) {
            return;
        }
        if (hasTouch) {
            if (wantMove) {
                window.addEventListener("touchmove", onTouchMove, opts);
            } else {
                window.removeEventListener("touchmove", onTouchMove, opts);
            }
        } else {
            if (wantMove) {
                window.addEventListener("mousemove", onMouseMove, opts);
            } else {
                window.removeEventListener("mousemove", onMouseMove, opts);
            }
        }
        boundMove = wantMove;
    }

    syncEvents();
    document.addEventListener("visibilitychange", function () {
        if (document.hidden) {
            unbindEvents();
            destroyLayer();
        } else {
            syncEvents();
        }
    });

    coara.registerCommand("タッチエフェクト 種類切替", function () {
        type = TYPES[(TYPES.indexOf(type) + 1) % TYPES.length];
        persist();
        syncEvents();
        if (type === "off") {
            destroyLayer();
        }
        coara.notify(TYPE_NAMES[type], "タッチエフェクト");
    });
    coara.registerCommand("タッチエフェクト 色切替", function () {
        palette = (palette + 1) % PALETTES.length;
        persist();
        coara.notify(PALETTES[palette].name, "タッチエフェクト");
    });
    coara.registerCommand("タッチエフェクト 大きさ切替", function () {
        size = (size + 1) % SIZES.length;
        persist();
        coara.notify(SIZES[size].name, "タッチエフェクト");
    });
    coara.registerCommand("タッチエフェクト OFF/ON", function () {
        if (type === "off") {
            type = coara.storage.get("last") || "ripple";
            if (type === "off" || TYPES.indexOf(type) < 0) {
                type = "ripple";
            }
        } else {
            coara.storage.set("last", type);
            type = "off";
            destroyLayer();
        }
        persist();
        syncEvents();
        coara.notify(TYPE_NAMES[type], "タッチエフェクト");
    });
})();
