(function () {
    var HOST = location.hostname || "local";
    var MODES = [
        { name: "ネガポジ", f: "invert(1)" },
        { name: "ネガポジ+モノクロ", f: "invert(1) grayscale(1)" },
        { name: "ネガポジ+コントラスト強", f: "invert(1) contrast(1.2)" },
        { name: "ネガポジ+やや暗め", f: "invert(1) brightness(0.88)" }
    ];
    var METHODS = ["フィルタ", "ブレンド(軽量)", "バックドロップ"];

    var cfg = { on: 1, mode: 0, method: 0, ex: [] };
    try {
        var raw = coara.storage.get("cfg");
        if (raw) {
            var p = JSON.parse(raw);
            if (p && typeof p === "object") {
                cfg.on = p.on === 0 ? 0 : 1;
                cfg.mode = p.mode >= 0 && p.mode < MODES.length ? p.mode | 0 : 0;
                cfg.method = p.method >= 0 && p.method < METHODS.length ? p.method | 0 : 0;
                cfg.ex = Array.isArray(p.ex) ? p.ex : [];
            }
        }
    } catch (e) {}

    var handle = null;

    function css() {
        var f = MODES[cfg.mode].f;
        if (cfg.method === 1) {
            return "html{background:#fff}html::after{content:'';position:fixed;left:0;top:0;width:100%;height:100%;background:#fff;mix-blend-mode:difference;pointer-events:none;z-index:2147483647}@media print{html::after{display:none}}";
        }
        if (cfg.method === 2) {
            return "html{background:#fff}html::after{content:'';position:fixed;left:0;top:0;width:100%;height:100%;-webkit-backdrop-filter:" + f + ";backdrop-filter:" + f + ";pointer-events:none;z-index:2147483647}@media print{html::after{display:none}}";
        }
        return "html{background:#fff;filter:" + f + " !important}@media print{html{filter:none !important}}";
    }

    function apply() {
        if (handle) {
            handle.remove();
            handle = null;
        }
        if (cfg.on && cfg.ex.indexOf(HOST) < 0) {
            handle = coara.addStyle(css());
        }
    }

    function save() {
        coara.storage.set("cfg", JSON.stringify(cfg));
    }

    coara.registerCommand("ネガポジ このサイトON/OFF", function () {
        var i = cfg.ex.indexOf(HOST);
        if (i >= 0) {
            cfg.ex.splice(i, 1);
        } else {
            cfg.ex.push(HOST);
        }
        save();
        apply();
        coara.notify(HOST + ": " + (i >= 0 ? "反転する" : "反転しない"), "完全ネガポジ反転");
    });

    coara.registerCommand("ネガポジ 全体ON/OFF", function () {
        cfg.on = cfg.on ? 0 : 1;
        save();
        apply();
        coara.notify(cfg.on ? "全体ON" : "全体OFF", "完全ネガポジ反転");
    });

    coara.registerCommand("ネガポジ モード切替", function () {
        cfg.mode = (cfg.mode + 1) % MODES.length;
        save();
        apply();
        coara.notify(MODES[cfg.mode].name + (cfg.method === 1 ? " (ブレンド方式では無効)" : ""), "完全ネガポジ反転");
    });

    coara.registerCommand("ネガポジ 方式切替", function () {
        cfg.method = (cfg.method + 1) % METHODS.length;
        save();
        apply();
        coara.notify("方式: " + METHODS[cfg.method], "完全ネガポジ反転");
    });

    apply();
})();
