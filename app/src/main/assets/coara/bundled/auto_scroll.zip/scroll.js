(function () {
    var speed = parseInt(coara.storage.get('speed') || '60', 10);
    var running = false;
    var last = 0;
    var carry = 0;

    function frame(t) {
        if (!running) {
            return;
        }
        if (last) {
            carry += speed * (t - last) / 1000;
            var step = Math.floor(carry);
            if (step > 0) {
                carry -= step;
                window.scrollBy(0, step);
            }
        }
        last = t;
        var bottom = window.innerHeight + window.pageYOffset >= document.documentElement.scrollHeight - 2;
        if (bottom) {
            stop();
            return;
        }
        requestAnimationFrame(frame);
    }

    function start() {
        if (running) {
            return;
        }
        running = true;
        last = 0;
        carry = 0;
        requestAnimationFrame(frame);
    }

    function stop() {
        running = false;
    }

    function setSpeed(v) {
        speed = Math.max(10, Math.min(600, v));
        coara.storage.set('speed', String(speed));
        coara.notify('速度 ' + speed + 'px/秒');
    }

    coara.registerCommand('自動スクロール 開始/停止', function () {
        if (running) {
            stop();
        } else {
            start();
        }
    });
    coara.registerCommand('速度アップ', function () { setSpeed(speed + 20); });
    coara.registerCommand('速度ダウン', function () { setSpeed(speed - 20); });
    window.addEventListener('touchstart', stop, { passive: true });
})();
